(function(){
 'use strict';
 const el=id=>document.getElementById(id),esc=s=>window.QingruContent.escape(s);
 let currentCourse=null;
 function refresh(lesson,index){
  const course=window.QINGRU_COURSE_DATA,extra=el('interactive'),stage=el('stage');
  const showInteraction=course.kind!=='document'&&Boolean(extra.innerHTML.trim());
  stage.classList.toggle('interaction-mode',showInteraction);
  stage.classList.toggle('reading-mode',course.kind==='document');
  el('stageCaption').textContent=showInteraction?'':lesson.body.length>135?lesson.body.slice(0,134)+'…':lesson.body;
  el('stageCaption').hidden=showInteraction;
  el('lessonVisual').hidden=showInteraction;
  extra.hidden=false;
  (showInteraction?el('stageInteraction'):el('readingDetail')).appendChild(extra);
  if(course.kind==='document'){
   const picture=(lesson.blocks||[]).flatMap(b=>b.images||[])[0];
   if(picture){el('lessonVisual').innerHTML='<figure class="source-figure"><img src="'+esc(picture)+'" alt="本页教材原图"><figcaption>教材原图</figcaption></figure>';el('stageCaption').hidden=true;}
  }
  el('roomMenu').open=false;
  if(window.matchMedia('(max-width:900px)').matches){document.body.classList.remove('catalog-open');el('sidebarScrim').hidden=true;el('catalogToggle').setAttribute('aria-expanded','false');el('catalogToggle').setAttribute('aria-label','展开课程目录');}
 }
 function open(id){el('lessonVideo').pause();el('roomMenu').open=false;el(id).showModal();}
 function init(course){
  currentCourse=course;document.body.classList.add('classroom-ready');el('courseView').setAttribute('aria-busy','false');for(const id of ['catalogToggle','openNotes','openQA','courseSwitch'])el(id).disabled=false;if(course.kind!=='document'){el('lectureStart').disabled=false;el('lectureStart').textContent='播放数字精讲';}
  el('roomMode').textContent=course.kind==='document'?'资料课件':'数字精讲';
  if(course.kind==='document')el('lectureStart').hidden=true;
  const courses=window.QingruLibrary.courses;
  el('courseSwitch').innerHTML=courses.map(c=>'<option value="'+esc(c.id)+'">'+esc(c.title)+'</option>').join('')+(course.id?.startsWith('draft-')?'<option value="'+esc(course.id)+'">'+esc(course.title)+'</option>':'');
  el('courseSwitch').value=course.id;
  el('courseSwitch').onchange=()=>{const chosen=courses.find(c=>c.id===el('courseSwitch').value);if(chosen)location.href=chosen.url;};
  el('openNotes').onclick=()=>open('notesDialog');el('openQA').onclick=()=>open('qaDialog');
  const toggle=()=>{
   const small=window.matchMedia('(max-width:900px)').matches;
   if(small){const expanded=document.body.classList.toggle('catalog-open');el('sidebarScrim').hidden=!expanded;el('catalogToggle').setAttribute('aria-expanded',String(expanded));el('catalogToggle').setAttribute('aria-label',expanded?'收起课程目录':'展开课程目录');}
   else{const hidden=document.body.classList.toggle('catalog-hidden');el('catalogToggle').setAttribute('aria-expanded',String(!hidden));el('catalogToggle').setAttribute('aria-label',hidden?'展开课程目录':'收起课程目录');}
  };
  el('catalogToggle').onclick=toggle;el('sidebarScrim').onclick=toggle;
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.body.classList.contains('catalog-open'))toggle();});
  document.addEventListener('click',e=>{if(!el('roomMenu').contains(e.target))el('roomMenu').open=false;});
  for(const b of el('roomMenu').querySelectorAll('button'))b.addEventListener('click',()=>{el('roomMenu').open=false;});
  for(const d of document.querySelectorAll('dialog'))d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}});
 }
 window.QingruClassroom={refresh,init};
})();
