(function(root){
 'use strict';let opening;const CACHE=new Map(),DB='qingru-teaching-studio',VERSION=1;
 function database(){if(!opening)opening=new Promise((resolve,reject)=>{if(!root.indexedDB){reject(Error('当前浏览器不能保存课堂，请使用普通浏览器窗口。'));return;}const r=indexedDB.open(DB,VERSION);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('courses'))r.result.createObjectStore('courses',{keyPath:'id'});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});return opening;}
 async function op(mode,work){const db=await database();return new Promise((resolve,reject)=>{const tx=db.transaction('courses',mode),store=tx.objectStore('courses');let value;const req=work(store);req.onsuccess=()=>{value=req.result;};tx.oncomplete=()=>resolve(value);tx.onerror=()=>reject(tx.error||req.error);tx.onabort=()=>reject(tx.error||Error('保存未完成'));});}
 const Store={async put(course){await op('readwrite',s=>s.put(course));CACHE.set(course.id,course);return course;},async get(id){if(CACHE.has(id))return CACHE.get(id);const c=await op('readonly',s=>s.get(id));if(c)CACHE.set(id,c);return c;},async list(){return(await op('readonly',s=>s.getAll())).sort((a,b)=>b.created_at.localeCompare(a.created_at));},async remove(id){await op('readwrite',s=>s.delete(id));CACHE.delete(id);},async updatePage(id,page){const c=await this.get(id);if(c){c.last_page=page;await this.put(c);}}};
 root.QingruStore=Store;
})(globalThis);

;
/* Qingru material parser and deterministic teaching draft compiler.
 * The original blocks stay intact; extracted summaries never replace sources.
 */
(function(root){
 'use strict';
 const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const clean=s=>String(s??'').replace(/\r/g,'').replace(/[\t\u00a0]+/g,' ').replace(/ +/g,' ').trim();
 const shorten=(s,n=50)=>{s=clean(s);return s.length>n?s.slice(0,n-1)+'…':s;};
 const sentences=s=>String(s).split(/(?<=[。！？；\n])/).map(clean).filter(Boolean);
 const texts=node=>Array.from(node?.getElementsByTagNameNS('*','t')||[]).map(n=>n.textContent).join('');
 function xml(s){const d=new DOMParser().parseFromString(s,'application/xml');if(d.getElementsByTagName('parsererror').length)throw Error('文件中的XML内容无法解析。');return d;}
 function math(n){if(!n)return'';const key=n.localName,els=Array.from(n.children||[]),part=k=>els.find(c=>c.localName===k);if(key==='f')return'('+math(part('num'))+')/('+math(part('den'))+')';if(key==='sSup')return math(part('e'))+'^('+math(part('sup'))+')';if(key==='sSub')return math(part('e'))+'_('+math(part('sub'))+')';if(key==='t')return n.textContent;return els.map(math).join('');}
 function paragraph(node){let result='';function walk(n){if(n.nodeType!==1)return;const k=n.localName;if(k==='oMath'||k==='oMathPara'){result+=math(n);return;}if(k==='t'){result+=n.textContent;return;}if(k==='tab')result+=' ';else if(k==='br')result+='\n';else for(const c of n.children)walk(c);}walk(node);return clean(result);}
 const heading=s=>s.length<90&&(/^(第[一二三四五六七八九十百\d]+[章节篇部分]|[一二三四五六七八九十]+[、．.]|\d+(?:\.\d+){0,3}[、.\s])/u.test(s)||/^(导论|绪论|课程说明|学习目标|本章小结|知识总结|案例分析|思考题|练习题)$/.test(s));
 function classify(block){const t=block.text||'';if(block.kind==='table')return'table';if(block.kind==='image')return'image';if(heading(t))return'heading';if(/[=＝]|[αβγδΔ]/.test(t)&&t.length<200)return'formula';if(/步骤|首先|其次|第一步|第二步/.test(t))return'steps';if(/条件|假设|适用|除非|其他.*不变/.test(t))return'condition';if(/案例|例如|假设.*元|示例/.test(t))return'example';return'concept';}
 function packText(name,text){const blocks=text.split(/\n+/).map(clean).filter(Boolean).map((text,i)=>({id:'p'+(i+1),kind:'paragraph',text,style:heading(text)?'heading':''}));if(!blocks.length)throw Error('没有读取到可用文字，请检查文件内容。');return{name,blocks};}
 let zipReady=null;
 async function loadZip(){if(root.fflate)return;if(!zipReady)zipReady=new Promise((resolve,reject)=>{const s=document.createElement('script');s.src='vendor/fflate/umd/index.js';s.onload=resolve;s.onerror=()=>{s.remove();zipReady=null;reject(Error('文件解析组件未能加载，请再次选择材料。'));};document.head.appendChild(s);});await zipReady;}
 async function parseFile(file,progress=()=>{}){
  const ext=file.name.split('.').pop().toLowerCase();if(file.size>20*1024*1024)throw Error('单个文件请控制在20MB以内。');progress('正在读取 '+file.name);
  if(['txt','md'].includes(ext)){const bytes=new Uint8Array(await file.arrayBuffer());let text=new TextDecoder('utf-8').decode(bytes);if(text.includes('\ufffd'))text=new TextDecoder('gb18030').decode(bytes);return packText(file.name,text);}
  if(ext==='pdf'){
   if(location.protocol==='file:')throw Error('PDF请在网页访问地址中导入；离线直接打开时可使用DOCX、PPTX或TXT。');
   const pdf=await import('./vendor/pdfjs-dist/build/pdf.mjs?v=6.5.438');pdf.GlobalWorkerOptions.workerSrc=new URL('./vendor/pdfjs-dist/build/pdf.worker.mjs?v=6.5.438',location.href).href;
   const loading=pdf.getDocument({data:new Uint8Array(await file.arrayBuffer()),isEvalSupported:false,cMapUrl:new URL('./vendor/pdfjs-dist/cmaps/',location.href).href,cMapPacked:true,standardFontDataUrl:new URL('./vendor/pdfjs-dist/standard_fonts/',location.href).href,wasmUrl:new URL('./vendor/pdfjs-dist/wasm/',location.href).href}),doc=await loading.promise;
   const blocks=[];try{for(let i=1;i<=doc.numPages;i++){progress('解析PDF '+i+' / '+doc.numPages+'页');const p=await doc.getPage(i),c=await p.getTextContent();let line='',lastY=null;for(const item of c.items){if(!item.str)continue;const y=item.transform?.[5];if(lastY!==null&&Math.abs(y-lastY)>3&&line){blocks.push({kind:'paragraph',text:clean(line),page:i});line='';}line+=item.str+(item.hasEOL?'\n':' ');lastY=y;}if(clean(line))blocks.push({kind:'paragraph',text:clean(line),page:i});p.cleanup();}}finally{await loading.destroy();}
   if(!blocks.length)throw Error('此PDF未包含可提取文字，可能是扫描件。请使用带文字层的PDF或DOCX。');return{name:file.name,blocks};
  }
  if(!['docx','pptx'].includes(ext))throw Error('请导入DOCX、PPTX、文字型PDF、TXT或Markdown文件。');
  await loadZip();
  let total=0;const entries=root.fflate.unzipSync(new Uint8Array(await file.arrayBuffer()),{filter:f=>{const include=ext==='docx'?/^word\/(document\.xml|styles\.xml|_rels\/document\.xml\.rels|media\/)/.test(f.name):/^ppt\/slides\/slide\d+\.xml$/.test(f.name);if(include){total+=f.originalSize;if(total>80*1024*1024)throw Error('解压后的材料过大，请拆分章节后导入。');}return include;}});
  const blocks=[];
  if(ext==='docx'){
   if(!entries['word/document.xml'])throw Error('DOCX文件缺少正文。');const doc=xml(root.fflate.strFromU8(entries['word/document.xml'])),body=doc.getElementsByTagNameNS('*','body')[0];
   const ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main',levels=new Map();if(entries['word/styles.xml'])for(const s of xml(root.fflate.strFromU8(entries['word/styles.xml'])).getElementsByTagNameNS('*','style')){const name=s.getElementsByTagNameNS('*','name')[0]?.getAttributeNS(ns,'val')||'',outline=s.getElementsByTagNameNS('*','outlineLvl')[0]?.getAttributeNS(ns,'val'),match=name.match(/(?:heading|标题)\s*([1-6])/i);if(outline!==undefined&&Number(outline)<6)levels.set(s.getAttributeNS(ns,'styleId'),Number(outline)+1);else if(match)levels.set(s.getAttributeNS(ns,'styleId'),Number(match[1]));}
   const rels=new Map();if(entries['word/_rels/document.xml.rels'])for(const r of xml(root.fflate.strFromU8(entries['word/_rels/document.xml.rels'])).getElementsByTagName('Relationship'))rels.set(r.getAttribute('Id'),r.getAttribute('Target'));
   for(const node of body.children){
    if(node.localName==='p'){const text=paragraph(node),style=node.getElementsByTagNameNS('*','pStyle')[0]?.getAttributeNS(ns,'val')||'';if(text)blocks.push({kind:'paragraph',text,style,heading_level:levels.get(style)||null});
     for(const image of node.getElementsByTagNameNS('*','blip')){const id=image.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','embed'),target=rels.get(id),bytes=entries['word/'+target];if(bytes&&bytes.length<4*1024*1024&&/\.(png|jpe?g|webp)$/i.test(target)){let binary='';for(let at=0;at<bytes.length;at+=8192)binary+=String.fromCharCode(...bytes.subarray(at,at+8192));const mime=/\.png$/i.test(target)?'image/png':/\.webp$/i.test(target)?'image/webp':'image/jpeg';blocks.push({kind:'image',text:'原文插图',images:['data:'+mime+';base64,'+btoa(binary)]});}}
    }else if(node.localName==='tbl'){const rows=Array.from(node.children).filter(n=>n.localName==='tr').map(row=>Array.from(row.children).filter(n=>n.localName==='tc').map(c=>Array.from(c.getElementsByTagNameNS('*','p')).map(paragraph).join('\n')));if(rows.length)blocks.push({kind:'table',rows,text:rows.map(r=>r.join(' | ')).join('\n')});}
   }
  }else{
   const keys=Object.keys(entries).sort((a,b)=>Number(a.match(/slide(\d+)/)[1])-Number(b.match(/slide(\d+)/)[1]));for(const[keyIndex,key]of keys.entries()){const doc=xml(root.fflate.strFromU8(entries[key])),parts=Array.from(doc.getElementsByTagNameNS('*','p')).map(texts).map(clean).filter(Boolean);parts.forEach((text,i)=>blocks.push({kind:'paragraph',text,style:i===0?'heading':'',heading_level:i===0?1:null,page:keyIndex+1}));}
  }
  if(!blocks.length)throw Error('没有读取到文字或表格，请确认文件有效。');return{name:file.name,blocks};
 }
 function compile(materials,title){
  if(!materials.length)throw Error('请先导入材料。');let n=0;const blocks=materials.flatMap(m=>m.blocks.map(b=>({...b,id:'src-'+(++n),source_name:m.name})));if(n>20000)throw Error('材料超过本次可处理规模，请按章节分开创建。');
  const groups=[];let current={title:title||materials[0].name.replace(/\.[^.]+$/,''),blocks:[]};
  for(const b of blocks){const t=b.text||'',isHeading=b.heading_level?b.heading_level<=2:t.length<90&&(/^(第[一二三四五六七八九十百\d]+[章节篇部分])/u.test(t)||/^(导论|绪论|课程说明|学习目标|本章小结|知识总结|案例分析|思考题|练习题)$/.test(t));if(isHeading&&current.blocks.length){groups.push(current);current={title:shorten(t,65),blocks:[]};}else if(isHeading&&!current.blocks.length)current.title=shorten(t,65);current.blocks.push(b);}if(current.blocks.length)groups.push(current);
  const lessons=[],sections=[],quizzes=[];
  groups.forEach((g,i)=>{const sid='section-'+(i+1),parts=[];let chunk=[],size=0;for(const b of g.blocks){const len=(b.text||'').length;if(chunk.length&&(size+len>750||chunk.length>=5)){parts.push(chunk);chunk=[];size=0;}chunk.push(b);size+=len;}if(chunk.length)parts.push(chunk);const section={id:sid,title:g.title,chapter_title:'导入材料',lesson_ids:[]};
   parts.forEach((bs,k)=>{const meaningful=bs.filter(b=>b.kind!=='image'&&classify(b)!=='heading'&&!b.heading_level),text=meaningful.map(b=>b.text||'').join('\n'),type=bs.some(b=>b.kind==='table')?'table':bs.some(b=>classify(b)==='formula')?'formula':bs.some(b=>classify(b)==='steps')?'steps':'reading';const id=sid+'-page-'+(k+1);lessons.push({id,title:g.title+(parts.length>1?' · '+(k+1):''),short:g.title,section_id:sid,section_title:g.title,body:sentences(text).slice(0,2).join('')||'阅读本节原文，核对概念与条件。',sources:bs.map(b=>b.id),blocks:bs,layout:type});section.lesson_ids.push(id);});sections.push(section);
   const sentence=g.blocks.flatMap(b=>sentences(b.text||'')).find(s=>s.length>=18&&s.length<=110&&/[是指为]|表示|取决于|需要/.test(s));if(sentence&&quizzes.length<12)quizzes.push({section_id:sid,q:'根据“'+g.title+'”的原文，哪项表述有材料依据？',options:[sentence,'本段结论在任何条件下都必然成立。','原文并未给出相关概念或判断依据。'],answer:0,why:'原文表述为：“'+sentence+'”请结合该段条件理解。',source:g.blocks.find(b=>(b.text||'').includes(sentence))?.id||g.blocks[0].id});
  });
  const summary=sections.map(s=>({title:s.title,text:lessons.filter(p=>p.section_id===s.id).flatMap(p=>sentences(p.body)).slice(0,2).join('')}));
  return{id:'draft-'+Date.now().toString(36),kind:'document',title:clean(title)||materials[0].name.replace(/\.[^.]+$/,''),source:materials.map(m=>m.name).join('、'),source_section:'导入材料',source_blocks:blocks,lessons,sections,quizzes,faq:[],summary,coverage:{preserved_blocks:blocks.length,source_blocks:blocks.length},materials:materials.map(m=>({name:m.name,blocks:m.blocks.length})),created_at:new Date().toISOString(),teacher:'qingru',media_state:'awaiting-production',compiler:'qingru-source-preserving-draft-v1'};
 }
 const table=rows=>'<div class="table-scroll"><table class="data-table"><thead><tr>'+rows[0].map(c=>'<th>'+escape(c)+'</th>').join('')+'</tr></thead><tbody>'+rows.slice(1).map(r=>'<tr>'+r.map(c=>'<td>'+escape(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';
 function details(lesson){return'<div class="source-reading">'+(lesson.blocks||[]).map(b=>b.rows?table(b.rows):b.kind==='image'?(b.images||[]).map(src=>'<img src="'+escape(src)+'" alt="原文插图">').join(''):'<p class="'+(classify(b)==='formula'?'math-line':'')+'">'+escape(b.text)+'</p>').join('')+'</div>';}
 function visual(lesson){const blocks=lesson.blocks||[],label={table:'表格读解',formula:'公式与关系',steps:'推理步骤',reading:'概念与条件'}[lesson.layout]||'知识讲解';const words=blocks.filter(b=>!b.rows&&b.kind!=='image').flatMap(b=>sentences(b.text)).filter(s=>s!==lesson.short).slice(0,3);return'<span class="lesson-type">'+label+'</span><div class="reading-points">'+words.map(s=>'<p>'+escape(shorten(s,48))+'</p>').join('')+'</div>';}
 function unpack(text){
  const p=JSON.parse(text),c=p.course;
  if(p.format!=='qingru-classroom-package-v1'||!c||c.kind!=='document'||typeof c.title!=='string'||!Array.isArray(c.source_blocks)||!Array.isArray(c.lessons)||!Array.isArray(c.sections)||!Array.isArray(c.quizzes)||!c.lessons.length||c.lessons.length>20000||c.source_blocks.length>20000)throw Error('这不是有效的清如课堂包，请选择导出的.qingru.json文件。');
  const validBlock=b=>b&&typeof b.id==='string'&&typeof b.text==='string'&&(!b.rows||Array.isArray(b.rows)&&b.rows.every(r=>Array.isArray(r)&&r.every(v=>typeof v==='string')))&&(!b.images||Array.isArray(b.images)&&b.images.every(v=>typeof v==='string'&&/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v)));
  if(!c.source_blocks.every(validBlock)||!c.lessons.every(l=>l&&typeof l.id==='string'&&typeof l.title==='string'&&typeof l.body==='string'&&Array.isArray(l.sources)&&Array.isArray(l.blocks)&&l.blocks.every(validBlock))||!c.sections.every(s=>s&&typeof s.id==='string'&&typeof s.title==='string'&&Array.isArray(s.lesson_ids))||!c.quizzes.every(q=>q&&typeof q.q==='string'&&typeof q.why==='string'&&Array.isArray(q.options)&&q.options.every(v=>typeof v==='string')&&Number.isInteger(q.answer)&&q.answer>=0&&q.answer<q.options.length))throw Error('课堂包内容不完整，请重新导出后导入。');
  c.id='draft-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6);c.created_at=new Date().toISOString();c.media_state='awaiting-production';c.teacher='qingru';delete c.lecture;c.faq=[];return c;
 }
 root.QingruContent={escape,clean,shorten,parseFile,packText,compile,details,visual,classify,heading,unpack};
})(globalThis);

;
window.QingruLibrary={loaded:{},courses:[{"id": "market-equilibrium", "title": "市场均衡", "category": "微观经济学", "description": "从同一杯奶茶的供求关系，理解均衡、价格调整与条件变化。数字讲师精讲与动态供求图已经就绪。", "pages": 10, "sections": 1, "quiz_count": 5, "status": "ready", "cover": "equilibrium", "url": "classroom.html", "data": "course-data.js"}, {"id": "microeconomics", "title": "微观经济学", "category": "资料课堂", "description": "从导论到市场失灵，按章节阅读教材、图表、例题与练习。原文依据与知识小结相互连接。", "pages": 722, "sections": 127, "quiz_count": 53, "status": "reading", "cover": "microeconomics", "url": "classroom.html?course=microeconomics", "data": "courses/microeconomics.js"}, {"id": "business-topics", "title": "经管应用专题", "category": "资料课堂", "description": "围绕机会成本、边际分析、投资与管理决策等主题，组织概念、案例、误区和练习。", "pages": 120, "sections": 24, "quiz_count": 24, "status": "reading", "cover": "business", "url": "classroom.html?course=business-topics", "data": "courses/business-topics.js"}]};
;
(function(){
 'use strict';const $=id=>document.getElementById(id),esc=QingruContent.escape;let materials=[],built=null,busy=false;const Library=window.QingruLibrary;
 function toast(s){const el=$('siteToast');if(!el)return;el.textContent=s;el.hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.hidden=true,5500);}
 const bookCover=(c)=>`<svg viewBox="0 0 640 360" role="img" aria-label="${esc(c.title)}教材封面"><rect width="640" height="360" fill="none"/><path d="M118 82Q220 51 318 83V299Q216 269 118 299Z" fill="#f6f9ee" stroke="#779465" stroke-width="2"/><g class="book-page-right"><path d="M318 83Q421 51 523 82V299Q421 269 318 299Z" fill="#d7e4b9" stroke="#779465" stroke-width="2"/><path d="M353 244V130M353 244H484M363 222Q399 153 475 141" fill="none" stroke="#38583a" stroke-width="3"/><circle cx="416" cy="168" r="5" fill="#38583a"/></g><path d="M152 121H270M152 147H259M152 173H277M152 199H247M152 225H271" stroke="#9db68d" stroke-width="5"/><path d="M318 84V300" stroke="#66835a" stroke-width="3"/><path d="M204 79V116L218 106L232 116V76" fill="#91ab75"/></svg>`;
 const cover=(c)=>c.id==='microeconomics'?bookCover(c):`<svg viewBox="0 0 640 360" aria-label="${esc(c.title)}课程封面" role="img"><rect width="640" height="360" fill="${c.cover==='business'?'none':'none'}"/><path d="M70 292V70M70 292H550" fill="none" stroke="#8ba37c" stroke-width="2"/>${c.cover==='business'?'<rect x="120" y="186" width="70" height="106" rx="4" fill="#94b078"/><rect x="235" y="141" width="70" height="151" rx="4" fill="#688b54"/><rect x="350" y="89" width="70" height="203" rx="4" fill="#385d33"/>':'<path d="M90 95L480 290M90 290L480 95" stroke="#38583a" stroke-width="4" fill="none"/><circle cx="285" cy="193" r="8" fill="#38583a" stroke="white" stroke-width="3"/>'}<text x="490" y="70" text-anchor="end" fill="#627953" font-size="21" font-family="Microsoft YaHei">${c.cover==='business'?'案例与决策':'概念与关系'}</text></svg>`;
 function card(c){return'<a class="course-card" href="'+esc(c.url)+'"><div class="card-cover">'+cover(c)+'</div><div class="card-copy"><span class="badge '+(c.status==='ready'?'':'reading')+'">'+(c.status==='ready'?'数字讲师精讲':'资料课堂 · 可阅读')+'</span><h3>'+esc(c.title)+'</h3><p>'+esc(c.description.split('。')[0])+'</p><div class="card-meta"><span>'+c.sections+'个知识单元 · '+c.pages+'页课件</span><span>'+c.quiz_count+'组练习</span></div></div></a>';}
 function state(s){if($('builderState'))$('builderState').textContent=s;}
 function reset(){materials=[];built=null;$('draftTitle').value='';$('materialText').value='';$('materialInput').value='';$('pasteField').hidden=true;$('builderPreview').hidden=true;$('builderIntro').hidden=false;$('compileDraft').hidden=false;$('compileDraft').disabled=false;$('openDraft').hidden=true;$('exportDraft').hidden=true;state('');renderMaterials();}
 function openBuilder(){if(busy)return;reset();$('builderDialog').showModal();$('draftTitle').focus();}
 function renderMaterials(){if(!$('materialList'))return;$('materialList').innerHTML=materials.map((m,i)=>'<div class="material-item"><span>'+esc(m.name)+'<small>'+m.blocks.length+'个原文块已读取</small></span><button type="button" data-remove="'+i+'" aria-label="移除'+esc(m.name)+'">×</button></div>').join('');for(const b of $('materialList').querySelectorAll('[data-remove]'))b.onclick=()=>{materials.splice(Number(b.dataset.remove),1);built=null;renderMaterials();};}
 async function addFiles(files){if(busy)return;const list=Array.from(files);if(materials.length+list.length>8){state('每次课堂最多导入8份材料。');return;}busy=true;$('compileDraft').disabled=true;$('addFiles').disabled=true;
  try{if(list.some(f=>f.name.endsWith('.qingru.json'))){if(list.length!==1||materials.length)throw Error('请单独选择一个清如课堂包。');const f=list[0];if(f.size>20*1024*1024)throw Error('课堂包请控制在20MB以内。');built=QingruContent.unpack(await f.text());await QingruStore.put(built);$('draftTitle').value=built.title;present(built);state('课堂包已导入，可以继续学习。');await refreshDrafts();return;}for(const f of list){const value=await QingruContent.parseFile(f,state);materials.push(value);if(!$('draftTitle').value)$('draftTitle').value=f.name.replace(/\.[^.]+$/,'');renderMaterials();}state('材料已读取。');}catch(e){state(e.message||'材料读取失败，请换一份文件重试。');}finally{busy=false;$('compileDraft').disabled=false;$('addFiles').disabled=false;}
 }
 async function compile(){if(busy)return;busy=true;$('compileDraft').disabled=true;state('正在梳理知识结构与课堂页面…');try{await new Promise(requestAnimationFrame);const source=[...materials],extra=$('materialText').value.trim();if(extra)source.push(QingruContent.packText('补充文字',extra));built=QingruContent.compile(source,$('draftTitle').value);await QingruStore.put(built);present(built);state('课件草稿已保存。');await refreshDrafts();}catch(e){state(e.message||'生成未完成，请重试。');}finally{busy=false;$('compileDraft').disabled=false;}}
 function present(c){$('previewCount').textContent=c.sections.length+'个知识单元 · '+c.lessons.length+'页课堂草稿';$('previewOutline').innerHTML=c.sections.map(s=>'<li>'+esc(s.title)+'<small>'+s.lesson_ids.length+'页 · 原文可核对</small></li>').join('');$('builderPreview').hidden=false;$('builderIntro').hidden=true;$('compileDraft').hidden=true;$('openDraft').href='classroom.html?draft='+encodeURIComponent(c.id);$('openDraft').hidden=false;$('exportDraft').hidden=false;}
 function download(course){const blob=new Blob([JSON.stringify({format:'qingru-classroom-package-v1',course},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=course.title.replace(/[\\/:*?"<>|]/g,'_')+'.qingru.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}
 async function refreshDrafts(){let drafts=[];try{drafts=await QingruStore.list();}catch(e){if($('recentDrafts'))$('recentDrafts').textContent='当前浏览器未开放本地存储，已发布课堂仍可使用。';return;}
  if(document.querySelector('.workbench-foot .recent-disclosure'))document.querySelector('.workbench-foot .recent-disclosure').hidden=!drafts.length;
  if($('recentDrafts')&&drafts.length)$('recentDrafts').innerHTML='<div class="recent-head"><h2>最近创建的课堂</h2><a href="courses.html?filter=draft">查看全部草稿</a></div>'+drafts.slice(0,3).map(d=>draftRow(d)).join('');
  if($('draftList')){const q=$('librarySearch').value.trim().toLowerCase(),filtered=drafts.filter(d=>d.title.toLowerCase().includes(q));$('draftList').innerHTML=filtered.map(draftRow).join('');$('draftList').hidden=filter!=='draft';if(filter==='draft'){$('libraryEmpty').hidden=filtered.length>0;}}
  for(const b of document.querySelectorAll('[data-export-draft]'))b.onclick=async()=>download(await QingruStore.get(b.dataset.exportDraft));
  for(const b of document.querySelectorAll('[data-delete-draft]'))b.onclick=async()=>{const d=await QingruStore.get(b.dataset.deleteDraft);if(d&&confirm('删除“'+d.title+'”的本地草稿？导出的课堂包不受影响。')){await QingruStore.remove(d.id);refreshDrafts();}};
 }
 function draftRow(d){return'<article class="draft-row"><div><h3>'+esc(d.title)+'</h3><p>'+d.lessons.length+'页课件 · '+d.source_blocks.length+'个来源块 · 讲解视频待制作</p></div><a class="button" href="classroom.html?draft='+encodeURIComponent(d.id)+'">进入课堂</a><button class="button text" data-export-draft="'+esc(d.id)+'">导出</button><button class="button text" data-delete-draft="'+esc(d.id)+'">删除</button></article>';}
 let searchTimer=0;
 let filter=new URLSearchParams(location.search).get('filter')||'all',album=0,filtered=[],initialCourse=new URLSearchParams(location.search).get('selected');
 function renderLibrary(){if(!$('albumStage'))return;const q=$('librarySearch').value.trim().toLowerCase();filtered=Library.courses.filter(c=>(filter==='all'||c.status===filter)&&(c.title+c.description+c.category).toLowerCase().includes(q));if(filter==='draft')filtered=[];if(initialCourse){const chosen=filtered.findIndex(c=>c.id===initialCourse);if(chosen>=0)album=chosen;initialCourse=null;}album=Math.max(0,Math.min(album,filtered.length-1));$('albumStage').hidden=!filtered.length;$('albumControls').hidden=filtered.length<2;$('libraryEmpty').textContent=filter==='draft'?'还没有课程草稿':'没有匹配的课程';$('libraryEmpty').hidden=filtered.length>0||filter==='draft';if(filtered.length)showAlbum();refreshDrafts();for(const b of document.querySelectorAll('[data-filter]'))b.classList.toggle('active',b.dataset.filter===filter);}
 function showAlbum(){
  const c=filtered[album];if(!c)return;const stage=$('albumStage'),key=filtered.map(x=>x.id).join('|');stage.dataset.course=c.id;stage.dataset.ordinal=String(album+1).padStart(2,'0');
  if(stage.dataset.ringKey!==key){
   stage.dataset.ringKey=key;stage.innerHTML='<div class="course-ring" data-count="'+filtered.length+'" aria-label="选择课程">'+filtered.map((x,i)=>'<button type="button" class="course-ring-card ring-tone-'+i%3+'" data-ring-index="'+i+'"><span class="ring-card-type">'+(x.status==='ready'?'数字讲师精讲':'资料课堂')+'</span><span class="ring-card-cover">'+cover(x)+'</span><h3>'+esc(x.title)+'</h3><span class="ring-card-foot"><span>'+x.pages+'页课件</span><span class="ring-choice-dot" aria-hidden="true"></span></span></button>').join('')+'</div><div class="album-copy"></div><div class="album-actions"></div>';
   const scene=stage.querySelector('.course-ring');let gesture=null,suppressUntil=0;
   scene.addEventListener('click',e=>{const a=e.target.closest('[data-ring-index]');if(!a||performance.now()<suppressUntil)return;album=Number(a.dataset.ringIndex);showAlbum();});
   scene.addEventListener('pointerdown',e=>{if(e.button!==0)return;gesture={id:e.pointerId,x:e.clientX,y:e.clientY,dx:0,active:false};});
   scene.addEventListener('pointermove',e=>{if(!gesture||gesture.id!==e.pointerId)return;const dx=e.clientX-gesture.x,dy=e.clientY-gesture.y;if(!gesture.active&&Math.abs(dx)>Math.abs(dy)+8){gesture.active=true;scene.setPointerCapture(e.pointerId);scene.classList.add('is-dragging');}if(gesture.active){gesture.dx=dx;scene.style.setProperty('--gesture',Math.max(-90,Math.min(90,dx))+'px');}});
   function release(e){if(!gesture||gesture.id!==e.pointerId)return;const g=gesture;gesture=null;scene.classList.remove('is-dragging');scene.style.removeProperty('--gesture');if(g.active){suppressUntil=performance.now()+250;if(e.type!=='pointercancel'&&Math.abs(g.dx)>48){album=Math.max(0,Math.min(filtered.length-1,album+(g.dx<0?1:-1)));showAlbum();}}}
   scene.addEventListener('pointerup',release);scene.addEventListener('pointercancel',release);scene.addEventListener('dragstart',e=>e.preventDefault());
  }
  for(const a of stage.querySelectorAll('[data-ring-index]')){const i=Number(a.dataset.ringIndex);let slot=(i-album+filtered.length)%filtered.length;if(slot>filtered.length/2)slot-=filtered.length;a.style.setProperty('--slot',slot);a.style.setProperty('--depth',Math.abs(slot));a.classList.toggle('is-current',i===album);a.setAttribute('aria-pressed',String(i===album));a.setAttribute('aria-label','选择'+filtered[i].title);}
  const copy=stage.querySelector('.album-copy');copy.innerHTML='<h2>'+esc(c.title)+'</h2><p>'+esc(c.description.split('。')[0])+'</p><div class="album-numbers"><div><strong>'+c.sections+'</strong><span>知识单元</span></div><div><strong>'+c.pages+'</strong><span>课件页面</span></div><div><strong>'+c.quiz_count+'</strong><span>理解练习</span></div></div>';
  stage.querySelector('.album-actions').innerHTML='<a class="button primary" href="'+esc(c.url)+'">'+(c.status==='ready'?'进入课堂':'查看课件')+'</a>';
  window.QingruMotion?.enter(copy);$('albumPosition').textContent=String(album+1).padStart(2,'0')+' / '+String(filtered.length).padStart(2,'0');$('previousAlbum').disabled=album===0;$('nextAlbum').disabled=album===filtered.length-1;
 }

 for(const b of document.querySelectorAll('[data-import]'))b.onclick=openBuilder;
 if($('builderDialog')){$('closeBuilder').onclick=()=>$('builderDialog').close();$('addFiles').onclick=()=>$('materialInput').click();$('materialInput').onchange=e=>addFiles(e.target.files);$('pasteToggle').onclick=()=>{$('pasteField').hidden=!$('pasteField').hidden;if(!$('pasteField').hidden)$('materialText').focus();};$('compileDraft').onclick=compile;$('exportDraft').onclick=()=>built&&download(built);}
 if($('homeDrop')){const target=$('homeDrop');target.ondragover=e=>{e.preventDefault();target.classList.add('dragging');};target.ondragleave=()=>target.classList.remove('dragging');target.ondrop=e=>{e.preventDefault();target.classList.remove('dragging');openBuilder();addFiles(e.dataTransfer.files);};}
 if($('recentCourses'))$('recentCourses').innerHTML=Library.courses.map(card).join('');
 if($('auditionVoice'))$('auditionVoice').onclick=async()=>{try{const audio=$('teacherAudition');if(audio.paused){await audio.play();$('auditionVoice').textContent='停止试听';}else{audio.pause();audio.currentTime=0;$('auditionVoice').textContent='试听讲解声线';}}catch{toast('浏览器未能播放语音，请再点击一次。');}};
 if($('teacherAudition'))$('teacherAudition').onended=()=>{if($('auditionVoice'))$('auditionVoice').textContent='试听讲解声线';};
 if($('librarySearch')){$('librarySearch').value=new URLSearchParams(location.search).get('q')||'';$('librarySearch').oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{album=0;renderLibrary();},90);};for(const b of document.querySelectorAll('[data-filter]'))b.onclick=()=>{filter=b.dataset.filter;album=0;renderLibrary();};$('previousAlbum').onclick=()=>{album--;showAlbum();};$('nextAlbum').onclick=()=>{album++;showAlbum();};$('albumStage').tabIndex=0;$('albumStage').onkeydown=e=>{if(e.key==='ArrowRight'&&album<filtered.length-1){e.preventDefault();album++;showAlbum();}if(e.key==='ArrowLeft'&&album>0){e.preventDefault();album--;showAlbum();}};renderLibrary();}else refreshDrafts();
 if($('librarySearch')&&new URLSearchParams(location.search).get('focus')==='search')$('librarySearch').focus();
 rootExport();function rootExport(){window.QingruStudio={openBuilder,addFiles,compile,refreshDrafts,download,toast};}
})();

;
(function(){
 'use strict';
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),animations=new WeakMap();
 const version=new URL(document.currentScript?.src||location.href,location.href).searchParams.get('v');
 function url(value){const u=new URL(value,location.href);if(version&&u.origin===location.origin)u.searchParams.set('ui',version);return u.href;}
 function enter(node,direction=1){if(!node||reduced.matches||typeof node.animate!=='function')return;for(const a of animations.get(node)||[])a.cancel();const options={duration:420,easing:'cubic-bezier(.22,.72,.14,1)'},running=[node.animate([{opacity:.45,transform:'translateX('+direction*18+'px)'},{opacity:1,transform:'translateX(0)'}],options)];const objects=node.matches('.album-stage')?node.querySelectorAll('.album-copy h2,.album-copy>p,.album-numbers,.album-actions'):node.matches('#slide')?node.querySelectorAll('#lessonTitle,#lessonVisual,#stageInteraction'):[];objects.forEach((part,i)=>running.push(part.animate([{opacity:.15,transform:'translateY(9px)'},{opacity:1,transform:'translateY(0)'}],{...options,duration:350,delay:Math.min(i,3)*30,fill:'backwards'})));animations.set(node,running);}
 const closing=new WeakSet();async function dismiss(dialog){if(!dialog?.open||closing.has(dialog))return;if(reduced.matches||typeof dialog.animate!=='function'){dialog.close();return;}closing.add(dialog);const a=dialog.animate([{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(10px)'}],{duration:170,easing:'cubic-bezier(.4,0,.8,.5)',fill:'forwards'});try{await a.finished;}catch{}dialog.close();a.cancel();closing.delete(dialog);}
 window.QingruMotion={enter,url,dismiss};
 document.querySelectorAll('iframe.report-inline').forEach(f=>{if(version)f.src=url(f.getAttribute('src'));});
 document.querySelectorAll('.paper-figure img').forEach(img=>{if(version){const u=new URL(img.src,location.href);u.searchParams.set('v',version);img.src=u.href;}});
 // Native document transitions and compositor-only hover styles replace pointer sampling.
 const prefetched=new Set();let intent=0;
 function target(a){if(!a||a.hasAttribute('download'))return null;const u=new URL(a.href,location.href);return u.origin===location.origin&&/\.html$|\/$/.test(u.pathname)?u:null;}
 function prepare(a){const u=target(a);if(!u)return null;if(version){u.searchParams.set('ui',version);a.href=u.href;}return u;}
 function prefetch(a){const u=prepare(a);if(!u||prefetched.has(u.href)||navigator.connection?.saveData||/2g/.test(navigator.connection?.effectiveType||''))return;prefetched.add(u.href);const l=document.createElement('link');l.rel='prefetch';l.href=u.href;l.as='document';document.head.appendChild(l);}
 document.addEventListener('pointerover',e=>{const a=e.target.closest?.('a[href]');if(!target(a))return;clearTimeout(intent);intent=setTimeout(()=>prefetch(a),95);},{passive:true});
 document.addEventListener('pointerout',e=>{if(e.target.closest?.('a[href]'))clearTimeout(intent);},{passive:true});
 document.addEventListener('focusin',e=>prefetch(e.target.closest?.('a[href]')));
 document.addEventListener('click',e=>prepare(e.target.closest?.('a[href]')),true);
 document.addEventListener('submit',e=>{const f=e.target;if(!version||!f.hasAttribute('action')||(f.method||'get').toLowerCase()!=='get')return;let input=f.querySelector('input[name="ui"]');if(!input){input=document.createElement('input');input.type='hidden';input.name='ui';f.appendChild(input);}input.value=version;},true);
})();

;
(function(){
 'use strict';const stage=document.querySelector('#colourstage');if(!stage)return;
 const panels=[...stage.querySelectorAll('[data-panel]')],fine=matchMedia('(hover:hover) and (pointer:fine)');
 let hovered=null,focused=null;function sync(){stage.dataset.active=(hovered||focused)?.dataset.panel||'';}
 for(const panel of panels){panel.addEventListener('pointerenter',()=>{if(fine.matches){hovered=panel;sync();}});panel.addEventListener('pointerleave',()=>{if(hovered===panel)hovered=null;sync();});panel.addEventListener('focusin',()=>{focused=panel;sync();});panel.addEventListener('focusout',e=>{if(!panel.contains(e.relatedTarget)){focused=null;sync();}});}
 if('IntersectionObserver'in window&&!matchMedia('(prefers-reduced-motion: reduce)').matches){stage.classList.add('motion-armed');panels.forEach((p,i)=>p.querySelector('.panel-copy').style.setProperty('--panel-delay',i*75+'ms'));const observer=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){stage.classList.add('is-in-view');observer.disconnect();}},{threshold:.08});observer.observe(stage);}
 document.addEventListener('visibilitychange',()=>{if(document.hidden){hovered=null;sync();}});
})();

;
(function(){
 'use strict';
 const album=document.getElementById('albumStage');if(album&&!album.hidden)window.QingruMotion?.enter(album);
 const dialog=document.getElementById('builderDialog');if(!dialog)return;
 const close=document.getElementById('closeBuilder');if(close)close.onclick=()=>window.QingruMotion?.dismiss(dialog)||dialog.close();
 dialog.addEventListener('cancel',e=>{if(window.QingruMotion?.dismiss){e.preventDefault();window.QingruMotion.dismiss(dialog);}});
 const drop=dialog.querySelector('[data-file-drop]'),compile=document.getElementById('compileDraft');let dragDepth=0;
 function isFile(e){return [...(e.dataTransfer?.types||[])].includes('Files');}
 if(drop){
  drop.addEventListener('dragenter',e=>{if(!isFile(e))return;e.preventDefault();dragDepth++;drop.classList.add('drag-active');});
  drop.addEventListener('dragover',e=>{if(isFile(e)){e.preventDefault();e.dataTransfer.dropEffect='copy';}});
  drop.addEventListener('dragleave',()=>{dragDepth=Math.max(0,dragDepth-1);if(!dragDepth)drop.classList.remove('drag-active');});
  drop.addEventListener('drop',e=>{if(!isFile(e))return;e.preventDefault();dragDepth=0;drop.classList.remove('drag-active');window.QingruStudio?.addFiles(e.dataTransfer.files);});
 }
 function state(){dialog.classList.toggle('is-building',!compile.hidden&&compile.disabled);dialog.classList.toggle('has-preview',!document.getElementById('builderPreview').hidden);dialog.setAttribute('aria-busy',String(!compile.hidden&&compile.disabled));}
 new MutationObserver(state).observe(dialog,{subtree:true,attributes:true,attributeFilter:['disabled','hidden']});
 dialog.addEventListener('close',()=>{dragDepth=0;drop?.classList.remove('drag-active');});state();
})();

;
/* Adapted to Qingru from the user-supplied model-city-scene entrance. */
(function(){
 'use strict';
 const intro=document.querySelector('.scene-intro'),stage=intro?.querySelector('.brand-scene-stage');if(!stage)return;
 const scene=intro.querySelector('.brand-scene'),copy=intro.querySelector('.brand-scene-copy'),workspace=document.getElementById('workspace');
 const reduced=matchMedia('(prefers-reduced-motion:reduce)'),clamp=v=>Math.max(0,Math.min(1,v));
 const ramp=(p,a,b)=>{const t=clamp((p-a)/(b-a));return t*t*(3-2*t);};
 let start=0,span=1,reading=1,frame=0,last=0,current=0,target=0,entered=false,entry=null,revision=0,resizeTimer=0;
 intro.classList.add('scene-motion-ready');intro.dataset.entrance='waiting';
 function draw(p){
  intro.style.setProperty('--scene-pan',ramp(p,0,.68).toFixed(4));
  intro.style.setProperty('--scene-dusk',ramp(p,.13,.65).toFixed(4));
  intro.style.setProperty('--scene-sunset',ramp(p,.18,.65).toFixed(4));
  intro.style.setProperty('--scene-sun-alpha',(1-ramp(p,.5,.68)).toFixed(4));
  intro.style.setProperty('--scene-night',(reduced.matches?.8:ramp(p,.5,.77)).toFixed(4));
  const reveal=reduced.matches?1:ramp(p,.77,.985);
  intro.style.setProperty('--scene-copy',reveal.toFixed(4));
  intro.dataset.phase=reduced.matches?'static':p<.13?'day':p<.68?'sunset':p<.77?'night':reveal>=.999?'reading':'title';
  intro.dataset.progress=p.toFixed(4);
  document.body.classList.toggle('workspace-in-view',scrollY>start+span+reading*.25);
 }
 function render(now){
  frame=0;if(document.hidden||!entered)return;
  const dt=last?Math.min(48,now-last):16.7;last=now;
  current+=(target-current)*(reduced.matches?1:1-Math.exp(-dt/80));
  if(Math.abs(target-current)<.00008)current=target;
  draw(current);if(current!==target)frame=requestAnimationFrame(render);else last=0;
 }
 function request(){target=reduced.matches?1:clamp((scrollY-start)/span);if(entered&&!frame&&!document.hidden)frame=requestAnimationFrame(render);}
 function measure(){
  const h=stage.offsetHeight;span=Math.max(620,h*1.22);reading=Math.max(230,h*.38);
  intro.style.height=(reduced.matches?h:h+span+reading)+'px';intro.style.setProperty('--scene-sun-drop',h*.28+'px');
  start=intro.getBoundingClientRect().top+scrollY;request();
 }
 function waitForBoot(){return new Promise(resolve=>{
  const ready=()=>!document.documentElement.classList.contains('q-booting')&&!document.documentElement.classList.contains('q-boot-visible');
  if(ready()){resolve();return;}const observer=new MutationObserver(()=>{if(ready()){observer.disconnect();resolve();}});observer.observe(document.documentElement,{attributes:true,attributeFilter:['class']});
 });}
 async function entrance(){
  const version=++revision;
  await Promise.allSettled([waitForBoot(),...Array.from(scene.querySelectorAll('img'),img=>typeof img.decode==='function'?img.decode():Promise.resolve())]);
  if(version!==revision)return;
  if(reduced.matches||typeof scene.animate!=='function'||location.hash==='#workspace'||scrollY>start+span){entered=true;intro.dataset.entrance='settled';current=target;draw(current);request();return;}
  intro.dataset.entrance='playing';entry=scene.animate([
   {clipPath:'inset(8% 49% round 18px)',transform:'scale(.72)',filter:'blur(8px)',opacity:0},
   {clipPath:'inset(0% 0% round 0px)',transform:'scale(1)',filter:'blur(0px)',opacity:1}
  ],{duration:800,easing:'cubic-bezier(.72,0,.16,1)',fill:'both'});
  if(document.hidden)entry.pause();try{await entry.finished;}catch{}
  if(version!==revision)return;intro.dataset.entrance='settled';entry.cancel();entry=null;entered=true;request();
 }
 window.addEventListener('scroll',request,{passive:true});
 window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(measure,150);},{passive:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;last=0;entry?.pause();}else{entry?.play();request();}});
 reduced.addEventListener('change',()=>{revision++;entry?.cancel();entry=null;entered=true;intro.dataset.entrance='settled';measure();current=target;draw(current);});
 window.addEventListener('pagehide',()=>{cancelAnimationFrame(frame);entry?.pause();});
 window.addEventListener('pageshow',event=>{if(event.persisted){entry?.play();measure();request();}});
 window.addEventListener('hashchange',request);
 measure();draw(0);entrance();
 if(location.hash==='#workspace')requestAnimationFrame(()=>{workspace.scrollIntoView({behavior:'instant'});request();});
})();


window.QingruBoot?.ready();
