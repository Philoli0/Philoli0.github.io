window.QINGRU_COURSE_DATA={"title": "市场均衡", "source": "微观经济学.docx", "source_sha256": "c3cc451fcc87f699fd72d1dd1501d59ec7f05a0ec163e6864b97d98f1dc82966", "source_section": "第三节 市场均衡", "source_blocks": [{"id": "b0239", "kind": "paragraph", "style": "4", "text": "第三节 市场均衡", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 239}, {"id": "b0240", "kind": "paragraph", "style": "5", "text": "一、均衡的含义", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 240}, {"id": "b0241", "kind": "paragraph", "style": "", "text": "均衡（Equilibrium）：经济事物中有关的变量在一定条件的相互作用下所达到的一种相对静止的状态。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 241}, {"id": "b0242", "kind": "paragraph", "style": "", "text": "市场均衡：市场上需求与供给两种力量相等时所达到的状态。在均衡状态，买方和卖方都愿意接受且不再有变动倾向。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 242}, {"id": "b0243", "kind": "paragraph", "style": "5", "text": "二、均衡价格和均衡数量", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 243}, {"id": "b0244", "kind": "paragraph", "style": "", "text": "▪ 均衡价格（Equilibrium Price）：一种商品的市场需求量与市场供给量相等时的价格。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 244}, {"id": "b0245", "kind": "paragraph", "style": "", "text": "▪ 均衡数量（Equilibrium Quantity）：在均衡价格水平下的相等的供求数量。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 245}, {"id": "b0246", "kind": "paragraph", "style": "", "text": "▪ 均衡条件：Qd = Qs。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 246}, {"id": "b0247", "kind": "paragraph", "style": "", "text": "当市场价格 高于 均衡价格：供过于求（过剩），价格下降；", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 247}, {"id": "b0248", "kind": "paragraph", "style": "", "text": "当市场价格 低于 均衡价格：供不应求（短缺），价格上升。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 248}, {"id": "b0249", "kind": "paragraph", "style": "", "text": "价格机制自发调节市场趋向均衡——即\"看不见的手\"。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 249}, {"id": "b0250", "kind": "paragraph", "style": "", "text": "均衡解（线性情形）：", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 250}, {"id": "b0251", "kind": "paragraph", "style": "", "text": "设 Qd = α − βP，Qs = −δ + γP，令 Qd = Qs：", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 251}, {"id": "b0252", "kind": "paragraph", "style": "", "text": "▪ P* = (α + δ) / (β + γ)", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 252}, {"id": "b0253", "kind": "paragraph", "style": "", "text": "▪ Q* = α − βP*", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 253}, {"id": "b0254", "kind": "paragraph", "style": "", "text": "表1-7 市场均衡的形成（示例）", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 254}, {"id": "b0255", "kind": "table", "rows": [["价格P", "需求量Qd", "供给量Qs", "市场状态", "价格变动趋势"], ["5", "10", "50", "过剩（供>求）", "下降"], ["4", "20", "40", "过剩", "下降"], ["3", "30", "30", "均衡", "不变"], ["2", "40", "20", "短缺（供<求）", "上升"], ["1", "50", "10", "短缺", "上升"]], "text": "价格P | 需求量Qd | 供给量Qs | 市场状态 | 价格变动趋势\n5 | 10 | 50 | 过剩（供>求） | 下降\n4 | 20 | 40 | 过剩 | 下降\n3 | 30 | 30 | 均衡 | 不变\n2 | 40 | 20 | 短缺（供<求） | 上升\n1 | 50 | 10 | 短缺 | 上升", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 255}, {"id": "b0257", "kind": "paragraph", "style": "", "text": "均衡价格 P* = 3，均衡数量 Q* = 30。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 257}, {"id": "b0258", "kind": "paragraph", "style": "", "text": "图1-2 供求均衡图：需求曲线D与供给曲线S相交于E点，交点对应均衡价格P*和均衡数量Q*。价格高于P*存在过剩（价格下压），低于P*存在短缺（价格上抬）。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 258}, {"id": "b0259", "kind": "paragraph", "style": "", "text": "", "images": ["/courses/microeconomics/media/3f1176b58337e8a89fce.png"], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 259}, {"id": "b0260", "kind": "paragraph", "style": "", "text": "▲ 图1-2 市场均衡的形成", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 260}, {"id": "b0261", "kind": "paragraph", "style": "5", "text": "三、市场均衡的变动", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 261}, {"id": "b0262", "kind": "paragraph", "style": "", "text": "需求或供给变动引起均衡价格和均衡数量变动，规律如下：", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 262}, {"id": "b0263", "kind": "paragraph", "style": "", "text": "1. 需求增加（需求曲线右移）：均衡价格上升，均衡数量增加。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 263}, {"id": "b0264", "kind": "paragraph", "style": "", "text": "2. 需求减少（左移）：均衡价格下降，均衡数量减少。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 264}, {"id": "b0265", "kind": "paragraph", "style": "", "text": "3. 供给增加（供给曲线右移）：均衡价格下降，均衡数量增加。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 265}, {"id": "b0266", "kind": "paragraph", "style": "", "text": "4. 供给减少（左移）：均衡价格上升，均衡数量减少。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 266}, {"id": "b0267", "kind": "paragraph", "style": "", "text": "5. 供求同时变动：结果取决于两种力量的相对大小。同向变动时数量（或价格）确定，价格（或数量）不确定；反向变动时价格确定，数量不确定。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 267}, {"id": "b0268", "kind": "paragraph", "style": "", "text": "表1-8 供求变动对均衡的影响（供求定理）", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 268}, {"id": "b0269", "kind": "table", "rows": [["变动情况", "均衡价格", "均衡数量"], ["需求增加", "↑", "↑"], ["需求减少", "↓", "↓"], ["供给增加", "↓", "↑"], ["供给减少", "↑", "↓"], ["需求增加 + 供给增加", "不确定", "↑"], ["需求增加 + 供给减少", "↑", "不确定"], ["需求减少 + 供给增加", "↓", "不确定"], ["需求减少 + 供给减少", "不确定", "↓"]], "text": "变动情况 | 均衡价格 | 均衡数量\n需求增加 | ↑ | ↑\n需求减少 | ↓ | ↓\n供给增加 | ↓ | ↑\n供给减少 | ↑ | ↓\n需求增加 + 供给增加 | 不确定 | ↑\n需求增加 + 供给减少 | ↑ | 不确定\n需求减少 + 供给增加 | ↓ | 不确定\n需求减少 + 供给减少 | 不确定 | ↓", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 269}, {"id": "b0271", "kind": "paragraph", "style": "5", "text": "四、经济模型的结构", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 271}, {"id": "b0272", "kind": "paragraph", "style": "", "text": "经济模型是经济理论的数学表达，一般由三要素构成：变量、假设、假说。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 272}, {"id": "b0273", "kind": "paragraph", "style": "", "text": "▪ 变量：内生变量（由模型内部决定）与外生变量（由模型外部决定，模型给定量）。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 273}, {"id": "b0274", "kind": "paragraph", "style": "", "text": "▪ 假设：如\"其他条件不变\"（ceteris paribus）假设。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 274}, {"id": "b0275", "kind": "paragraph", "style": "", "text": "▪ 假说：关于经济变量之间关系的陈述，如需求规律。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 275}, {"id": "b0276", "kind": "paragraph", "style": "", "text": "分析方法的层次：", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 276}, {"id": "b0277", "kind": "table", "rows": [["方法", "含义"], ["静态分析", "考察均衡状态本身"], ["比较静态分析", "比较不同条件下的均衡状态"], ["动态分析", "考察均衡的变动过程（含时间因素）"]], "text": "方法 | 含义\n静态分析 | 考察均衡状态本身\n比较静态分析 | 比较不同条件下的均衡状态\n动态分析 | 考察均衡的变动过程（含时间因素）", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 277}, {"id": "b0279", "kind": "paragraph", "style": "5", "text": "五、一个动态经济模型（蛛网模型）", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 279}, {"id": "b0280", "kind": "paragraph", "style": "", "text": "蛛网模型（Cobweb Model）：用动态分析方法考察价格波动对下一期产量的影响。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 280}, {"id": "b0281", "kind": "paragraph", "style": "", "text": "假设：本期产量决定本期价格；本期价格决定下期产量。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 281}, {"id": "b0282", "kind": "paragraph", "style": "", "text": "三种情形：", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 282}, {"id": "b0283", "kind": "paragraph", "style": "", "text": "1. 收敛型蛛网：供给弹性 < 需求弹性 → 波动逐渐收敛于均衡。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 283}, {"id": "b0284", "kind": "paragraph", "style": "", "text": "2. 封闭型蛛网：供给弹性 = 需求弹性 → 形成闭合循环波动。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 284}, {"id": "b0285", "kind": "paragraph", "style": "", "text": "3. 发散型蛛网：供给弹性 > 需求弹性 → 波动离均衡越来越远。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 285}, {"id": "b0286", "kind": "paragraph", "style": "", "text": "适用于农产品等生产周期较长的市场。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 286}, {"id": "b0287", "kind": "paragraph", "style": "", "text": "图1-3 蛛网模型：收敛型（蛛网向内收敛于均衡点）、发散型（蛛网向外发散）、封闭型（蛛网形成闭合环）三种图形。", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 287}, {"id": "b0288", "kind": "paragraph", "style": "", "text": "", "images": ["/courses/microeconomics/media/b58787224ed14b41f0d1.png"], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 288}, {"id": "b0289", "kind": "paragraph", "style": "", "text": "▲ 图1-3 需求变动对均衡的影响（供求定理图示）", "images": [], "chapter_id": "micro-ch02", "section_id": "micro-ch02-s05", "source_position": 289}], "coverage": {"source_blocks": 48, "preserved_blocks": 48, "method": "All selected-unit blocks retained verbatim in source view, including two source images; teaching pages reorganize rather than replace them."}, "faq": [{"id": "shortage", "question": "为什么短缺会推动价格上涨？", "answer": "在其他条件不变且价格能够调整的模型中，低于均衡价格时需求量大于供给量，买方竞争形成涨价压力。价格上升会减少需求量并增加供给量，直到供求数量相等。", "source": "b0248", "audio": "assets/faq-shortage.mp3"}, {"id": "surplus", "question": "为什么价格高了反而卖不完？", "answer": "在其他条件不变时，高于均衡价格会使供给量大于需求量，形成过剩。卖方降价有助于扩大销售并减少供给量，市场向均衡点调整。", "source": "b0247", "audio": "assets/faq-surplus.mp3"}, {"id": "both", "question": "需求和供给同时增加，价格一定上涨吗？", "answer": "不能直接判断。需求增加会推高均衡价格，供给增加会压低均衡价格，价格结果取决于相对幅度；两种变化都会增加均衡数量，所以均衡数量增加。", "source": "b0269", "audio": "assets/faq-both.mp3"}, {"id": "equilibrium", "question": "均衡价格是政府规定的价格吗？", "answer": "本单元所说的均衡价格，是市场需求量与市场供给量相等时的价格。它是模型中的供求交点；政府规定的价格可能高于、低于或者恰好等于这个价格。", "source": "b0244", "audio": "assets/faq-equilibrium.mp3"}, {"id": "cobweb", "question": "蛛网模型为什么会收敛或者发散？", "answer": "蛛网模型区分当期价格与下一期供给。在本单元的线性模型中，价格偏离均衡的传递倍数，是供给反应系数与需求反应系数之比的负值。其绝对值小于一时收敛，等于一时持续等幅波动，大于一时发散。", "source": "b0280", "audio": "assets/faq-cobweb.mp3"}, {"id": "movement", "question": "价格变化和需求变化有什么区别？", "answer": "其他条件不变时，商品自身价格变化对应沿原曲线的数量调整。收入、偏好等条件改变会使需求曲线整体移动，进而改变均衡价格和均衡数量。", "source": "b0263", "audio": "assets/faq-movement.mp3"}], "lessons": [{"id": "opening", "title": "从一杯奶茶开始", "short": "看见供求", "sources": ["b0242", "b0247", "b0248"], "body": "同一杯奶茶，有时排队，有时卖不完。先比较同一价格下，消费者愿意并能够买多少，商家愿意并能够卖多少。", "section_id": "equilibrium", "section_title": "市场均衡"}, {"id": "definition", "title": "什么是市场均衡", "short": "明确条件", "sources": ["b0241", "b0242", "b0244", "b0245", "b0246"], "body": "在给定条件下，市场需求量等于市场供给量。交点对应均衡价格与均衡数量；均衡不等于价格永远不变，也不等于社会福利在任何条件下都达到最优。", "section_id": "equilibrium", "section_title": "市场均衡"}, {"id": "table", "title": "把材料中的表格读懂", "short": "读表定位", "sources": ["b0254", "b0255", "b0257"], "body": "原材料给定五组价格。价格为3时，供求数量均为30；价格为4时过剩20；价格为2时短缺20。数量的单位与统计期间须在实际案例中统一。", "section_id": "equilibrium", "section_title": "市场均衡"}, {"id": "adjustment", "title": "价格如何向均衡调整", "short": "交互推演", "sources": ["b0247", "b0248", "b0249", "b0258", "b0259", "b0260"], "body": "在其他条件不变、价格可以调整且竞争机制发挥作用的模型中，过剩形成降价压力，短缺形成涨价压力。这里描述的是沿既有曲线的数量调整。", "section_id": "equilibrium", "section_title": "市场均衡"}, {"id": "linear", "title": "用一个方程算出均衡", "short": "理解模型", "sources": ["b0250", "b0251", "b0252", "b0253"], "body": "令需求量等于供给量，联立线性需求函数与供给函数。原材料中的数表对应一个可行示例：Qd=60−10P，Qs=10P，得到P*=3、Q*=30。该函数是与表格一致的教学拟合，不是原文另给的经验估计。", "section_id": "equilibrium", "section_title": "市场均衡"}, {"id": "shifts", "title": "曲线移动会改变什么", "short": "条件改变", "sources": ["b0261", "b0262", "b0263", "b0264", "b0265", "b0266"], "body": "自身价格变化对应沿曲线移动；收入、偏好、生产成本等条件改变，可能使需求或供给曲线整体移动。单边变化时，四种方向分别判断。", "section_id": "equilibrium", "section_title": "市场均衡"}, {"id": "both", "title": "同时变化为何不能凭直觉", "short": "辨析误区", "sources": ["b0267", "b0268", "b0269"], "body": "需求与供给同时增加时，均衡数量增加，价格不确定；同时减少时，数量减少，价格不确定。需求增且供给减时，价格上升、数量不确定；需求减且供给增时，价格下降、数量不确定。", "section_id": "equilibrium", "section_title": "市场均衡"}, {"id": "model", "title": "结论依赖哪些假设", "short": "模型边界", "sources": ["b0271", "b0272", "b0273", "b0274", "b0275", "b0276", "b0277"], "body": "经济模型由变量、假设和假说组织起来。模型内部决定的是内生变量，给定条件是外生变量。静态分析看一个均衡，比较静态看不同均衡，动态分析研究随时间变化的过程。", "section_id": "equilibrium", "section_title": "市场均衡"}, {"id": "cobweb", "title": "把时间放进模型", "short": "动态延伸", "sources": ["b0279", "b0280", "b0281", "b0282", "b0283", "b0284", "b0285", "b0286", "b0287", "b0288", "b0289"], "body": "蛛网模型假定本期产量影响本期价格，本期价格影响下期产量。在线性、一期滞后且每期出清的设定下，供给反应与需求反应的比值决定收敛、等幅或发散。原文对图1-3的蛛网文字说明与实际需求移动图片不一致，因此本页按正文重绘动态示意，并保留原图对照。", "section_id": "equilibrium", "section_title": "市场均衡"}, {"id": "quiz", "title": "把结论用到新情境", "short": "测验巩固", "sources": ["b0247", "b0248", "b0269", "b0277", "b0283"], "body": "先判断条件，再判断曲线，最后讨论价格和数量。完成题目后，可以查看解释与原文依据，也可以带着当前问题继续追问。", "section_id": "equilibrium", "section_title": "市场均衡"}], "quizzes": [{"q": "材料表中，价格4、需求量20、供给量40，市场出现什么？", "options": ["短缺20，价格有上涨压力", "过剩20，价格有下降压力", "均衡，因为商家能生产40"], "answer": 1, "why": "供给量减去需求量为20，形成过剩。在既定模型条件下，卖方竞争带来降价压力。", "source": "b0247"}, {"q": "需求与供给同时增加，可以确定什么？", "options": ["均衡价格一定上升", "均衡数量增加，价格不能直接确定", "均衡价格与数量都不变"], "answer": 1, "why": "两种变化均推高均衡数量，但对价格作用相反，需比较相对幅度。", "source": "b0269"}, {"q": "其他条件不变，商品自身价格下降，通常对应什么？", "options": ["沿既有需求曲线移动", "需求曲线自动右移", "供给曲线自动左移"], "answer": 0, "why": "这里变化的是价格，需求与供给的非价格条件没有改变，因此首先分析沿原曲线的数量变化。", "source": "b0258"}, {"q": "比较成本降低前后两个均衡点，属于什么方法？", "options": ["只有静态分析", "比较静态分析", "必然是蛛网动态分析"], "answer": 1, "why": "比较静态分析比较不同给定条件下的均衡结果，不自动描述调整路径与时间。", "source": "b0277"}, {"q": "在线性一期滞后的蛛网设定下，供给反应系数与需求反应系数之比为0.6时？", "options": ["偏离逐步收敛", "必然发散", "保持等幅"], "answer": 0, "why": "价格偏离的逐期传递倍数为−0.6，绝对值小于1，因此偏离幅度逐渐减小。", "source": "b0283"}], "demo_chapters": [{"title": "一份材料，走向一次理解", "time": 0}, {"title": "数字讲师精讲", "time": 60.0}, {"title": "把供求关系调出来", "time": 122.4}, {"title": "带着卡点继续追问", "time": 187.20000000000002}, {"title": "把人物、声音与课件连起来", "time": 247.20000000000002}], "lecture": {"url": "assets/market-equilibrium.mp4", "duration": 61.76, "script": "为什么同一杯奶茶，有时排队，有时卖不完？关键是价格与供求是否匹配。市场均衡，是同一价格下，需求量与供给量相等。请看材料中的表格。价格3元时，需求量和供给量都是30，均衡点就在这里。价格4元时，需求量20，供给量40，多出的20形成过剩，价格有下降压力。价格2元时，需求量40，供给量20，短缺20，价格有上升压力。这里讨论的是其他条件不变时，沿原曲线的调整。如果收入、偏好或者生产成本改变，曲线会移动，均衡点也会改变。所以，读图时先判断变化的是价格，还是需求与供给的条件。最后想一想，需求与供给同时增加，均衡数量会上升，但价格为什么不能直接判断？", "voice_profile": "qingru-approved-fullcontext-v42", "image_sha256": "702136c895cf3b70aa44e565b15262c6a890ec8126f2faf8c51400e371585820", "sha256": "964f5d7b9bdca566d60ef708499327c2b5a68f2a325258e33edd7c4ec2df9836", "cues": [{"index": 0, "start": 0, "anchor": "为什么同一杯奶茶", "end": 7.33}, {"index": 1, "start": 7.33, "anchor": "市场均衡", "end": 15.21}, {"index": 2, "start": 15.21, "anchor": "价格三元时", "end": 21.95}, {"index": 3, "start": 21.95, "anchor": "价格四元时", "end": 30.77}, {"index": 4, "start": 30.77, "anchor": "价格二元时", "end": 42.39}, {"index": 5, "start": 42.39, "anchor": "如果收入", "end": 54.79}, {"index": 6, "start": 54.79, "anchor": "最后想一想", "end": 61.76}]}, "id": "market-equilibrium", "kind": "curated", "teacher": "qingru", "sections": [{"id": "equilibrium", "title": "市场均衡", "lesson_ids": ["opening", "definition", "table", "adjustment", "linear", "shifts", "both", "model", "cobweb", "quiz"]}]};
;
(function(root){
 'use strict';let opening;const CACHE=new Map(),DB='qingru-teaching-studio',VERSION=1;
 function database(){if(!opening)opening=new Promise((resolve,reject)=>{if(!root.indexedDB){reject(Error('当前浏览器不能保存课堂，请使用普通浏览器窗口。'));return;}const r=indexedDB.open(DB,VERSION);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('courses'))r.result.createObjectStore('courses',{keyPath:'id'});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});return opening;}
 async function op(mode,work){const db=await database();return new Promise((resolve,reject)=>{const tx=db.transaction('courses',mode),store=tx.objectStore('courses');let value;const req=work(store);req.onsuccess=()=>{value=req.result;};tx.oncomplete=()=>resolve(value);tx.onerror=()=>reject(tx.error||req.error);tx.onabort=()=>reject(tx.error||Error('保存未完成'));});}
 const Store={async put(course){await op('readwrite',s=>s.put(course));CACHE.set(course.id,course);return course;},async get(id){if(CACHE.has(id))return CACHE.get(id);const c=await op('readonly',s=>s.get(id));if(c)CACHE.set(id,c);return c;},async list(){return(await op('readonly',s=>s.getAll())).sort((a,b)=>b.created_at.localeCompare(a.created_at));},async remove(id){await op('readwrite',s=>s.delete(id));CACHE.delete(id);},async updatePage(id,page){const c=await this.get(id);if(c){c.last_page=page;await this.put(c);}}};
 root.QingruStore=Store;
})(globalThis);

;
/* Qingru material parser and deterministic teaching draft compiler.
 * The original blocks stay intact; extracted summaries never replace sources.
 */
(function(root){
 'use strict';
 const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const clean=s=>String(s??'').replace(/\r/g,'').replace(/[\t\u00a0]+/g,' ').replace(/ +/g,' ').trim();
 const shorten=(s,n=50)=>{s=clean(s);return s.length>n?s.slice(0,n-1)+'…':s;};
 const sentences=s=>String(s).split(/(?<=[。！？；\n])/).map(clean).filter(Boolean);
 const texts=node=>Array.from(node?.getElementsByTagNameNS('*','t')||[]).map(n=>n.textContent).join('');
 function xml(s){const d=new DOMParser().parseFromString(s,'application/xml');if(d.getElementsByTagName('parsererror').length)throw Error('文件中的XML内容无法解析。');return d;}
 function math(n){if(!n)return'';const key=n.localName,els=Array.from(n.children||[]),part=k=>els.find(c=>c.localName===k);if(key==='f')return'('+math(part('num'))+')/('+math(part('den'))+')';if(key==='sSup')return math(part('e'))+'^('+math(part('sup'))+')';if(key==='sSub')return math(part('e'))+'_('+math(part('sub'))+')';if(key==='t')return n.textContent;return els.map(math).join('');}
 function paragraph(node){let result='';function walk(n){if(n.nodeType!==1)return;const k=n.localName;if(k==='oMath'||k==='oMathPara'){result+=math(n);return;}if(k==='t'){result+=n.textContent;return;}if(k==='tab')result+=' ';else if(k==='br')result+='\n';else for(const c of n.children)walk(c);}walk(node);return clean(result);}
 const heading=s=>s.length<90&&(/^(第[一二三四五六七八九十百\d]+[章节篇部分]|[一二三四五六七八九十]+[、．.]|\d+(?:\.\d+){0,3}[、.\s])/u.test(s)||/^(导论|绪论|课程说明|学习目标|本章小结|知识总结|案例分析|思考题|练习题)$/.test(s));
 function classify(block){const t=block.text||'';if(block.kind==='table')return'table';if(block.kind==='image')return'image';if(heading(t))return'heading';if(/[=＝]|[αβγδΔ]/.test(t)&&t.length<200)return'formula';if(/步骤|首先|其次|第一步|第二步/.test(t))return'steps';if(/条件|假设|适用|除非|其他.*不变/.test(t))return'condition';if(/案例|例如|假设.*元|示例/.test(t))return'example';return'concept';}
 function packText(name,text){const blocks=text.split(/\n+/).map(clean).filter(Boolean).map((text,i)=>({id:'p'+(i+1),kind:'paragraph',text,style:heading(text)?'heading':''}));if(!blocks.length)throw Error('没有读取到可用文字，请检查文件内容。');return{name,blocks};}
 let zipReady=null;
 async function loadZip(){if(root.fflate)return;if(!zipReady)zipReady=new Promise((resolve,reject)=>{const s=document.createElement('script');s.src='vendor/fflate/umd/index.js';s.onload=resolve;s.onerror=()=>{s.remove();zipReady=null;reject(Error('文件解析组件未能加载，请再次选择材料。'));};document.head.appendChild(s);});await zipReady;}
 async function parseFile(file,progress=()=>{}){
  const ext=file.name.split('.').pop().toLowerCase();if(file.size>20*1024*1024)throw Error('单个文件请控制在20MB以内。');progress('正在读取 '+file.name);
  if(['txt','md'].includes(ext)){const bytes=new Uint8Array(await file.arrayBuffer());let text=new TextDecoder('utf-8').decode(bytes);if(text.includes('\ufffd'))text=new TextDecoder('gb18030').decode(bytes);return packText(file.name,text);}
  if(ext==='pdf'){
   if(location.protocol==='file:')throw Error('PDF请在网页访问地址中导入；离线直接打开时可使用DOCX、PPTX或TXT。');
   const pdf=await import('./vendor/pdfjs-dist/build/pdf.mjs?v=6.5.438');pdf.GlobalWorkerOptions.workerSrc=new URL('./vendor/pdfjs-dist/build/pdf.worker.mjs?v=6.5.438',location.href).href;
   const loading=pdf.getDocument({data:new Uint8Array(await file.arrayBuffer()),isEvalSupported:false,cMapUrl:new URL('./vendor/pdfjs-dist/cmaps/',location.href).href,cMapPacked:true,standardFontDataUrl:new URL('./vendor/pdfjs-dist/standard_fonts/',location.href).href,wasmUrl:new URL('./vendor/pdfjs-dist/wasm/',location.href).href}),doc=await loading.promise;
   const blocks=[];try{for(let i=1;i<=doc.numPages;i++){progress('解析PDF '+i+' / '+doc.numPages+'页');const p=await doc.getPage(i),c=await p.getTextContent();let line='',lastY=null;for(const item of c.items){if(!item.str)continue;const y=item.transform?.[5];if(lastY!==null&&Math.abs(y-lastY)>3&&line){blocks.push({kind:'paragraph',text:clean(line),page:i});line='';}line+=item.str+(item.hasEOL?'\n':' ');lastY=y;}if(clean(line))blocks.push({kind:'paragraph',text:clean(line),page:i});p.cleanup();}}finally{await loading.destroy();}
   if(!blocks.length)throw Error('此PDF未包含可提取文字，可能是扫描件。请使用带文字层的PDF或DOCX。');return{name:file.name,blocks};
  }
  if(!['docx','pptx'].includes(ext))throw Error('请导入DOCX、PPTX、文字型PDF、TXT或Markdown文件。');
  await loadZip();
  let total=0;const entries=root.fflate.unzipSync(new Uint8Array(await file.arrayBuffer()),{filter:f=>{const include=ext==='docx'?/^word\/(document\.xml|styles\.xml|_rels\/document\.xml\.rels|media\/)/.test(f.name):/^ppt\/slides\/slide\d+\.xml$/.test(f.name);if(include){total+=f.originalSize;if(total>80*1024*1024)throw Error('解压后的材料过大，请拆分章节后导入。');}return include;}});
  const blocks=[];
  if(ext==='docx'){
   if(!entries['word/document.xml'])throw Error('DOCX文件缺少正文。');const doc=xml(root.fflate.strFromU8(entries['word/document.xml'])),body=doc.getElementsByTagNameNS('*','body')[0];
   const ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main',levels=new Map();if(entries['word/styles.xml'])for(const s of xml(root.fflate.strFromU8(entries['word/styles.xml'])).getElementsByTagNameNS('*','style')){const name=s.getElementsByTagNameNS('*','name')[0]?.getAttributeNS(ns,'val')||'',outline=s.getElementsByTagNameNS('*','outlineLvl')[0]?.getAttributeNS(ns,'val'),match=name.match(/(?:heading|标题)\s*([1-6])/i);if(outline!==undefined&&Number(outline)<6)levels.set(s.getAttributeNS(ns,'styleId'),Number(outline)+1);else if(match)levels.set(s.getAttributeNS(ns,'styleId'),Number(match[1]));}
   const rels=new Map();if(entries['word/_rels/document.xml.rels'])for(const r of xml(root.fflate.strFromU8(entries['word/_rels/document.xml.rels'])).getElementsByTagName('Relationship'))rels.set(r.getAttribute('Id'),r.getAttribute('Target'));
   for(const node of body.children){
    if(node.localName==='p'){const text=paragraph(node),style=node.getElementsByTagNameNS('*','pStyle')[0]?.getAttributeNS(ns,'val')||'';if(text)blocks.push({kind:'paragraph',text,style,heading_level:levels.get(style)||null});
     for(const image of node.getElementsByTagNameNS('*','blip')){const id=image.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','embed'),target=rels.get(id),bytes=entries['word/'+target];if(bytes&&bytes.length<4*1024*1024&&/\.(png|jpe?g|webp)$/i.test(target)){let binary='';for(let at=0;at<bytes.length;at+=8192)binary+=String.fromCharCode(...bytes.subarray(at,at+8192));const mime=/\.png$/i.test(target)?'image/png':/\.webp$/i.test(target)?'image/webp':'image/jpeg';blocks.push({kind:'image',text:'原文插图',images:['data:'+mime+';base64,'+btoa(binary)]});}}
    }else if(node.localName==='tbl'){const rows=Array.from(node.children).filter(n=>n.localName==='tr').map(row=>Array.from(row.children).filter(n=>n.localName==='tc').map(c=>Array.from(c.getElementsByTagNameNS('*','p')).map(paragraph).join('\n')));if(rows.length)blocks.push({kind:'table',rows,text:rows.map(r=>r.join(' | ')).join('\n')});}
   }
  }else{
   const keys=Object.keys(entries).sort((a,b)=>Number(a.match(/slide(\d+)/)[1])-Number(b.match(/slide(\d+)/)[1]));for(const[keyIndex,key]of keys.entries()){const doc=xml(root.fflate.strFromU8(entries[key])),parts=Array.from(doc.getElementsByTagNameNS('*','p')).map(texts).map(clean).filter(Boolean);parts.forEach((text,i)=>blocks.push({kind:'paragraph',text,style:i===0?'heading':'',heading_level:i===0?1:null,page:keyIndex+1}));}
  }
  if(!blocks.length)throw Error('没有读取到文字或表格，请确认文件有效。');return{name:file.name,blocks};
 }
 function compile(materials,title){
  if(!materials.length)throw Error('请先导入材料。');let n=0;const blocks=materials.flatMap(m=>m.blocks.map(b=>({...b,id:'src-'+(++n),source_name:m.name})));if(n>20000)throw Error('材料超过本次可处理规模，请按章节分开创建。');
  const groups=[];let current={title:title||materials[0].name.replace(/\.[^.]+$/,''),blocks:[]};
  for(const b of blocks){const t=b.text||'',isHeading=b.heading_level?b.heading_level<=2:t.length<90&&(/^(第[一二三四五六七八九十百\d]+[章节篇部分])/u.test(t)||/^(导论|绪论|课程说明|学习目标|本章小结|知识总结|案例分析|思考题|练习题)$/.test(t));if(isHeading&&current.blocks.length){groups.push(current);current={title:shorten(t,65),blocks:[]};}else if(isHeading&&!current.blocks.length)current.title=shorten(t,65);current.blocks.push(b);}if(current.blocks.length)groups.push(current);
  const lessons=[],sections=[],quizzes=[];
  groups.forEach((g,i)=>{const sid='section-'+(i+1),parts=[];let chunk=[],size=0;for(const b of g.blocks){const len=(b.text||'').length;if(chunk.length&&(size+len>750||chunk.length>=5)){parts.push(chunk);chunk=[];size=0;}chunk.push(b);size+=len;}if(chunk.length)parts.push(chunk);const section={id:sid,title:g.title,chapter_title:'导入材料',lesson_ids:[]};
   parts.forEach((bs,k)=>{const meaningful=bs.filter(b=>b.kind!=='image'&&classify(b)!=='heading'&&!b.heading_level),text=meaningful.map(b=>b.text||'').join('\n'),type=bs.some(b=>b.kind==='table')?'table':bs.some(b=>classify(b)==='formula')?'formula':bs.some(b=>classify(b)==='steps')?'steps':'reading';const id=sid+'-page-'+(k+1);lessons.push({id,title:g.title+(parts.length>1?' · '+(k+1):''),short:g.title,section_id:sid,section_title:g.title,body:sentences(text).slice(0,2).join('')||'阅读本节原文，核对概念与条件。',sources:bs.map(b=>b.id),blocks:bs,layout:type});section.lesson_ids.push(id);});sections.push(section);
   const sentence=g.blocks.flatMap(b=>sentences(b.text||'')).find(s=>s.length>=18&&s.length<=110&&/[是指为]|表示|取决于|需要/.test(s));if(sentence&&quizzes.length<12)quizzes.push({section_id:sid,q:'根据“'+g.title+'”的原文，哪项表述有材料依据？',options:[sentence,'本段结论在任何条件下都必然成立。','原文并未给出相关概念或判断依据。'],answer:0,why:'原文表述为：“'+sentence+'”请结合该段条件理解。',source:g.blocks.find(b=>(b.text||'').includes(sentence))?.id||g.blocks[0].id});
  });
  const summary=sections.map(s=>({title:s.title,text:lessons.filter(p=>p.section_id===s.id).flatMap(p=>sentences(p.body)).slice(0,2).join('')}));
  return{id:'draft-'+Date.now().toString(36),kind:'document',title:clean(title)||materials[0].name.replace(/\.[^.]+$/,''),source:materials.map(m=>m.name).join('、'),source_section:'导入材料',source_blocks:blocks,lessons,sections,quizzes,faq:[],summary,coverage:{preserved_blocks:blocks.length,source_blocks:blocks.length},materials:materials.map(m=>({name:m.name,blocks:m.blocks.length})),created_at:new Date().toISOString(),teacher:'qingru',media_state:'awaiting-production',compiler:'qingru-source-preserving-draft-v1'};
 }
 const table=rows=>'<div class="table-scroll"><table class="data-table"><thead><tr>'+rows[0].map(c=>'<th>'+escape(c)+'</th>').join('')+'</tr></thead><tbody>'+rows.slice(1).map(r=>'<tr>'+r.map(c=>'<td>'+escape(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';
 function details(lesson){return'<div class="source-reading">'+(lesson.blocks||[]).map(b=>b.rows?table(b.rows):b.kind==='image'?(b.images||[]).map(src=>'<img src="'+escape(src)+'" alt="原文插图">').join(''):'<p class="'+(classify(b)==='formula'?'math-line':'')+'">'+escape(b.text)+'</p>').join('')+'</div>';}
 function visual(lesson){const blocks=lesson.blocks||[],label={table:'表格读解',formula:'公式与关系',steps:'推理步骤',reading:'概念与条件'}[lesson.layout]||'知识讲解';const words=blocks.filter(b=>!b.rows&&b.kind!=='image').flatMap(b=>sentences(b.text)).filter(s=>s!==lesson.short).slice(0,3);return'<span class="lesson-type">'+label+'</span><div class="reading-points">'+words.map(s=>'<p>'+escape(shorten(s,48))+'</p>').join('')+'</div>';}
 function unpack(text){
  const p=JSON.parse(text),c=p.course;
  if(p.format!=='qingru-classroom-package-v1'||!c||c.kind!=='document'||typeof c.title!=='string'||!Array.isArray(c.source_blocks)||!Array.isArray(c.lessons)||!Array.isArray(c.sections)||!Array.isArray(c.quizzes)||!c.lessons.length||c.lessons.length>20000||c.source_blocks.length>20000)throw Error('这不是有效的清如课堂包，请选择导出的.qingru.json文件。');
  const validBlock=b=>b&&typeof b.id==='string'&&typeof b.text==='string'&&(!b.rows||Array.isArray(b.rows)&&b.rows.every(r=>Array.isArray(r)&&r.every(v=>typeof v==='string')))&&(!b.images||Array.isArray(b.images)&&b.images.every(v=>typeof v==='string'&&/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v)));
  if(!c.source_blocks.every(validBlock)||!c.lessons.every(l=>l&&typeof l.id==='string'&&typeof l.title==='string'&&typeof l.body==='string'&&Array.isArray(l.sources)&&Array.isArray(l.blocks)&&l.blocks.every(validBlock))||!c.sections.every(s=>s&&typeof s.id==='string'&&typeof s.title==='string'&&Array.isArray(s.lesson_ids))||!c.quizzes.every(q=>q&&typeof q.q==='string'&&typeof q.why==='string'&&Array.isArray(q.options)&&q.options.every(v=>typeof v==='string')&&Number.isInteger(q.answer)&&q.answer>=0&&q.answer<q.options.length))throw Error('课堂包内容不完整，请重新导出后导入。');
  c.id='draft-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6);c.created_at=new Date().toISOString();c.media_state='awaiting-production';c.teacher='qingru';delete c.lecture;c.faq=[];return c;
 }
 root.QingruContent={escape,clean,shorten,parseFile,packText,compile,details,visual,classify,heading,unpack};
})(globalThis);

;
window.QingruLibrary={loaded:{},courses:[{"id": "market-equilibrium", "title": "市场均衡", "category": "微观经济学", "description": "从同一杯奶茶的供求关系，理解均衡、价格调整与条件变化。数字讲师精讲与动态供求图已经就绪。", "pages": 10, "sections": 1, "quiz_count": 5, "status": "ready", "cover": "equilibrium", "url": "classroom.html", "data": "course-data.js"}, {"id": "microeconomics", "title": "微观经济学", "category": "资料课堂", "description": "从导论到市场失灵，按章节阅读教材、图表、例题与练习。原文依据与知识小结相互连接。", "pages": 722, "sections": 127, "quiz_count": 53, "status": "reading", "cover": "microeconomics", "url": "classroom.html?course=microeconomics", "data": "courses/microeconomics.js"}, {"id": "business-topics", "title": "经管应用专题", "category": "资料课堂", "description": "围绕机会成本、边际分析、投资与管理决策等主题，组织概念、案例、误区和练习。", "pages": 120, "sections": 24, "quiz_count": 24, "status": "reading", "cover": "business", "url": "classroom.html?course=business-topics", "data": "courses/business-topics.js"}]};
;
(function(){
 'use strict';const $=id=>document.getElementById(id),esc=QingruContent.escape;let materials=[],built=null,busy=false;const Library=window.QingruLibrary;
 function toast(s){const el=$('siteToast');if(!el)return;el.textContent=s;el.hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.hidden=true,5500);}
 const bookCover=(c)=>`<svg viewBox="0 0 640 360" role="img" aria-label="${esc(c.title)}教材封面"><rect width="640" height="360" fill="none"/><path d="M118 82Q220 51 318 83V299Q216 269 118 299Z" fill="#f6f9ee" stroke="#779465" stroke-width="2"/><g class="book-page-right"><path d="M318 83Q421 51 523 82V299Q421 269 318 299Z" fill="#d7e4b9" stroke="#779465" stroke-width="2"/><path d="M353 244V130M353 244H484M363 222Q399 153 475 141" fill="none" stroke="#38583a" stroke-width="3"/><circle cx="416" cy="168" r="5" fill="#38583a"/></g><path d="M152 121H270M152 147H259M152 173H277M152 199H247M152 225H271" stroke="#9db68d" stroke-width="5"/><path d="M318 84V300" stroke="#66835a" stroke-width="3"/><path d="M204 79V116L218 106L232 116V76" fill="#91ab75"/></svg>`;
 const cover=(c)=>c.id==='microeconomics'?bookCover(c):`<svg viewBox="0 0 640 360" aria-label="${esc(c.title)}课程封面" role="img"><rect width="640" height="360" fill="${c.cover==='business'?'none':'none'}"/><path d="M70 292V70M70 292H550" fill="none" stroke="#8ba37c" stroke-width="2"/>${c.cover==='business'?'<rect x="120" y="186" width="70" height="106" rx="4" fill="#94b078"/><rect x="235" y="141" width="70" height="151" rx="4" fill="#688b54"/><rect x="350" y="89" width="70" height="203" rx="4" fill="#385d33"/>':'<path d="M90 95L480 290M90 290L480 95" stroke="#38583a" stroke-width="4" fill="none"/><circle cx="285" cy="193" r="8" fill="#38583a" stroke="white" stroke-width="3"/>'}<text x="490" y="70" text-anchor="end" fill="#627953" font-size="21" font-family="Microsoft YaHei">${c.cover==='business'?'案例与决策':'概念与关系'}</text></svg>`;
 function card(c){return'<a class="course-card" href="'+esc(c.url)+'"><div class="card-cover">'+cover(c)+'</div><div class="card-copy"><span class="badge '+(c.status==='ready'?'':'reading')+'">'+(c.status==='ready'?'数字讲师精讲':'资料课堂 · 可阅读')+'</span><h3>'+esc(c.title)+'</h3><p>'+esc(c.description.split('。')[0])+'</p><div class="card-meta"><span>'+c.sections+'个知识单元 · '+c.pages+'页课件</span><span>'+c.quiz_count+'组练习</span></div></div></a>';}
 function state(s){if($('builderState'))$('builderState').textContent=s;}
 function reset(){materials=[];built=null;$('draftTitle').value='';$('materialText').value='';$('materialInput').value='';$('pasteField').hidden=true;$('builderPreview').hidden=true;$('builderIntro').hidden=false;$('compileDraft').hidden=false;$('compileDraft').disabled=false;$('openDraft').hidden=true;$('exportDraft').hidden=true;state('');renderMaterials();}
 function openBuilder(){if(busy)return;reset();$('builderDialog').showModal();$('draftTitle').focus();}
 function renderMaterials(){if(!$('materialList'))return;$('materialList').innerHTML=materials.map((m,i)=>'<div class="material-item"><span>'+esc(m.name)+'<small>'+m.blocks.length+'个原文块已读取</small></span><button type="button" data-remove="'+i+'" aria-label="移除'+esc(m.name)+'">×</button></div>').join('');for(const b of $('materialList').querySelectorAll('[data-remove]'))b.onclick=()=>{materials.splice(Number(b.dataset.remove),1);built=null;renderMaterials();};}
 async function addFiles(files){if(busy)return;const list=Array.from(files);if(materials.length+list.length>8){state('每次课堂最多导入8份材料。');return;}busy=true;$('compileDraft').disabled=true;$('addFiles').disabled=true;
  try{if(list.some(f=>f.name.endsWith('.qingru.json'))){if(list.length!==1||materials.length)throw Error('请单独选择一个清如课堂包。');const f=list[0];if(f.size>20*1024*1024)throw Error('课堂包请控制在20MB以内。');built=QingruContent.unpack(await f.text());await QingruStore.put(built);$('draftTitle').value=built.title;present(built);state('课堂包已导入，可以继续学习。');await refreshDrafts();return;}for(const f of list){const value=await QingruContent.parseFile(f,state);materials.push(value);if(!$('draftTitle').value)$('draftTitle').value=f.name.replace(/\.[^.]+$/,'');renderMaterials();}state('材料已读取。');}catch(e){state(e.message||'材料读取失败，请换一份文件重试。');}finally{busy=false;$('compileDraft').disabled=false;$('addFiles').disabled=false;}
 }
 async function compile(){if(busy)return;busy=true;$('compileDraft').disabled=true;state('正在梳理知识结构与课堂页面…');try{await new Promise(requestAnimationFrame);const source=[...materials],extra=$('materialText').value.trim();if(extra)source.push(QingruContent.packText('补充文字',extra));built=QingruContent.compile(source,$('draftTitle').value);await QingruStore.put(built);present(built);state('课件草稿已保存。');await refreshDrafts();}catch(e){state(e.message||'生成未完成，请重试。');}finally{busy=false;$('compileDraft').disabled=false;}}
 function present(c){$('previewCount').textContent=c.sections.length+'个知识单元 · '+c.lessons.length+'页课堂草稿';$('previewOutline').innerHTML=c.sections.map(s=>'<li>'+esc(s.title)+'<small>'+s.lesson_ids.length+'页 · 原文可核对</small></li>').join('');$('builderPreview').hidden=false;$('builderIntro').hidden=true;$('compileDraft').hidden=true;$('openDraft').href='classroom.html?draft='+encodeURIComponent(c.id);$('openDraft').hidden=false;$('exportDraft').hidden=false;}
 function download(course){const blob=new Blob([JSON.stringify({format:'qingru-classroom-package-v1',course},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=course.title.replace(/[\\/:*?"<>|]/g,'_')+'.qingru.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}
 async function refreshDrafts(){let drafts=[];try{drafts=await QingruStore.list();}catch(e){if($('recentDrafts'))$('recentDrafts').textContent='当前浏览器未开放本地存储，已发布课堂仍可使用。';return;}
  if(document.querySelector('.workbench-foot .recent-disclosure'))document.querySelector('.workbench-foot .recent-disclosure').hidden=!drafts.length;
  if($('recentDrafts')&&drafts.length)$('recentDrafts').innerHTML='<div class="recent-head"><h2>最近创建的课堂</h2><a href="courses.html?filter=draft">查看全部草稿</a></div>'+drafts.slice(0,3).map(d=>draftRow(d)).join('');
  if($('draftList')){const q=$('librarySearch').value.trim().toLowerCase(),filtered=drafts.filter(d=>d.title.toLowerCase().includes(q));$('draftList').innerHTML=filtered.map(draftRow).join('');$('draftList').hidden=filter!=='draft';if(filter==='draft'){$('libraryEmpty').hidden=filtered.length>0;}}
  for(const b of document.querySelectorAll('[data-export-draft]'))b.onclick=async()=>download(await QingruStore.get(b.dataset.exportDraft));
  for(const b of document.querySelectorAll('[data-delete-draft]'))b.onclick=async()=>{const d=await QingruStore.get(b.dataset.deleteDraft);if(d&&confirm('删除“'+d.title+'”的本地草稿？导出的课堂包不受影响。')){await QingruStore.remove(d.id);refreshDrafts();}};
 }
 function draftRow(d){return'<article class="draft-row"><div><h3>'+esc(d.title)+'</h3><p>'+d.lessons.length+'页课件 · '+d.source_blocks.length+'个来源块 · 讲解视频待制作</p></div><a class="button" href="classroom.html?draft='+encodeURIComponent(d.id)+'">进入课堂</a><button class="button text" data-export-draft="'+esc(d.id)+'">导出</button><button class="button text" data-delete-draft="'+esc(d.id)+'">删除</button></article>';}
 let searchTimer=0;
 let filter=new URLSearchParams(location.search).get('filter')||'all',album=0,filtered=[],initialCourse=new URLSearchParams(location.search).get('selected');
 function renderLibrary(){if(!$('albumStage'))return;const q=$('librarySearch').value.trim().toLowerCase();filtered=Library.courses.filter(c=>(filter==='all'||c.status===filter)&&(c.title+c.description+c.category).toLowerCase().includes(q));if(filter==='draft')filtered=[];if(initialCourse){const chosen=filtered.findIndex(c=>c.id===initialCourse);if(chosen>=0)album=chosen;initialCourse=null;}album=Math.max(0,Math.min(album,filtered.length-1));$('albumStage').hidden=!filtered.length;$('albumControls').hidden=filtered.length<2;$('libraryEmpty').textContent=filter==='draft'?'还没有课程草稿':'没有匹配的课程';$('libraryEmpty').hidden=filtered.length>0||filter==='draft';if(filtered.length)showAlbum();refreshDrafts();for(const b of document.querySelectorAll('[data-filter]'))b.classList.toggle('active',b.dataset.filter===filter);}
 function showAlbum(){
  const c=filtered[album];if(!c)return;const stage=$('albumStage'),key=filtered.map(x=>x.id).join('|');stage.dataset.course=c.id;stage.dataset.ordinal=String(album+1).padStart(2,'0');
  if(stage.dataset.ringKey!==key){
   stage.dataset.ringKey=key;stage.innerHTML='<div class="course-ring" data-count="'+filtered.length+'" aria-label="选择课程">'+filtered.map((x,i)=>'<button type="button" class="course-ring-card ring-tone-'+i%3+'" data-ring-index="'+i+'"><span class="ring-card-type">'+(x.status==='ready'?'数字讲师精讲':'资料课堂')+'</span><span class="ring-card-cover">'+cover(x)+'</span><h3>'+esc(x.title)+'</h3><span class="ring-card-foot"><span>'+x.pages+'页课件</span><span class="ring-choice-dot" aria-hidden="true"></span></span></button>').join('')+'</div><div class="album-copy"></div><div class="album-actions"></div>';
   const scene=stage.querySelector('.course-ring');let gesture=null,suppressUntil=0;
   scene.addEventListener('click',e=>{const a=e.target.closest('[data-ring-index]');if(!a||performance.now()<suppressUntil)return;album=Number(a.dataset.ringIndex);showAlbum();});
   scene.addEventListener('pointerdown',e=>{if(e.button!==0)return;gesture={id:e.pointerId,x:e.clientX,y:e.clientY,dx:0,active:false};});
   scene.addEventListener('pointermove',e=>{if(!gesture||gesture.id!==e.pointerId)return;const dx=e.clientX-gesture.x,dy=e.clientY-gesture.y;if(!gesture.active&&Math.abs(dx)>Math.abs(dy)+8){gesture.active=true;scene.setPointerCapture(e.pointerId);scene.classList.add('is-dragging');}if(gesture.active){gesture.dx=dx;scene.style.setProperty('--gesture',Math.max(-90,Math.min(90,dx))+'px');}});
   function release(e){if(!gesture||gesture.id!==e.pointerId)return;const g=gesture;gesture=null;scene.classList.remove('is-dragging');scene.style.removeProperty('--gesture');if(g.active){suppressUntil=performance.now()+250;if(e.type!=='pointercancel'&&Math.abs(g.dx)>48){album=Math.max(0,Math.min(filtered.length-1,album+(g.dx<0?1:-1)));showAlbum();}}}
   scene.addEventListener('pointerup',release);scene.addEventListener('pointercancel',release);scene.addEventListener('dragstart',e=>e.preventDefault());
  }
  for(const a of stage.querySelectorAll('[data-ring-index]')){const i=Number(a.dataset.ringIndex);let slot=(i-album+filtered.length)%filtered.length;if(slot>filtered.length/2)slot-=filtered.length;a.style.setProperty('--slot',slot);a.style.setProperty('--depth',Math.abs(slot));a.classList.toggle('is-current',i===album);a.setAttribute('aria-pressed',String(i===album));a.setAttribute('aria-label','选择'+filtered[i].title);}
  const copy=stage.querySelector('.album-copy');copy.innerHTML='<h2>'+esc(c.title)+'</h2><p>'+esc(c.description.split('。')[0])+'</p><div class="album-numbers"><div><strong>'+c.sections+'</strong><span>知识单元</span></div><div><strong>'+c.pages+'</strong><span>课件页面</span></div><div><strong>'+c.quiz_count+'</strong><span>理解练习</span></div></div>';
  stage.querySelector('.album-actions').innerHTML='<a class="button primary" href="'+esc(c.url)+'">'+(c.status==='ready'?'进入课堂':'查看课件')+'</a>';
  window.QingruMotion?.enter(copy);$('albumPosition').textContent=String(album+1).padStart(2,'0')+' / '+String(filtered.length).padStart(2,'0');$('previousAlbum').disabled=album===0;$('nextAlbum').disabled=album===filtered.length-1;
 }

 for(const b of document.querySelectorAll('[data-import]'))b.onclick=openBuilder;
 if($('builderDialog')){$('closeBuilder').onclick=()=>$('builderDialog').close();$('addFiles').onclick=()=>$('materialInput').click();$('materialInput').onchange=e=>addFiles(e.target.files);$('pasteToggle').onclick=()=>{$('pasteField').hidden=!$('pasteField').hidden;if(!$('pasteField').hidden)$('materialText').focus();};$('compileDraft').onclick=compile;$('exportDraft').onclick=()=>built&&download(built);}
 if($('homeDrop')){const target=$('homeDrop');target.ondragover=e=>{e.preventDefault();target.classList.add('dragging');};target.ondragleave=()=>target.classList.remove('dragging');target.ondrop=e=>{e.preventDefault();target.classList.remove('dragging');openBuilder();addFiles(e.dataTransfer.files);};}
 if($('recentCourses'))$('recentCourses').innerHTML=Library.courses.map(card).join('');
 if($('auditionVoice'))$('auditionVoice').onclick=async()=>{try{const audio=$('teacherAudition');if(audio.paused){await audio.play();$('auditionVoice').textContent='停止试听';}else{audio.pause();audio.currentTime=0;$('auditionVoice').textContent='试听讲解声线';}}catch{toast('浏览器未能播放语音，请再点击一次。');}};
 if($('teacherAudition'))$('teacherAudition').onended=()=>{if($('auditionVoice'))$('auditionVoice').textContent='试听讲解声线';};
 if($('librarySearch')){$('librarySearch').value=new URLSearchParams(location.search).get('q')||'';$('librarySearch').oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{album=0;renderLibrary();},90);};for(const b of document.querySelectorAll('[data-filter]'))b.onclick=()=>{filter=b.dataset.filter;album=0;renderLibrary();};$('previousAlbum').onclick=()=>{album--;showAlbum();};$('nextAlbum').onclick=()=>{album++;showAlbum();};$('albumStage').tabIndex=0;$('albumStage').onkeydown=e=>{if(e.key==='ArrowRight'&&album<filtered.length-1){e.preventDefault();album++;showAlbum();}if(e.key==='ArrowLeft'&&album>0){e.preventDefault();album--;showAlbum();}};renderLibrary();}else refreshDrafts();
 if($('librarySearch')&&new URLSearchParams(location.search).get('focus')==='search')$('librarySearch').focus();
 rootExport();function rootExport(){window.QingruStudio={openBuilder,addFiles,compile,refreshDrafts,download,toast};}
})();

;
(function(){
 'use strict';
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),animations=new WeakMap();
 const version=new URL(document.currentScript?.src||location.href,location.href).searchParams.get('v');
 function url(value){const u=new URL(value,location.href);if(version&&u.origin===location.origin)u.searchParams.set('ui',version);return u.href;}
 function enter(node,direction=1){if(!node||reduced.matches||typeof node.animate!=='function')return;for(const a of animations.get(node)||[])a.cancel();const options={duration:420,easing:'cubic-bezier(.22,.72,.14,1)'},running=[node.animate([{opacity:.45,transform:'translateX('+direction*18+'px)'},{opacity:1,transform:'translateX(0)'}],options)];const objects=node.matches('.album-stage')?node.querySelectorAll('.album-copy h2,.album-copy>p,.album-numbers,.album-actions'):node.matches('#slide')?node.querySelectorAll('#lessonTitle,#lessonVisual,#stageInteraction'):[];objects.forEach((part,i)=>running.push(part.animate([{opacity:.15,transform:'translateY(9px)'},{opacity:1,transform:'translateY(0)'}],{...options,duration:350,delay:Math.min(i,3)*30,fill:'backwards'})));animations.set(node,running);}
 const closing=new WeakSet();async function dismiss(dialog){if(!dialog?.open||closing.has(dialog))return;if(reduced.matches||typeof dialog.animate!=='function'){dialog.close();return;}closing.add(dialog);const a=dialog.animate([{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(10px)'}],{duration:170,easing:'cubic-bezier(.4,0,.8,.5)',fill:'forwards'});try{await a.finished;}catch{}dialog.close();a.cancel();closing.delete(dialog);}
 window.QingruMotion={enter,url,dismiss};
 document.querySelectorAll('iframe.report-inline').forEach(f=>{if(version)f.src=url(f.getAttribute('src'));});
 document.querySelectorAll('.paper-figure img').forEach(img=>{if(version){const u=new URL(img.src,location.href);u.searchParams.set('v',version);img.src=u.href;}});
 // Native document transitions and compositor-only hover styles replace pointer sampling.
 const prefetched=new Set();let intent=0;
 function target(a){if(!a||a.hasAttribute('download'))return null;const u=new URL(a.href,location.href);return u.origin===location.origin&&/\.html$|\/$/.test(u.pathname)?u:null;}
 function prepare(a){const u=target(a);if(!u)return null;if(version){u.searchParams.set('ui',version);a.href=u.href;}return u;}
 function prefetch(a){const u=prepare(a);if(!u||prefetched.has(u.href)||navigator.connection?.saveData||/2g/.test(navigator.connection?.effectiveType||''))return;prefetched.add(u.href);const l=document.createElement('link');l.rel='prefetch';l.href=u.href;l.as='document';document.head.appendChild(l);}
 document.addEventListener('pointerover',e=>{const a=e.target.closest?.('a[href]');if(!target(a))return;clearTimeout(intent);intent=setTimeout(()=>prefetch(a),95);},{passive:true});
 document.addEventListener('pointerout',e=>{if(e.target.closest?.('a[href]'))clearTimeout(intent);},{passive:true});
 document.addEventListener('focusin',e=>prefetch(e.target.closest?.('a[href]')));
 document.addEventListener('click',e=>prepare(e.target.closest?.('a[href]')),true);
 document.addEventListener('submit',e=>{const f=e.target;if(!version||!f.hasAttribute('action')||(f.method||'get').toLowerCase()!=='get')return;let input=f.querySelector('input[name="ui"]');if(!input){input=document.createElement('input');input.type='hidden';input.name='ui';f.appendChild(input);}input.value=version;},true);
})();

;
(function(){
 'use strict';const stage=document.querySelector('#colourstage');if(!stage)return;
 const panels=[...stage.querySelectorAll('[data-panel]')],fine=matchMedia('(hover:hover) and (pointer:fine)');
 let hovered=null,focused=null;function sync(){stage.dataset.active=(hovered||focused)?.dataset.panel||'';}
 for(const panel of panels){panel.addEventListener('pointerenter',()=>{if(fine.matches){hovered=panel;sync();}});panel.addEventListener('pointerleave',()=>{if(hovered===panel)hovered=null;sync();});panel.addEventListener('focusin',()=>{focused=panel;sync();});panel.addEventListener('focusout',e=>{if(!panel.contains(e.relatedTarget)){focused=null;sync();}});}
 if('IntersectionObserver'in window&&!matchMedia('(prefers-reduced-motion: reduce)').matches){stage.classList.add('motion-armed');panels.forEach((p,i)=>p.querySelector('.panel-copy').style.setProperty('--panel-delay',i*75+'ms'));const observer=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){stage.classList.add('is-in-view');observer.disconnect();}},{threshold:.08});observer.observe(stage);}
 document.addEventListener('visibilitychange',()=>{if(document.hidden){hovered=null;sync();}});
})();

;
(function(){
 'use strict';
 const album=document.getElementById('albumStage');if(album&&!album.hidden)window.QingruMotion?.enter(album);
 const dialog=document.getElementById('builderDialog');if(!dialog)return;
 const close=document.getElementById('closeBuilder');if(close)close.onclick=()=>window.QingruMotion?.dismiss(dialog)||dialog.close();
 dialog.addEventListener('cancel',e=>{if(window.QingruMotion?.dismiss){e.preventDefault();window.QingruMotion.dismiss(dialog);}});
 const drop=dialog.querySelector('[data-file-drop]'),compile=document.getElementById('compileDraft');let dragDepth=0;
 function isFile(e){return [...(e.dataTransfer?.types||[])].includes('Files');}
 if(drop){
  drop.addEventListener('dragenter',e=>{if(!isFile(e))return;e.preventDefault();dragDepth++;drop.classList.add('drag-active');});
  drop.addEventListener('dragover',e=>{if(isFile(e)){e.preventDefault();e.dataTransfer.dropEffect='copy';}});
  drop.addEventListener('dragleave',()=>{dragDepth=Math.max(0,dragDepth-1);if(!dragDepth)drop.classList.remove('drag-active');});
  drop.addEventListener('drop',e=>{if(!isFile(e))return;e.preventDefault();dragDepth=0;drop.classList.remove('drag-active');window.QingruStudio?.addFiles(e.dataTransfer.files);});
 }
 function state(){dialog.classList.toggle('is-building',!compile.hidden&&compile.disabled);dialog.classList.toggle('has-preview',!document.getElementById('builderPreview').hidden);dialog.setAttribute('aria-busy',String(!compile.hidden&&compile.disabled));}
 new MutationObserver(state).observe(dialog,{subtree:true,attributes:true,attributeFilter:['disabled','hidden']});
 dialog.addEventListener('close',()=>{dragDepth=0;drop?.classList.remove('drag-active');});state();
})();

;
/* Adapted to Qingru from the user-supplied model-city-scene entrance. */
(function(){
 'use strict';
 const intro=document.querySelector('.scene-intro'),stage=intro?.querySelector('.brand-scene-stage');if(!stage)return;
 const scene=intro.querySelector('.brand-scene'),copy=intro.querySelector('.brand-scene-copy'),workspace=document.getElementById('workspace');
 const reduced=matchMedia('(prefers-reduced-motion:reduce)'),clamp=v=>Math.max(0,Math.min(1,v));
 const ramp=(p,a,b)=>{const t=clamp((p-a)/(b-a));return t*t*(3-2*t);};
 let start=0,span=1,reading=1,frame=0,last=0,current=0,target=0,entered=false,entry=null,revision=0,resizeTimer=0;
 intro.classList.add('scene-motion-ready');intro.dataset.entrance='waiting';
 function draw(p){
  intro.style.setProperty('--scene-pan',ramp(p,0,.68).toFixed(4));
  intro.style.setProperty('--scene-dusk',ramp(p,.13,.65).toFixed(4));
  intro.style.setProperty('--scene-sunset',ramp(p,.18,.65).toFixed(4));
  intro.style.setProperty('--scene-sun-alpha',(1-ramp(p,.5,.68)).toFixed(4));
  intro.style.setProperty('--scene-night',(reduced.matches?.8:ramp(p,.5,.77)).toFixed(4));
  const reveal=reduced.matches?1:ramp(p,.77,.985);
  intro.style.setProperty('--scene-copy',reveal.toFixed(4));
  intro.dataset.phase=reduced.matches?'static':p<.13?'day':p<.68?'sunset':p<.77?'night':reveal>=.999?'reading':'title';
  intro.dataset.progress=p.toFixed(4);
  document.body.classList.toggle('workspace-in-view',scrollY>start+span+reading*.25);
 }
 function render(now){
  frame=0;if(document.hidden||!entered)return;
  const dt=last?Math.min(48,now-last):16.7;last=now;
  current+=(target-current)*(reduced.matches?1:1-Math.exp(-dt/80));
  if(Math.abs(target-current)<.00008)current=target;
  draw(current);if(current!==target)frame=requestAnimationFrame(render);else last=0;
 }
 function request(){target=reduced.matches?1:clamp((scrollY-start)/span);if(entered&&!frame&&!document.hidden)frame=requestAnimationFrame(render);}
 function measure(){
  const h=stage.offsetHeight;span=Math.max(620,h*1.22);reading=Math.max(230,h*.38);
  intro.style.height=(reduced.matches?h:h+span+reading)+'px';intro.style.setProperty('--scene-sun-drop',h*.28+'px');
  start=intro.getBoundingClientRect().top+scrollY;request();
 }
 function waitForBoot(){return new Promise(resolve=>{
  const ready=()=>!document.documentElement.classList.contains('q-booting')&&!document.documentElement.classList.contains('q-boot-visible');
  if(ready()){resolve();return;}const observer=new MutationObserver(()=>{if(ready()){observer.disconnect();resolve();}});observer.observe(document.documentElement,{attributes:true,attributeFilter:['class']});
 });}
 async function entrance(){
  const version=++revision;
  await Promise.allSettled([waitForBoot(),...Array.from(scene.querySelectorAll('img'),img=>typeof img.decode==='function'?img.decode():Promise.resolve())]);
  if(version!==revision)return;
  if(reduced.matches||typeof scene.animate!=='function'||location.hash==='#workspace'||scrollY>start+span){entered=true;intro.dataset.entrance='settled';current=target;draw(current);request();return;}
  intro.dataset.entrance='playing';entry=scene.animate([
   {clipPath:'inset(8% 49% round 18px)',transform:'scale(.72)',filter:'blur(8px)',opacity:0},
   {clipPath:'inset(0% 0% round 0px)',transform:'scale(1)',filter:'blur(0px)',opacity:1}
  ],{duration:800,easing:'cubic-bezier(.72,0,.16,1)',fill:'both'});
  if(document.hidden)entry.pause();try{await entry.finished;}catch{}
  if(version!==revision)return;intro.dataset.entrance='settled';entry.cancel();entry=null;entered=true;request();
 }
 window.addEventListener('scroll',request,{passive:true});
 window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(measure,150);},{passive:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;last=0;entry?.pause();}else{entry?.play();request();}});
 reduced.addEventListener('change',()=>{revision++;entry?.cancel();entry=null;entered=true;intro.dataset.entrance='settled';measure();current=target;draw(current);});
 window.addEventListener('pagehide',()=>{cancelAnimationFrame(frame);entry?.pause();});
 window.addEventListener('pageshow',event=>{if(event.persisted){entry?.play();measure();request();}});
 window.addEventListener('hashchange',request);
 measure();draw(0);entrance();
 if(location.hash==='#workspace')requestAnimationFrame(()=>{workspace.scrollIntoView({behavior:'instant'});request();});
})();


;
(function(root){
 'use strict';
 function build(course){
  const bySection=new Map(),pages=course.lessons.map((lesson,index)=>({lesson,index,text:(lesson.title+' '+lesson.short).toLowerCase()}));
  for(const page of pages){const key=page.lesson.section_id;if(!bySection.has(key))bySection.set(key,[]);bySection.get(key).push(page);}
  const sections=(course.sections?.length?course.sections:[{id:pages[0]?.lesson.section_id,title:course.title,chapter_title:'课程内容'}]).map(section=>({section,pages:bySection.get(section.id)||[],text:((section.chapter_title||'课程内容')+' '+section.title).toLowerCase()})).filter(x=>x.pages.length);
  function search(query=''){
   const chapters=new Map(),q=query.trim().toLowerCase();
   for(const row of sections){const sectionMatch=!q||row.text.includes(q),filtered=sectionMatch?row.pages:row.pages.filter(p=>p.text.includes(q));if(!filtered.length)continue;const chapter=row.section.chapter_title||'课程内容';if(!chapters.has(chapter))chapters.set(chapter,[]);chapters.get(chapter).push({s:row.section,pages:row.pages,filtered,sectionMatch});}
   return chapters;
  }
  return{pages,sections,bySection,search};
 }
 root.QingruCourseIndex={build};
})(typeof window==='undefined'?globalThis:window);

;
(function(){
 'use strict';
 const el=id=>document.getElementById(id),esc=s=>window.QingruContent.escape(String(s??''));
 let currentIndex=0,videoMode=false,search='',indexedCourse=null,indexed=null,renderKey='',initialized=false,searchFrame=0;
 function catalog(){
  const c=window.QINGRU_COURSE_DATA,active=c.lessons[currentIndex],box=el('catalog');
  if(indexedCourse!==c){indexedCourse=c;indexed=window.QingruCourseIndex.build(c);renderKey='';}
  function selection(){const old=box.querySelector('.unit.active');if(old){old.classList.remove('active');old.removeAttribute('aria-current');}const next=box.querySelector('.unit[data-index="'+currentIndex+'"]');if(next){next.classList.add('active');next.setAttribute('aria-current','step');}el('chapterField').hidden=true;el('count').textContent=c.lessons.length+' 页';}
  const key=(active.section_id||'')+'|'+search;
  if(renderKey===key){selection();return;}
  renderKey=key;
  const opened=new Set([...box.querySelectorAll('details[open]')].map(d=>d.dataset.chapter));
  const page=({lesson:l,index:i})=>'<button class="unit'+(i===currentIndex?' active':'')+'" data-index="'+i+'"'+(i===currentIndex?' aria-current="step"':'')+'><span>'+String(i+1).padStart(2,'0')+'</span><span class="unit-title">'+esc(l.title)+'</span></button>';
  if(c.kind!=='document'){
   const groups=[['建立理解',0,3],['推理与应用',3,9],['巩固练习',9,c.lessons.length]];
   box.innerHTML=groups.map(([title,start,end])=>{const list=indexed.pages.slice(start,end).filter(p=>!search||p.text.includes(search));return list.length?'<div class="catalog-group"><h3>'+title+'</h3>'+list.map(page).join('')+'</div>':'';}).join('');
  }else{
   box.innerHTML=[...indexed.search(search)].map(([chapter,sections])=>{const activeChapter=sections.some(({s})=>s.id===active.section_id);return '<details class="catalog-chapter" data-chapter="'+esc(chapter)+'"'+(search||activeChapter||opened.has(chapter)?' open':'')+'><summary><span>'+esc(chapter)+'</span><small>'+sections.length+' 节</small></summary><div>'+sections.map(({s,pages,filtered,sectionMatch})=>'<button class="section-link'+(s.id===active.section_id?' current':'')+'" data-index="'+pages[0].index+'"><span>'+esc(s.title)+'</span><small>'+pages.length+' 页</small></button>'+((s.id===active.section_id||Boolean(search&&!sectionMatch))?'<div class="section-pages">'+filtered.map(page).join('')+'</div>':'')).join('')+'</div></details>';}).join('');
  }
  if(!box.innerHTML)box.innerHTML='<p class="catalog-empty">没有找到相关内容，请换个关键词。</p>';
  for(const b of box.querySelectorAll('[data-index]'))b.onclick=()=>{const next=Number(b.dataset.index);if(next!==currentIndex)window.QingruNavigateLesson(next);else{mode(false);if(window.matchMedia('(max-width:900px)').matches)closeCatalog();}};
  selection();
 }
 function mode(isVideo){
  videoMode=Boolean(isVideo&&window.QINGRU_COURSE_DATA.lecture?.url);
  el('stage').classList.toggle('video-mode',videoMode);
  el('courseView').classList.toggle('watching-video',videoMode);
  el('videoMode').setAttribute('aria-pressed',String(videoMode));el('slideMode').setAttribute('aria-pressed',String(!videoMode));
  el('lessonVideo').hidden=!videoMode;el('posterPlay').hidden=!videoMode||!el('lessonVideo').paused;
  if(!videoMode)el('lessonVideo').pause();
  document.querySelector('.page-transport').hidden=videoMode;
  el('contextLabel').textContent=videoMode?'本节精讲':'本页要点';
  el('lessonBrief').textContent=videoMode?'从排队与滞销的生活情境出发，理解均衡价格、市场调整与供求变化。切换动态课件，可继续操作图表并完成练习。':window.QINGRU_COURSE_DATA.lessons[currentIndex].body;
  el('lectureStart').hidden=!videoMode;
 }
 function refresh(lesson,index){
  const previousIndex=currentIndex;currentIndex=index;el('slide').scrollTop=0;
  const c=window.QINGRU_COURSE_DATA,extra=el('interactive'),stage=el('stage');
  const showInteraction=c.kind!=='document'&&Boolean(extra.innerHTML.trim());
  stage.classList.toggle('interaction-mode',showInteraction);stage.classList.toggle('reading-mode',c.kind==='document');
  stage.dataset.layout=c.kind==='document'?'document':lesson.id;
  const categories={opening:'情境导入',definition:'核心概念',table:'数据读解',adjustment:'动态推演',linear:'模型求解',shifts:'动态推演',both:'条件比较',model:'模型条件',cobweb:'时间推演',quiz:'理解练习'};
  el('slideCategory').textContent=c.kind==='document'?'教材课堂':categories[lesson.id]||'知识讲解';
  el('stageCaption').hidden=true;el('lessonVisual').hidden=showInteraction;
  extra.hidden=false;(showInteraction?el('stageInteraction'):el('readingDetail')).appendChild(extra);
  if(c.kind==='document'){
   const picture=(lesson.blocks||[]).flatMap(b=>b.images||[])[0];
   if(picture)el('lessonVisual').innerHTML='<figure class="source-figure"><img src="'+esc(picture)+'" alt="本页教材原图"><figcaption>教材原图</figcaption></figure>';
  }
  if(c.kind!=='document'&&!showInteraction){
   const note=document.createElement('div');note.className='slide-explanation';note.innerHTML='<span>关键理解</span><p>'+esc(lesson.body)+'</p>';el('lessonVisual').appendChild(note);
  }
  const quizCards=[...extra.querySelectorAll('.quiz')];
  for(const card of quizCards)for(const button of card.querySelectorAll('[data-option]')){const text=button.textContent.trim(),letter=text.slice(0,1),answer=text.slice(1).trim();button.setAttribute('aria-label',letter+' '+answer);button.innerHTML='<span class="option-mark">'+esc(letter)+'</span><span>'+esc(answer)+'</span>';}

  if(showInteraction&&quizCards.length){
   let question=0,lastQuestion=-1;const pager=document.createElement('div');pager.className='quiz-pager';pager.innerHTML='<button class="quiz-back" aria-label="上一题"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="m14 6-6 6 6 6"/></svg></button><div class="question-position"><span aria-live="polite"></span><div class="question-track" aria-hidden="true">'+quizCards.map(()=>'<i></i>').join('')+'</div></div><button class="quiz-forward" aria-label="下一题"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="m10 6 6 6-6 6"/></svg></button>';extra.appendChild(pager);
   const render=()=>{el('slide').scrollTop=0;quizCards.forEach((card,k)=>card.hidden=k!==question);pager.querySelector('span').textContent=(question+1)+' / '+quizCards.length;pager.querySelectorAll('.question-track i').forEach((mark,k)=>mark.classList.toggle('current',k===question));pager.querySelector('.quiz-back').disabled=question===0;pager.querySelector('.quiz-forward').disabled=question===quizCards.length-1;if(lastQuestion!==-1)window.QingruMotion?.enter(quizCards[question],question<lastQuestion?-1:1);lastQuestion=question;};
   pager.querySelector('.quiz-back').onclick=()=>{question--;render();};pager.querySelector('.quiz-forward').onclick=()=>{question++;render();};render();
  }
  el('pageLabel').textContent=(index+1)+' / '+c.lessons.length;el('pageSource').textContent='查看本页 '+lesson.sources.length+' 条原文';
  mode(false);catalog();el('roomMenu').open=false;
  if(initialized)window.QingruMotion?.enter(el('slide'),index<previousIndex?-1:1);
  if(window.matchMedia('(max-width:900px)').matches)closeCatalog();
 }
 function closeCatalog(){document.body.classList.remove('catalog-open');el('sidebarScrim').hidden=true;el('catalogToggle').setAttribute('aria-expanded','false');el('catalogToggle').setAttribute('aria-label','展开课程目录');}
 function open(id){el('lessonVideo').pause();el('roomMenu').open=false;el(id).showModal();}
 async function play(){
  mode(true);const v=el('lessonVideo');el('mediaStatus').hidden=true;
  if(!v.paused){v.pause();return;}
  el('answerAudio').pause();el('demoVideo').pause();if(v.ended)v.currentTime=0;
  try{await v.play();}catch{el('mediaStatus').textContent='暂时无法播放，请检查网络后重试。';el('mediaStatus').hidden=false;}
 }
 function init(course){
  document.body.classList.add('classroom-ready');el('courseView').setAttribute('aria-busy','false');
  for(const id of ['catalogToggle','openNotes','openQA','courseSwitch','slideMode'])el(id).disabled=false;
  const hasVideo=Boolean(course.lecture?.url);el('videoMode').hidden=!hasVideo;el('videoMode').disabled=!hasVideo;
  el('lectureStart').disabled=!hasVideo;el('lectureStart').textContent='播放';el('roomMode').textContent=hasVideo?'数字讲师课堂':'资料课堂';
  const courses=window.QingruLibrary.courses;
  el('courseSwitch').innerHTML=courses.map(c=>'<option value="'+esc(c.id)+'">'+esc(c.title)+'</option>').join('')+(course.id?.startsWith('draft-')?'<option value="'+esc(course.id)+'">'+esc(course.title)+'</option>':'');
  el('courseSwitch').value=course.id;
  el('courseSwitch').onchange=()=>{const chosen=courses.find(c=>c.id===el('courseSwitch').value);if(chosen)location.href=window.QingruMotion?.url(chosen.url)||chosen.url;};
  el('openNotes').onclick=()=>open('notesDialog');el('openQA').onclick=()=>open('qaDialog');
  el('videoMode').onclick=()=>mode(true);el('slideMode').onclick=()=>mode(false);el('lectureStart').onclick=play;el('posterPlay').onclick=play;
  const v=el('lessonVideo');
  v.controls=false;
  const waiting=document.createElement('div');waiting.className='media-wait';waiting.hidden=true;waiting.setAttribute('role','status');waiting.setAttribute('aria-label','正在缓冲视频');waiting.innerHTML='<span class="eye-loader" aria-hidden="true"></span>';el('stage').appendChild(waiting);let waitTimer=0;
  const clearWait=()=>{clearTimeout(waitTimer);waiting.hidden=true;};
  v.addEventListener('waiting',()=>{clearTimeout(waitTimer);waitTimer=setTimeout(()=>{if(!v.paused&&!v.ended)waiting.hidden=false;},180);});for(const name of ['playing','pause','ended','error'])v.addEventListener(name,clearWait);

  v.addEventListener('play',()=>{v.controls=true;el('lectureStart').textContent='暂停';el('posterPlay').hidden=true;});
  v.addEventListener('pause',()=>{el('lectureStart').textContent=v.ended?'重新播放':'继续播放';el('posterPlay').hidden=!videoMode;});
  v.onended=()=>{el('lectureStart').textContent='重新播放';el('posterPlay').hidden=false;};
  v.addEventListener('error',()=>{if(hasVideo){el('mediaStatus').textContent='视频未能载入，请刷新页面后重试。';el('mediaStatus').hidden=false;}});
  function duration(){if(Number.isFinite(v.duration))el('mediaDuration').textContent=Math.floor(v.duration/60)+':'+String(Math.round(v.duration%60)).padStart(2,'0');}
  v.addEventListener('loadedmetadata',duration);duration();
  el('catalogSearch').oninput=e=>{search=e.target.value.trim().toLowerCase();if(!searchFrame)searchFrame=requestAnimationFrame(()=>{searchFrame=0;catalog();});};
  el('catalogToggle').onclick=()=>{const expanded=document.body.classList.toggle('catalog-open');el('sidebarScrim').hidden=!expanded;el('catalogToggle').setAttribute('aria-expanded',String(expanded));el('catalogToggle').setAttribute('aria-label',expanded?'收起课程目录':'展开课程目录');};
  el('catalogClose').onclick=closeCatalog;
  el('sidebarScrim').onclick=closeCatalog;
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeCatalog();});
  document.addEventListener('click',e=>{if(!el('roomMenu').contains(e.target))el('roomMenu').open=false;});
  for(const b of el('roomMenu').querySelectorAll('button'))b.addEventListener('click',()=>{el('roomMenu').open=false;});
  for(const d of document.querySelectorAll('dialog'))d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}});
  mode(hasVideo&&currentIndex===0);catalog();initialized=true;window.QingruBoot?.ready();
  if(new URLSearchParams(location.search).get('tool')==='qa')open('qaDialog');
 }
 window.QingruClassroom={refresh,init,managesCatalog:true};
})();

;
window.QingruStartLesson=function(){
const $=id=>document.getElementById(id);const course=window.QINGRU_COURSE_DATA;let index=0;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sourceMap=new Map(course.source_blocks.map(b=>[b.id,b]));
const table=rows=>'<table class="data-table"><thead><tr>'+rows[0].map(c=>'<th>'+esc(c)+'</th>').join('')+'</tr></thead><tbody>'+rows.slice(1).map(r=>'<tr>'+r.map(c=>'<td>'+esc(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
function cards(a){return'<div class="visual-cards">'+a.map(([label,value,unit])=>'<div><small>'+label+'</small><strong>'+value+'</strong><small>'+unit+'</small></div>').join('')+'</div>';}
const visuals={opening:'<div class="big-equation">排队，还是卖不完？</div><p>先比较同一价格下的供求数量。</p>',definition:'<div class="big-equation">需求量 = 供给量</div>'+cards([['均衡价格','3','原文表格'],['均衡数量','30','供求相等']]),table:cards([['价格','3','元／杯'],['需求量','30','杯／日'],['供给量','30','杯／日']]),adjustment:'<div class="big-equation">过剩 → 降价压力<br>短缺 → 涨价压力</div>',linear:'<div class="big-equation">Qd = Qs</div>'+cards([['均衡价格','P*','供求交点'],['均衡数量','Q*','共同数量']]),shifts:'<div class="big-equation">沿曲线移动<br>与曲线整体移动</div>',both:'<div class="big-equation">需求 ↑ ＋ 供给 ↑</div>'+cards([['均衡数量','↑','方向确定'],['均衡价格','?','比较相对幅度']]),model:'<div class="big-equation">变量 · 假设 · 假说</div><p>先说条件，再讨论结论。</p>',cobweb:'<div class="big-equation">本期价格<br>影响下期供给</div>',quiz:'<div class="big-equation">先判断条件<br>再判断变化</div><p>用一个新情境，检验真正的理解。</p>'};
function sources(ids=null){$('sourceSummary').textContent='来源：《'+course.source+'》'+course.source_section+'。本单元保留'+course.coverage.preserved_blocks+'个原文块；课堂重新组织表达，原文可逐项核对。';$('sourceContent').innerHTML=course.source_blocks.filter(b=>!ids||ids.includes(b.id)).map(b=>'<article id="src-'+b.id+'"><small>'+esc(b.id)+'</small>'+(b.rows?table(b.rows):'<p>'+esc(b.text||'')+'</p>')+(b.images||[]).map(src=>'<img loading="lazy" decoding="async" src="'+esc(src.startsWith('data:')||src.startsWith('assets/')?src:'assets/'+src.split('/').pop())+'" alt="导入材料原图">').join('')+'</article>').join('');$('sourceDialog').showModal();}
function graphUI(){return'<h3 class="interactive-title">把条件调一调，观察数量与价格</h3><svg id="marketGraph" viewBox="0 0 820 360" role="img" aria-label="供求曲线和市场均衡"></svg><div class="controls"><label>当前价格 P <output id="pValue"></output><input id="price" type="range" min="1" max="5" step="0.1" value="3" aria-label="当前价格"></label><label>需求条件变化 ΔD <output id="dValue"></output><input id="demand" type="range" min="-20" max="20" step="5" value="0" aria-label="需求条件变化"></label><label>供给条件变化 ΔS <output id="sValue"></output><input id="supply" type="range" min="-20" max="20" step="5" value="0" aria-label="供给条件变化"></label></div><div id="marketResult" class="result-line" aria-live="polite"></div><p class="mode-note">数值关系与原文表格一致。元／杯、杯／日为教学案例约定；本图假定其他条件按所选滑块保持不变。</p>';}
function market(){const p=Number($('price').value),d=Number($('demand').value),s=Number($('supply').value),pe=(60+d-s)/20,qe=10*pe+s,qd=Math.max(0,60-10*p+d),qs=Math.max(0,10*p+s),gap=qd-qs;const x=q=>70+q/100*520,y=v=>280-v/7*220;
 let svg='<g font-family="Microsoft YaHei,sans-serif" font-size="14" fill="#6b7d8b"><path d="M70 45V280H620" fill="none" stroke="#9aafc2"/><text x="14" y="25">价格 P</text><text x="345" y="347" text-anchor="middle">数量 Q</text>';
 for(let q=0;q<=100;q+=20)svg+=`<text x="${x(q)}" y="311" text-anchor="middle">${q}</text>`;
 for(let n=0;n<=6;n+=2)svg+=`<text x="50" y="${y(n)+5}" text-anchor="end">${n}</text>`;
 const curve=(demand,color)=>'<path d="'+Array.from({length:71},(_,i)=>{const v=i/10,q=Math.max(0,demand?60-10*v+d:10*v+s);return(i?'L':'M')+x(q)+','+y(v);}).join(' ')+'" stroke="'+color+'" stroke-width="3" fill="none"/>';
 svg+=curve(true,'#244f7c')+curve(false,'#267462');svg+=`<path d="M70 ${y(p)}H620M${x(qe)} 280V${y(pe)}H70" fill="none" stroke="#91a7bc" stroke-dasharray="4 5"/><circle cx="${x(qe)}" cy="${y(pe)}" r="6" fill="#244f7c" stroke="white" stroke-width="2"/><circle cx="${x(qd)}" cy="${y(p)}" r="4" fill="#244f7c"/><circle cx="${x(qs)}" cy="${y(p)}" r="4" fill="#267462"/>`;
 svg+='<g transform="translate(665,68)"><path d="M0 0H24" stroke="#244f7c" stroke-width="3"/><text x="32" y="5" fill="#244f7c">D 需求</text><path d="M0 30H24" stroke="#267462" stroke-width="3"/><text x="32" y="35" fill="#267462">S 供给</text><rect x="-12" y="65" width="143" height="122" rx="8" fill="#f4f7fa" stroke="#dce4ec"/><text x="0" y="91" fill="#244f7c">E 均衡点</text><text x="0" y="130">P* = '+pe.toFixed(1)+'</text><text x="0" y="163">Q* = '+qe.toFixed(0)+'</text></g></g>';
 $('marketGraph').innerHTML=svg;$('pValue').textContent=p.toFixed(1);$('dValue').textContent=d>0?'+'+d:d;$('sValue').textContent=s>0?'+'+s:s;$('marketResult').textContent=`当前价格：需求量 ${qd.toFixed(0)}，供给量 ${qs.toFixed(0)}。`+(Math.abs(gap)<.01?'供求相等，处于均衡。':gap>0?`短缺 ${gap.toFixed(0)}，存在涨价压力。`:`过剩 ${(-gap).toFixed(0)}，存在降价压力。`)+` 本组条件的均衡为 P*=${pe.toFixed(1)}，Q*=${qe.toFixed(0)}。`;
}
function cobweb(){const r=Number($('ratio').value),values=Array.from({length:11},(_,i)=>(-r)**i),max=Math.max(1,...values.map(Math.abs)),x=i=>55+i*69,y=v=>160-v/max*115;let svg='<path d="M55 26V285M55 160H770" stroke="#b3c2cf" fill="none"/><g font-family="Microsoft YaHei" font-size="12" fill="#6b7d8b"><text x="5" y="18">价格偏差</text><text x="780" y="290">期数</text><text x="10" y="49">'+max.toFixed(1)+'</text><text x="10" y="282">−'+max.toFixed(1)+'</text>';
 svg+='<path d="'+values.map((v,i)=>(i?'L':'M')+x(i)+','+y(v)).join(' ')+'" fill="none" stroke="#244f7c" stroke-width="3"/>';values.forEach((v,i)=>svg+=`<circle cx="${x(i)}" cy="${y(v)}" r="4" fill="#244f7c"/><text x="${x(i)-3}" y="306">${i}</text>`);$('cobwebGraph').innerHTML=svg+'</g>';$('ratioValue').textContent=r.toFixed(2);$('cobwebResult').textContent=r<.99?'绝对传递倍数小于1：偏离幅度逐期缩小，收敛于均衡。':r<=1.01?'绝对传递倍数等于1：偏离幅度保持不变，形成等幅波动。':'绝对传递倍数大于1：偏离幅度逐期增大，呈发散趋势。';}
function quizzes(){const list=course.quizzes.filter(q=>!q.section_id||q.section_id===course.lessons[index].section_id);return list.map((q)=>{const i=course.quizzes.indexOf(q);return `<section class="quiz"><h3>${esc(q.q)}</h3><div class="options">${q.options.map((v,k)=>`<button data-quiz="${i}" data-option="${k}">${String.fromCharCode(65+k)}　${esc(v)}</button>`).join('')}</div><p class="feedback" id="feedback-${i}" aria-live="polite"></p></section>`;}).join('');}
function renderCatalog(){if(window.QingruClassroom?.managesCatalog)return;const lesson=course.lessons[index],sections=course.sections||[];if($('chapterField')&&sections.length>1){$('chapterField').hidden=false;const select=$('chapterSelect');if(!select.options.length)select.innerHTML=sections.map(s=>'<option value="'+esc(s.id)+'">'+esc((s.chapter_title?s.chapter_title+' · ':'')+s.title)+'</option>').join('');select.value=lesson.section_id;select.onchange=()=>{const next=course.lessons.findIndex(p=>p.section_id===select.value);if(next>=0)selectLesson(next);};}
 const items=course.lessons.map((l,i)=>({l,i})).filter(({l})=>sections.length<2||l.section_id===lesson.section_id);$('catalog').innerHTML=items.map(({l,i})=>`<button class="unit" data-index="${i}"><span>${String(i+1).padStart(2,'0')}</span>${esc(l.short)}</button>`).join('');for(const b of $('catalog').children)b.onclick=()=>selectLesson(Number(b.dataset.index));}
function selectLesson(i){select(i);}
window.QingruNavigateLesson=selectLesson;
function select(i){index=Math.max(0,Math.min(course.lessons.length-1,i));renderCatalog();const lesson=course.lessons[index];$('lessonVideo').pause();$('lessonVideo').hidden=true;$('pageNumber').textContent=String(index+1).padStart(2,'0')+' / '+course.lessons.length;$('lessonTitle').textContent=lesson.title;$('lessonVisual').innerHTML=course.kind==='document'?QingruContent.visual(lesson):visuals[lesson.id];$('lessonBody').textContent=lesson.body;$('count').textContent=(index+1)+' / '+course.lessons.length;$('pageLabel').textContent=lesson.short;$('prev').disabled=index===0;$('next').disabled=index===course.lessons.length-1;if(!window.QingruClassroom?.managesCatalog)$('catalog').querySelectorAll('button').forEach((b,k)=>b.classList.toggle('active',Number(b.dataset.index)===index));$('pageSource').textContent=lesson.sources.join(' · ');$('pageSource').onclick=()=>sources(lesson.sources);
 let extra='';if(lesson.id==='table')extra=table(sourceMap.get('b0255').rows);if(['adjustment','shifts','both'].includes(lesson.id))extra=graphUI();if(lesson.id==='linear')extra='<div class="formula">Qd = α − βP，Qs = −δ + γP<br>Qd = Qs ⇒ (β + γ)P* = α + δ<br>P* = (α + δ) / (β + γ)，Q* = α − βP*</div><p class="mode-note">线性模型中取 β、γ＞0，并检查求得价格与数量是否位于经济上有效的范围。</p>';if(lesson.id==='both')extra+=table(sourceMap.get('b0269').rows);if(lesson.id==='model')extra=table(sourceMap.get('b0277').rows);if(lesson.id==='cobweb')extra='<div class="formula">ΔPₜ = −(γ / β) ΔPₜ₋₁</div><svg id="cobwebGraph" viewBox="0 0 820 320" role="img" aria-label="蛛网模型价格偏离随期数变化"></svg><label>供给反应 / 需求反应 <output id="ratioValue"></output><input id="ratio" type="range" min="0.5" max="1.3" step="0.05" value="0.6" aria-label="蛛网模型反应系数比"></label><p id="cobwebResult" class="result-line"></p><p class="mode-note">线性一期滞后的价格偏离示意。供给反应系数γ、需求反应系数β均为正。发散仅表示局部模型偏离增大，不表示现实价格可以无限变化。</p>';if(lesson.id==='quiz')extra=quizzes();if(course.kind==='document'){extra=QingruContent.details(lesson);if(index===course.lessons.length-1||course.lessons[index+1].section_id!==lesson.section_id)extra+=quizzes();}$('interactive').innerHTML=extra;
 if(['adjustment','shifts','both'].includes(lesson.id)){for(const k of['price','demand','supply'])$(k).oninput=market;market();}if(lesson.id==='cobweb'){$('ratio').oninput=cobweb;cobweb();}for(const b of $('interactive').querySelectorAll('[data-quiz]'))b.onclick=()=>{const q=course.quizzes[Number(b.dataset.quiz)],chosen=Number(b.dataset.option);for(const s of b.parentElement.children){s.classList.remove('correct','wrong');s.setAttribute('aria-pressed',String(s===b));}b.classList.add(chosen===q.answer?'correct':'wrong');$('feedback-'+b.dataset.quiz).textContent=(chosen===q.answer?'回答正确。':'再想一步。')+q.why;$('feedback-'+b.dataset.quiz).dataset.source=q.source;};history.replaceState(null,'','#'+lesson.id);window.QingruClassroom?.refresh(lesson,index);
}
$('prev').onclick=()=>select(index-1);$('next').onclick=()=>select(index+1);$('sourceOpen').onclick=()=>sources();for(const b of document.querySelectorAll('[data-close]'))b.onclick=()=>$(b.dataset.close).close();$('transcriptOpen').onclick=()=>{$('transcriptContent').innerHTML='<p>'+esc(course.lessons[index].body)+'</p><p>讲师主讲：'+esc(course.lecture?.script||'本课堂当前为资料阅读模式。')+'</p>';$('transcriptDialog').showModal();};$('fullScreen').onclick=()=>$('stage').requestFullscreen?.();
if(course.lecture?.url){$('lessonVideo').src=course.lecture.url;$('lectureStart').onclick=async()=>{$('answerAudio').pause();$('demoVideo').pause();$('lessonVideo').currentTime=0;$('lessonVideo').hidden=false;try{await $('lessonVideo').play();}catch{$('lessonVideo').controls=true;}};}else{$('lectureStart').disabled=true;$('lectureStart').textContent='资料课堂 · 阅读模式';}
for(const b of document.querySelectorAll('[data-view]'))b.onclick=()=>{for(const name of['course','demo','about'])$(name+'View').hidden=name!==b.dataset.view;for(const x of document.querySelectorAll('[data-view]'))x.classList.toggle('active',x===b);$('lessonVideo').pause();$('demoVideo').pause();$('answerAudio').pause();};
function ask(value){if(course.kind==='document')return askSource(value);$('lessonVideo').pause();$('demoVideo').pause();$('answerAudio').pause();$('answerAudio').hidden=true;const query=value.replace(/[？?，。\s]/g,'');const topics={shortage:['短缺','供不应求','涨价'],surplus:['过剩','供过于求','卖不完','积压'],both:['同时','一起','供求变动'],equilibrium:['均衡','政府','规定'],cobweb:['蛛网','收敛','发散','滞后','等幅'],movement:['曲线','收入','偏好','自身价格','价格变化']};let scored=course.faq.map(f=>{const matches=(topics[f.id]||[]).filter(k=>query.includes(k)).length;const text=f.question+f.answer;const pairs=Array.from({length:Math.max(0,query.length-1)},(_,i)=>query.slice(i,i+2));let score=matches?6*matches+pairs.reduce((n,p)=>n+(text.includes(p)?1:0),0):0;if(f.question.replace(/[？?，。\s]/g,'')===query)score+=100;return{f,score};}).sort((a,b)=>b.score-a.score);$('answer').hidden=false;if(!query||scored[0].score<2){const found=course.source_blocks.filter(b=>query.length>1&&b.text?.includes(query)).slice(0,3);$('answer').innerHTML=found.length?found.map(b=>'<p>'+esc(b.text)+'</p><small>原文依据：'+b.id+'</small>').join(''):'本单元中暂未找到足够依据。请缩小到均衡、过剩、短缺、供求变动或蛛网模型，也可打开原文查看。';return;}const f=scored[0].f;$('answer').innerHTML='<strong>'+esc(f.question)+'</strong><p>'+esc(f.answer)+'</p><small>资料内匹配 · 原文依据：'+f.source+' · '+esc(sourceMap.get(f.source)?.text||'原文表格')+'</small>';$('answerAudio').src=f.audio;$('answerAudio').hidden=false;}
$('askForm').onsubmit=e=>{e.preventDefault();ask($('question').value);};$('suggestions').innerHTML=course.faq.slice(0,3).map((f,i)=>'<button data-faq="'+i+'">'+esc(f.question)+'</button>').join('');for(const b of $('suggestions').children)b.onclick=()=>{$('question').value=course.faq[Number(b.dataset.faq)].question;ask($('question').value);};
const chapters=course.demo_chapters||[{title:'项目与理念',time:0},{title:'精品课堂',time:75},{title:'交互与练习',time:145},{title:'答疑与依据',time:200},{title:'方法与交付',time:245}];$('demoChapters').innerHTML=chapters.map((c,i)=>'<button data-chapter="'+i+'">'+c.title+'</button>').join('');for(const b of $('demoChapters').children)b.onclick=()=>{$('demoVideo').currentTime=chapters[Number(b.dataset.chapter)].time;$('demoVideo').play();};select(Math.max(0,course.lessons.findIndex(l=>l.id===location.hash.slice(1))));

// A single active speaker across classroom, film and FAQ playback.
$('lessonVideo').onplay=()=>{$('answerAudio').pause();$('demoVideo').pause();};
$('demoVideo').onplay=()=>{$('lessonVideo').pause();$('answerAudio').pause();};
$('answerAudio').onplay=()=>{$('lessonVideo').pause();$('demoVideo').pause();};
$('lessonVideo').onended=()=>{select(3);$('lectureStart').textContent='重看数字讲师精讲';};

function askSource(value){$('answerAudio').pause();$('answerAudio').hidden=true;const q=String(value).replace(/[，。？！?\s]/g,'').toLowerCase();$('answer').hidden=false;if(q.length<2){$('answer').textContent='请输入至少两个字的课程概念或关键词。';return;}const pairs=Array.from({length:q.length-1},(_,i)=>q.slice(i,i+2));const ranked=course.source_blocks.filter(b=>b.text).map(b=>({b,score:pairs.reduce((n,k)=>n+(b.text.toLowerCase().includes(k)?1:0),0)+(b.text.toLowerCase().includes(q)?8:0)})).filter(x=>x.score>=Math.min(2,pairs.length)).sort((a,b)=>b.score-a.score).slice(0,3);$('answer').innerHTML=ranked.length?ranked.map(({b})=>'<article><p>'+esc(b.text)+'</p><small>原文摘录 · '+esc(b.id)+'</small></article>').join(''):'本课程原文中暂未找到足够依据，请换一个概念或打开课程原文查找。';}
if($('summaryOpen'))$('summaryOpen').onclick=()=>{const section=course.lessons[index].section_id;const pages=course.lessons.filter(p=>p.section_id===section);$('transcriptContent').innerHTML='<h3>本单元学习小结</h3><ul class="summary-items">'+pages.map(p=>'<li><strong>'+esc(p.title)+'</strong>'+esc(p.body)+'</li>').join('')+'</ul>';$('transcriptDialog').showModal();};
const lessonParams=new URLSearchParams(location.search);if(lessonParams.get('play')==='1'&&course.lecture){$('lectureStart').textContent='点击开始数字讲师精讲';}

};
(async function(){
 window.QingruBoot?.hint('正在准备课程');
 const params=new URLSearchParams(location.search),id=params.get('course'),draft=params.get('draft');
 try{
  if(draft){const course=await QingruStore.get(draft);if(!course)throw Error('此浏览器没有这份草稿，请回课程库查看或重新导入材料。');window.QINGRU_COURSE_DATA=course;}
  else if(id&&id!=='market-equilibrium'){const meta=QingruLibrary.courses.find(c=>c.id===id);if(!meta)throw Error('没有找到这门课程。');await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=window.QingruMotion?.url(meta.data)||meta.data;script.onload=resolve;script.onerror=()=>reject(Error('课程资料加载失败，请刷新重试。'));document.body.appendChild(script);});window.QINGRU_COURSE_DATA=QingruLibrary.loaded[id];}
  const course=window.QINGRU_COURSE_DATA;const libraryLink=document.querySelector('[data-course-library]');if(libraryLink)libraryLink.href=window.QingruMotion?.url(draft?'courses.html?filter=draft':'courses.html?selected='+encodeURIComponent(course.id))||'courses.html';document.title=course.title+' · 清如课堂';document.getElementById('courseTitle').textContent=course.title;document.getElementById('courseDescription').textContent=course.kind==='document'?'按章节阅读、核对原文，再通过练习检验理解。':'从一杯奶茶的价格，理解供求如何相遇。';
  if(course.kind==='document'){document.querySelector('.heading .subtle').textContent='资料课堂 / '+(draft?'我的材料':course.source);document.querySelector('.aside-foot').textContent='原文保留 · 按章节学习';document.querySelector('.ask-section>div>p').textContent='从本课程原文中查找相关段落。';document.querySelector('.ask-body>.mode-note').textContent='本页提供材料检索；新讲解视频尚未制作。';document.getElementById('question').placeholder='输入课程中的概念或关键词';}
  window.QingruStartLesson();window.QingruClassroom?.init(course);
 }catch(e){document.querySelector('.lesson-area').innerHTML='<div class="empty-state">'+QingruContent.escape(e.message)+'<p><a class="button" href="courses.html">返回课程库</a></p></div>';const button=document.getElementById('lectureStart');if(button)button.hidden=true;document.getElementById('courseView').setAttribute('aria-busy','false');window.QingruBoot?.ready();}
})();
