/* Adapted to Qingru from the user-supplied model-city-scene entrance. */
(function(){
 'use strict';
 const intro=document.querySelector('.scene-intro'),stage=intro?.querySelector('.brand-scene-stage');if(!stage)return;
 const scene=intro.querySelector('.brand-scene'),copy=intro.querySelector('.brand-scene-copy'),workspace=document.getElementById('workspace');
 const reduced=matchMedia('(prefers-reduced-motion:reduce)'),clamp=v=>Math.max(0,Math.min(1,v));
 const ramp=(p,a,b)=>{const t=clamp((p-a)/(b-a));return t*t*(3-2*t);};
 let start=0,span=1,reading=1,frame=0,last=0,current=0,target=0,entered=false,entry=null,revision=0,resizeTimer=0;
 intro.classList.add('scene-motion-ready');intro.dataset.entrance='waiting';
 const picturesReady=Promise.allSettled(Array.from(scene.querySelectorAll('img'),img=>typeof img.decode==='function'?img.decode():Promise.resolve()));
 window.QingruSceneReady=location.hash==='#workspace'?Promise.resolve():picturesReady;
 function draw(p){
  intro.style.setProperty('--scene-pan',ramp(p,0,.68).toFixed(4));
  intro.style.setProperty('--scene-dusk',ramp(p,.13,.65).toFixed(4));
  intro.style.setProperty('--scene-sunset',ramp(p,.18,.65).toFixed(4));
  intro.style.setProperty('--scene-sun-alpha',(1-ramp(p,.5,.68)).toFixed(4));
  intro.style.setProperty('--scene-night',(reduced.matches?.8:ramp(p,.5,.77)).toFixed(4));
  const reveal=reduced.matches?1:ramp(p,.77,.985);
  intro.style.setProperty('--scene-copy',reveal.toFixed(4));
  intro.dataset.phase=reduced.matches?'static':p<.13?'day':p<.68?'sunset':p<.77?'night':reveal>=.999?'reading':'title';
  intro.dataset.progress=p.toFixed(4);
  document.body.classList.toggle('workspace-in-view',scrollY>start+span+reading*.25);
 }
 function render(now){
  frame=0;if(document.hidden||!entered)return;
  const dt=last?Math.min(48,now-last):16.7;last=now;
  current+=(target-current)*(reduced.matches?1:1-Math.exp(-dt/80));
  if(Math.abs(target-current)<.00008)current=target;
  draw(current);if(current!==target)frame=requestAnimationFrame(render);else last=0;
 }
 function request(){target=reduced.matches?1:clamp((scrollY-start)/span);if(entered&&!frame&&!document.hidden)frame=requestAnimationFrame(render);}
 function measure(){
  const h=stage.offsetHeight;span=Math.max(620,h*1.22);reading=Math.max(230,h*.38);
  intro.style.height=(reduced.matches?h:h+span+reading)+'px';intro.style.setProperty('--scene-sun-drop',h*.28+'px');
  start=intro.getBoundingClientRect().top+scrollY;request();
 }
 function waitForBoot(){return new Promise(resolve=>{
  const ready=()=>!document.documentElement.classList.contains('q-booting')&&!document.documentElement.classList.contains('q-boot-visible');
  if(ready()){resolve();return;}const observer=new MutationObserver(()=>{if(ready()){observer.disconnect();resolve();}});observer.observe(document.documentElement,{attributes:true,attributeFilter:['class']});
 });}
 async function entrance(){
  const version=++revision;
  await Promise.allSettled([waitForBoot(),picturesReady]);
  if(version!==revision)return;
  if(reduced.matches||typeof scene.animate!=='function'||location.hash==='#workspace'||scrollY>start+span){entered=true;intro.dataset.entrance='settled';current=target;draw(current);request();return;}
  intro.dataset.entrance='playing';entry=scene.animate([
   {clipPath:'inset(8% 49% round 18px)',transform:'scale(.72)',filter:'blur(8px)',opacity:0},
   {clipPath:'inset(0% 0% round 0px)',transform:'scale(1)',filter:'blur(0px)',opacity:1}
  ],{duration:800,easing:'cubic-bezier(.72,0,.16,1)',fill:'both'});
  if(document.hidden)entry.pause();try{await entry.finished;}catch{}
  if(version!==revision)return;intro.dataset.entrance='settled';entry.cancel();entry=null;entered=true;request();
 }
 window.addEventListener('scroll',request,{passive:true});
 window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(measure,150);},{passive:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;last=0;entry?.pause();}else{entry?.play();request();}});
 reduced.addEventListener('change',()=>{revision++;entry?.cancel();entry=null;entered=true;intro.dataset.entrance='settled';measure();current=target;draw(current);});
 window.addEventListener('pagehide',()=>{cancelAnimationFrame(frame);entry?.pause();});
 window.addEventListener('pageshow',event=>{if(event.persisted){entry?.play();measure();request();}});
 window.addEventListener('hashchange',request);
 measure();draw(0);entrance();
 if(location.hash==='#workspace')requestAnimationFrame(()=>{workspace.scrollIntoView({behavior:'instant'});request();});
})();
