(function(){
 'use strict';const hero=document.querySelector('.orbit-hero');if(!hero)return;
 const tiles=[...hero.querySelectorAll('.orbit-tile')],toggle=document.querySelector('#orbitToggle'),reduced=matchMedia('(prefers-reduced-motion:reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
 let angle=-.4,frame=0,last=0,width=0,height=0,hovered=null,focused=null,paused=false,inView=true;
 function paint(){const small=width<700,rx=Math.min(width*(small ? .34 : .29),365),ry=Math.min(height*(small ? .30 : .33),222),cx=width/2,cy=height*.45;
  tiles.forEach((tile,i)=>{const t=i*2*Math.PI/tiles.length+angle,x=Math.cos(t)*rx,y=Math.sin(t)*ry,px=x*.97-y*.16,py=x*.16+y*.97,depth=(Math.sin(t)+1)/2,selected=tile===hovered||tile===focused;
   tile.style.transform='translate3d('+px.toFixed(2)+'px,'+py.toFixed(2)+'px,0) rotate('+(selected?0:-7+Math.cos(t)*11).toFixed(1)+'deg) rotateY('+(selected?0:Math.cos(t)*36).toFixed(1)+'deg) scale('+(selected?1:.79+depth*.22).toFixed(3)+')';
   tile.style.zIndex=selected?'20':String(2+Math.round(depth*6));tile.style.setProperty('--tile-depth',(.68+depth*.32).toFixed(2));
   const growW=small?268:308,growH=small?196:218,sx=Math.max(14+growW/2-(cx+px),Math.min(0,width-14-growW/2-(cx+px))),sy=Math.max(14+growH/2-(cy+py),Math.min(0,height-95-growH/2-(cy+py)));
   tile.style.setProperty('--expand-x',sx.toFixed(1)+'px');tile.style.setProperty('--expand-y',sy.toFixed(1)+'px');
  });
 }
 function blocked(){return paused||!!hovered||!!focused||document.hidden||!inView||reduced.matches||!!document.querySelector('dialog[open]');}
 function sync(){const stop=blocked();hero.dataset.motion=stop?'paused':'running';hero.classList.toggle('has-active-tile',!!hovered||!!focused);toggle.textContent=paused?'继续旋转':'暂停旋转';toggle.setAttribute('aria-pressed',String(paused));if(stop){if(frame)cancelAnimationFrame(frame);frame=0;last=0;}else if(!frame)frame=requestAnimationFrame(tick);}
 function tick(now){frame=0;if(blocked())return;const dt=last?Math.min(40,now-last):0;last=now;angle+=dt*.000075;paint();frame=requestAnimationFrame(tick);}
 for(const tile of tiles){tile.addEventListener('pointerenter',()=>{if(!fine.matches)return;hovered=tile;tile.classList.add('is-active');paint();sync();});tile.addEventListener('pointerleave',()=>{if(hovered===tile)hovered=null;if(focused!==tile)tile.classList.remove('is-active');sync();});tile.addEventListener('focus',()=>{focused=tile;tile.classList.add('is-active');paint();sync();});tile.addEventListener('blur',()=>{if(focused===tile)focused=null;if(hovered!==tile)tile.classList.remove('is-active');sync();});tile.addEventListener('keydown',e=>{if(e.key==='Escape'){tile.blur();hovered=null;tile.classList.remove('is-active');sync();}});}
 toggle.addEventListener('click',()=>{paused=!paused;sync();});
 new ResizeObserver(entries=>{width=entries[0].contentRect.width;height=entries[0].contentRect.height;paint();sync();}).observe(hero);
 new IntersectionObserver(entries=>{inView=entries[0].isIntersecting;sync();}).observe(hero);
 new MutationObserver(sync).observe(document.body,{subtree:true,attributes:true,attributeFilter:['open']});document.addEventListener('visibilitychange',sync);reduced.addEventListener('change',sync);
})();
