/* Qingru material parser and deterministic teaching draft compiler.
 * The original blocks stay intact; extracted summaries never replace sources.
 */
(function(root){
 'use strict';
 const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const clean=s=>String(s??'').replace(/\r/g,'').replace(/[\t\u00a0]+/g,' ').replace(/ +/g,' ').trim();
 const shorten=(s,n=50)=>{s=clean(s);return s.length>n?s.slice(0,n-1)+'…':s;};
 const sentences=s=>String(s).split(/(?<=[。！？；\n])/).map(clean).filter(Boolean);
 const texts=node=>Array.from(node?.getElementsByTagNameNS('*','t')||[]).map(n=>n.textContent).join('');
 function xml(s){const d=new DOMParser().parseFromString(s,'application/xml');if(d.getElementsByTagName('parsererror').length)throw Error('文件中的XML内容无法解析。');return d;}
 function math(n){if(!n)return'';const key=n.localName,els=Array.from(n.children||[]),part=k=>els.find(c=>c.localName===k);if(key==='f')return'('+math(part('num'))+')/('+math(part('den'))+')';if(key==='sSup')return math(part('e'))+'^('+math(part('sup'))+')';if(key==='sSub')return math(part('e'))+'_('+math(part('sub'))+')';if(key==='t')return n.textContent;return els.map(math).join('');}
 function paragraph(node){let result='';function walk(n){if(n.nodeType!==1)return;const k=n.localName;if(k==='oMath'||k==='oMathPara'){result+=math(n);return;}if(k==='t'){result+=n.textContent;return;}if(k==='tab')result+=' ';else if(k==='br')result+='\n';else for(const c of n.children)walk(c);}walk(node);return clean(result);}
 const heading=s=>s.length<90&&(/^(第[一二三四五六七八九十百\d]+[章节篇部分]|[一二三四五六七八九十]+[、．.]|\d+(?:\.\d+){0,3}[、.\s])/u.test(s)||/^(导论|绪论|课程说明|学习目标|本章小结|知识总结|案例分析|思考题|练习题)$/.test(s));
 function classify(block){const t=block.text||'';if(block.kind==='table')return'table';if(block.kind==='image')return'image';if(heading(t))return'heading';if(/[=＝]|[αβγδΔ]/.test(t)&&t.length<200)return'formula';if(/步骤|首先|其次|第一步|第二步/.test(t))return'steps';if(/条件|假设|适用|除非|其他.*不变/.test(t))return'condition';if(/案例|例如|假设.*元|示例/.test(t))return'example';return'concept';}
 function packText(name,text){const blocks=text.split(/\n+/).map(clean).filter(Boolean).map((text,i)=>({id:'p'+(i+1),kind:'paragraph',text,style:heading(text)?'heading':''}));if(!blocks.length)throw Error('没有读取到可用文字，请检查文件内容。');return{name,blocks};}
 async function parseFile(file,progress=()=>{}){
  const ext=file.name.split('.').pop().toLowerCase();if(file.size>20*1024*1024)throw Error('单个文件请控制在20MB以内。');progress('正在读取 '+file.name);
  if(['txt','md'].includes(ext)){const bytes=new Uint8Array(await file.arrayBuffer());let text=new TextDecoder('utf-8').decode(bytes);if(text.includes('\ufffd'))text=new TextDecoder('gb18030').decode(bytes);return packText(file.name,text);}
  if(ext==='pdf'){
   if(location.protocol==='file:')throw Error('PDF请在网页访问地址中导入；离线直接打开时可使用DOCX、PPTX或TXT。');
   const pdf=await import('./vendor/pdfjs-dist/build/pdf.mjs?v=6.5.438');pdf.GlobalWorkerOptions.workerSrc=new URL('./vendor/pdfjs-dist/build/pdf.worker.mjs?v=6.5.438',location.href).href;
   const loading=pdf.getDocument({data:new Uint8Array(await file.arrayBuffer()),isEvalSupported:false,cMapUrl:new URL('./vendor/pdfjs-dist/cmaps/',location.href).href,cMapPacked:true,standardFontDataUrl:new URL('./vendor/pdfjs-dist/standard_fonts/',location.href).href,wasmUrl:new URL('./vendor/pdfjs-dist/wasm/',location.href).href}),doc=await loading.promise;
   const blocks=[];try{for(let i=1;i<=doc.numPages;i++){progress('解析PDF '+i+' / '+doc.numPages+'页');const p=await doc.getPage(i),c=await p.getTextContent();let line='',lastY=null;for(const item of c.items){if(!item.str)continue;const y=item.transform?.[5];if(lastY!==null&&Math.abs(y-lastY)>3&&line){blocks.push({kind:'paragraph',text:clean(line),page:i});line='';}line+=item.str+(item.hasEOL?'\n':' ');lastY=y;}if(clean(line))blocks.push({kind:'paragraph',text:clean(line),page:i});p.cleanup();}}finally{await loading.destroy();}
   if(!blocks.length)throw Error('此PDF未包含可提取文字，可能是扫描件。请使用带文字层的PDF或DOCX。');return{name:file.name,blocks};
  }
  if(!['docx','pptx'].includes(ext))throw Error('请导入DOCX、PPTX、文字型PDF、TXT或Markdown文件。');
  if(!root.fflate)throw Error('文件解析组件未加载，请刷新页面。');
  let total=0;const entries=root.fflate.unzipSync(new Uint8Array(await file.arrayBuffer()),{filter:f=>{const include=ext==='docx'?/^word\/(document\.xml|styles\.xml|_rels\/document\.xml\.rels|media\/)/.test(f.name):/^ppt\/slides\/slide\d+\.xml$/.test(f.name);if(include){total+=f.originalSize;if(total>80*1024*1024)throw Error('解压后的材料过大，请拆分章节后导入。');}return include;}});
  const blocks=[];
  if(ext==='docx'){
   if(!entries['word/document.xml'])throw Error('DOCX文件缺少正文。');const doc=xml(root.fflate.strFromU8(entries['word/document.xml'])),body=doc.getElementsByTagNameNS('*','body')[0];
   const ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main',levels=new Map();if(entries['word/styles.xml'])for(const s of xml(root.fflate.strFromU8(entries['word/styles.xml'])).getElementsByTagNameNS('*','style')){const name=s.getElementsByTagNameNS('*','name')[0]?.getAttributeNS(ns,'val')||'',outline=s.getElementsByTagNameNS('*','outlineLvl')[0]?.getAttributeNS(ns,'val'),match=name.match(/(?:heading|标题)\s*([1-6])/i);if(outline!==undefined&&Number(outline)<6)levels.set(s.getAttributeNS(ns,'styleId'),Number(outline)+1);else if(match)levels.set(s.getAttributeNS(ns,'styleId'),Number(match[1]));}
   const rels=new Map();if(entries['word/_rels/document.xml.rels'])for(const r of xml(root.fflate.strFromU8(entries['word/_rels/document.xml.rels'])).getElementsByTagName('Relationship'))rels.set(r.getAttribute('Id'),r.getAttribute('Target'));
   for(const node of body.children){
    if(node.localName==='p'){const text=paragraph(node),style=node.getElementsByTagNameNS('*','pStyle')[0]?.getAttributeNS(ns,'val')||'';if(text)blocks.push({kind:'paragraph',text,style,heading_level:levels.get(style)||null});
     for(const image of node.getElementsByTagNameNS('*','blip')){const id=image.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','embed'),target=rels.get(id),bytes=entries['word/'+target];if(bytes&&bytes.length<4*1024*1024&&/\.(png|jpe?g|webp)$/i.test(target)){let binary='';for(let at=0;at<bytes.length;at+=8192)binary+=String.fromCharCode(...bytes.subarray(at,at+8192));const mime=/\.png$/i.test(target)?'image/png':/\.webp$/i.test(target)?'image/webp':'image/jpeg';blocks.push({kind:'image',text:'原文插图',images:['data:'+mime+';base64,'+btoa(binary)]});}}
    }else if(node.localName==='tbl'){const rows=Array.from(node.children).filter(n=>n.localName==='tr').map(row=>Array.from(row.children).filter(n=>n.localName==='tc').map(c=>Array.from(c.getElementsByTagNameNS('*','p')).map(paragraph).join('\n')));if(rows.length)blocks.push({kind:'table',rows,text:rows.map(r=>r.join(' | ')).join('\n')});}
   }
  }else{
   const keys=Object.keys(entries).sort((a,b)=>Number(a.match(/slide(\d+)/)[1])-Number(b.match(/slide(\d+)/)[1]));for(const[keyIndex,key]of keys.entries()){const doc=xml(root.fflate.strFromU8(entries[key])),parts=Array.from(doc.getElementsByTagNameNS('*','p')).map(texts).map(clean).filter(Boolean);parts.forEach((text,i)=>blocks.push({kind:'paragraph',text,style:i===0?'heading':'',heading_level:i===0?1:null,page:keyIndex+1}));}
  }
  if(!blocks.length)throw Error('没有读取到文字或表格，请确认文件有效。');return{name:file.name,blocks};
 }
 function compile(materials,title){
  if(!materials.length)throw Error('请先导入材料。');let n=0;const blocks=materials.flatMap(m=>m.blocks.map(b=>({...b,id:'src-'+(++n),source_name:m.name})));if(n>20000)throw Error('材料超过本次可处理规模，请按章节分开创建。');
  const groups=[];let current={title:title||materials[0].name.replace(/\.[^.]+$/,''),blocks:[]};
  for(const b of blocks){const t=b.text||'',isHeading=b.heading_level?b.heading_level<=2:t.length<90&&(/^(第[一二三四五六七八九十百\d]+[章节篇部分])/u.test(t)||/^(导论|绪论|课程说明|学习目标|本章小结|知识总结|案例分析|思考题|练习题)$/.test(t));if(isHeading&&current.blocks.length){groups.push(current);current={title:shorten(t,65),blocks:[]};}else if(isHeading&&!current.blocks.length)current.title=shorten(t,65);current.blocks.push(b);}if(current.blocks.length)groups.push(current);
  const lessons=[],sections=[],quizzes=[];
  groups.forEach((g,i)=>{const sid='section-'+(i+1),parts=[];let chunk=[],size=0;for(const b of g.blocks){const len=(b.text||'').length;if(chunk.length&&(size+len>750||chunk.length>=5)){parts.push(chunk);chunk=[];size=0;}chunk.push(b);size+=len;}if(chunk.length)parts.push(chunk);const section={id:sid,title:g.title,chapter_title:'导入材料',lesson_ids:[]};
   parts.forEach((bs,k)=>{const meaningful=bs.filter(b=>b.kind!=='image'&&classify(b)!=='heading'&&!b.heading_level),text=meaningful.map(b=>b.text||'').join('\n'),type=bs.some(b=>b.kind==='table')?'table':bs.some(b=>classify(b)==='formula')?'formula':bs.some(b=>classify(b)==='steps')?'steps':'reading';const id=sid+'-page-'+(k+1);lessons.push({id,title:g.title+(parts.length>1?' · '+(k+1):''),short:g.title,section_id:sid,section_title:g.title,body:sentences(text).slice(0,2).join('')||'阅读本节原文，核对概念与条件。',sources:bs.map(b=>b.id),blocks:bs,layout:type});section.lesson_ids.push(id);});sections.push(section);
   const sentence=g.blocks.flatMap(b=>sentences(b.text||'')).find(s=>s.length>=18&&s.length<=110&&/[是指为]|表示|取决于|需要/.test(s));if(sentence&&quizzes.length<12)quizzes.push({section_id:sid,q:'根据“'+g.title+'”的原文，哪项表述有材料依据？',options:[sentence,'本段结论在任何条件下都必然成立。','原文并未给出相关概念或判断依据。'],answer:0,why:'原文表述为：“'+sentence+'”请结合该段条件理解。',source:g.blocks.find(b=>(b.text||'').includes(sentence))?.id||g.blocks[0].id});
  });
  const summary=sections.map(s=>({title:s.title,text:lessons.filter(p=>p.section_id===s.id).flatMap(p=>sentences(p.body)).slice(0,2).join('')}));
  return{id:'draft-'+Date.now().toString(36),kind:'document',title:clean(title)||materials[0].name.replace(/\.[^.]+$/,''),source:materials.map(m=>m.name).join('、'),source_section:'导入材料',source_blocks:blocks,lessons,sections,quizzes,faq:[],summary,coverage:{preserved_blocks:blocks.length,source_blocks:blocks.length},materials:materials.map(m=>({name:m.name,blocks:m.blocks.length})),created_at:new Date().toISOString(),teacher:'qingru',media_state:'awaiting-production',compiler:'qingru-source-preserving-draft-v1'};
 }
 const table=rows=>'<div class="table-scroll"><table class="data-table"><thead><tr>'+rows[0].map(c=>'<th>'+escape(c)+'</th>').join('')+'</tr></thead><tbody>'+rows.slice(1).map(r=>'<tr>'+r.map(c=>'<td>'+escape(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';
 function details(lesson){return'<div class="source-reading">'+(lesson.blocks||[]).map(b=>b.rows?table(b.rows):b.kind==='image'?(b.images||[]).map(src=>'<img src="'+escape(src)+'" alt="原文插图">').join(''):'<p class="'+(classify(b)==='formula'?'math-line':'')+'">'+escape(b.text)+'</p>').join('')+'</div>';}
 function visual(lesson){const blocks=lesson.blocks||[],label={table:'表格读解',formula:'公式与关系',steps:'推理步骤',reading:'概念与条件'}[lesson.layout]||'知识讲解';const words=blocks.filter(b=>!b.rows&&b.kind!=='image').flatMap(b=>sentences(b.text)).filter(s=>s!==lesson.short).slice(0,3);return'<span class="lesson-type">'+label+'</span><div class="reading-points">'+words.map(s=>'<p>'+escape(shorten(s,48))+'</p>').join('')+'</div>';}
 function unpack(text){
  const p=JSON.parse(text),c=p.course;
  if(p.format!=='qingru-classroom-package-v1'||!c||c.kind!=='document'||typeof c.title!=='string'||!Array.isArray(c.source_blocks)||!Array.isArray(c.lessons)||!Array.isArray(c.sections)||!Array.isArray(c.quizzes)||!c.lessons.length||c.lessons.length>20000||c.source_blocks.length>20000)throw Error('这不是有效的清如课堂包，请选择导出的.qingru.json文件。');
  const validBlock=b=>b&&typeof b.id==='string'&&typeof b.text==='string'&&(!b.rows||Array.isArray(b.rows)&&b.rows.every(r=>Array.isArray(r)&&r.every(v=>typeof v==='string')))&&(!b.images||Array.isArray(b.images)&&b.images.every(v=>typeof v==='string'&&/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v)));
  if(!c.source_blocks.every(validBlock)||!c.lessons.every(l=>l&&typeof l.id==='string'&&typeof l.title==='string'&&typeof l.body==='string'&&Array.isArray(l.sources)&&Array.isArray(l.blocks)&&l.blocks.every(validBlock))||!c.sections.every(s=>s&&typeof s.id==='string'&&typeof s.title==='string'&&Array.isArray(s.lesson_ids))||!c.quizzes.every(q=>q&&typeof q.q==='string'&&typeof q.why==='string'&&Array.isArray(q.options)&&q.options.every(v=>typeof v==='string')&&Number.isInteger(q.answer)&&q.answer>=0&&q.answer<q.options.length))throw Error('课堂包内容不完整，请重新导出后导入。');
  c.id='draft-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6);c.created_at=new Date().toISOString();c.media_state='awaiting-production';c.teacher='qingru';delete c.lecture;c.faq=[];return c;
 }
 root.QingruContent={escape,clean,shorten,parseFile,packText,compile,details,visual,classify,heading,unpack};
})(globalThis);
