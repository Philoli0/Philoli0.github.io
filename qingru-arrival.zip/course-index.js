(function(root){
 'use strict';
 function build(course){
  const bySection=new Map(),pages=course.lessons.map((lesson,index)=>({lesson,index,text:(lesson.title+' '+lesson.short).toLowerCase()}));
  for(const page of pages){const key=page.lesson.section_id;if(!bySection.has(key))bySection.set(key,[]);bySection.get(key).push(page);}
  const sections=(course.sections?.length?course.sections:[{id:pages[0]?.lesson.section_id,title:course.title,chapter_title:'课程内容'}]).map(section=>({section,pages:bySection.get(section.id)||[],text:((section.chapter_title||'课程内容')+' '+section.title).toLowerCase()})).filter(x=>x.pages.length);
  function search(query=''){
   const chapters=new Map(),q=query.trim().toLowerCase();
   for(const row of sections){const sectionMatch=!q||row.text.includes(q),filtered=sectionMatch?row.pages:row.pages.filter(p=>p.text.includes(q));if(!filtered.length)continue;const chapter=row.section.chapter_title||'课程内容';if(!chapters.has(chapter))chapters.set(chapter,[]);chapters.get(chapter).push({s:row.section,pages:row.pages,filtered,sectionMatch});}
   return chapters;
  }
  return{pages,sections,bySection,search};
 }
 root.QingruCourseIndex={build};
})(typeof window==='undefined'?globalThis:window);
