/* One tab, one destination. Enter returns only when it cannot conflict with an action. */
(function(){
 'use strict';
 function normalize(root){if(!root?.querySelectorAll)return;for(const a of root.querySelectorAll('a[target="_blank"]'))a.removeAttribute('target');}
 normalize(document);
 const observer=new MutationObserver(entries=>{for(const entry of entries){if(entry.type==='attributes'){if(entry.target.getAttribute('target')==='_blank')entry.target.removeAttribute('target');}else for(const n of entry.addedNodes)if(n.nodeType===1){if(n.matches?.('a[target="_blank"]'))n.removeAttribute('target');normalize(n);}}});
 if(document.body)observer.observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['target']});
 document.addEventListener('keydown',event=>{
  if(event.key!=='Enter'||event.defaultPrevented||event.repeat||event.isComposing||event.altKey||event.ctrlKey||event.metaKey||event.shiftKey)return;
  const back=document.querySelector('.workbench-return');if(!back||document.documentElement.classList.contains('report-embedded')||document.querySelector('dialog[open]'))return;
  const target=event.target;if(target?.closest?.('input,textarea,select,button,a,summary,video,audio,[contenteditable],[role="button"],[role="textbox"],[role="slider"]'))return;
  event.preventDefault();back.click();
 });
})();
