(function(){
 'use strict';const stage=document.querySelector('#colourstage');if(!stage)return;
 const panels=[...stage.querySelectorAll('[data-panel]')],fine=matchMedia('(hover:hover) and (pointer:fine)');
 let hovered=null,focused=null;function sync(){stage.dataset.active=(hovered||focused)?.dataset.panel||'';}
 for(const panel of panels){panel.addEventListener('pointerenter',()=>{if(fine.matches){hovered=panel;sync();}});panel.addEventListener('pointerleave',()=>{if(hovered===panel)hovered=null;sync();});panel.addEventListener('focusin',()=>{focused=panel;sync();});panel.addEventListener('focusout',e=>{if(!panel.contains(e.relatedTarget)){focused=null;sync();}});}
 if('IntersectionObserver'in window&&!matchMedia('(prefers-reduced-motion: reduce)').matches){stage.classList.add('motion-armed');panels.forEach((p,i)=>p.querySelector('.panel-copy').style.setProperty('--panel-delay',i*75+'ms'));const observer=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){stage.classList.add('is-in-view');observer.disconnect();}},{threshold:.08});observer.observe(stage);}
 document.addEventListener('visibilitychange',()=>{if(document.hidden){hovered=null;sync();}});
})();
