Noto Sans SC from https://github.com/google/fonts/tree/main/ofl/notosanssc
SIL Open Font License 1.1; included as OFL.txt.
Locally subset and renamed for Qingru. UI and course-reading glyph ranges are disjoint.
Weight range 400–750 retained; outlines are unchanged.
