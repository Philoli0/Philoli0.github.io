(function(){
 'use strict';
 const el=id=>document.getElementById(id),esc=s=>window.QingruContent.escape(String(s??''));
 let currentIndex=0,videoMode=false,search='',indexedCourse=null,indexed=null,renderKey='',initialized=false,searchFrame=0;
 function catalog(){
  const c=window.QINGRU_COURSE_DATA,active=c.lessons[currentIndex],box=el('catalog');
  if(indexedCourse!==c){indexedCourse=c;indexed=window.QingruCourseIndex.build(c);renderKey='';}
  function selection(){const old=box.querySelector('.unit.active');if(old){old.classList.remove('active');old.removeAttribute('aria-current');}const next=box.querySelector('.unit[data-index="'+currentIndex+'"]');if(next){next.classList.add('active');next.setAttribute('aria-current','step');}el('chapterField').hidden=true;el('count').textContent=c.lessons.length+' 页';}
  const key=(active.section_id||'')+'|'+search;
  if(renderKey===key){selection();return;}
  renderKey=key;
  const opened=new Set([...box.querySelectorAll('details[open]')].map(d=>d.dataset.chapter));
  const page=({lesson:l,index:i})=>'<button class="unit'+(i===currentIndex?' active':'')+'" data-index="'+i+'"'+(i===currentIndex?' aria-current="step"':'')+'><span>'+String(i+1).padStart(2,'0')+'</span><span class="unit-title">'+esc(l.title)+'</span></button>';
  if(c.kind!=='document'){
   const groups=[['建立理解',0,3],['推理与应用',3,9],['巩固练习',9,c.lessons.length]];
   box.innerHTML=groups.map(([title,start,end])=>{const list=indexed.pages.slice(start,end).filter(p=>!search||p.text.includes(search));return list.length?'<div class="catalog-group"><h3>'+title+'</h3>'+list.map(page).join('')+'</div>':'';}).join('');
  }else{
   box.innerHTML=[...indexed.search(search)].map(([chapter,sections])=>{const activeChapter=sections.some(({s})=>s.id===active.section_id);return '<details class="catalog-chapter" data-chapter="'+esc(chapter)+'"'+(search||activeChapter||opened.has(chapter)?' open':'')+'><summary><span>'+esc(chapter)+'</span><small>'+sections.length+' 节</small></summary><div>'+sections.map(({s,pages,filtered,sectionMatch})=>'<button class="section-link'+(s.id===active.section_id?' current':'')+'" data-index="'+pages[0].index+'"><span>'+esc(s.title)+'</span><small>'+pages.length+' 页</small></button>'+((s.id===active.section_id||Boolean(search&&!sectionMatch))?'<div class="section-pages">'+filtered.map(page).join('')+'</div>':'')).join('')+'</div></details>';}).join('');
  }
  if(!box.innerHTML)box.innerHTML='<p class="catalog-empty">没有找到相关内容，请换个关键词。</p>';
  for(const b of box.querySelectorAll('[data-index]'))b.onclick=()=>{const next=Number(b.dataset.index);if(next!==currentIndex)window.QingruNavigateLesson(next);else{mode(false);if(window.matchMedia('(max-width:900px)').matches)closeCatalog();}};
  selection();
 }
 function mode(isVideo){
  videoMode=Boolean(isVideo&&window.QINGRU_COURSE_DATA.lecture?.url);
  el('stage').classList.toggle('video-mode',videoMode);
  el('courseView').classList.toggle('watching-video',videoMode);
  el('videoMode').setAttribute('aria-pressed',String(videoMode));el('slideMode').setAttribute('aria-pressed',String(!videoMode));
  el('lessonVideo').hidden=!videoMode;el('posterPlay').hidden=!videoMode||!el('lessonVideo').paused;
  if(!videoMode)el('lessonVideo').pause();
  document.querySelector('.page-transport').hidden=videoMode;
  el('contextLabel').textContent=videoMode?'本节精讲':'本页要点';
  el('lessonBrief').textContent=videoMode?'从排队与滞销的生活情境出发，理解均衡价格、市场调整与供求变化。切换动态课件，可继续操作图表并完成练习。':window.QINGRU_COURSE_DATA.lessons[currentIndex].body;
  el('lectureStart').hidden=!videoMode;
 }
 function refresh(lesson,index){
  const previousIndex=currentIndex;currentIndex=index;el('slide').scrollTop=0;
  const c=window.QINGRU_COURSE_DATA,extra=el('interactive'),stage=el('stage');
  const showInteraction=c.kind!=='document'&&Boolean(extra.innerHTML.trim());
  stage.classList.toggle('interaction-mode',showInteraction);stage.classList.toggle('reading-mode',c.kind==='document');
  stage.dataset.layout=c.kind==='document'?'document':lesson.id;
  const categories={opening:'情境导入',definition:'核心概念',table:'数据读解',adjustment:'动态推演',linear:'模型求解',shifts:'动态推演',both:'条件比较',model:'模型条件',cobweb:'时间推演',quiz:'理解练习'};
  el('slideCategory').textContent=c.kind==='document'?'教材课堂':categories[lesson.id]||'知识讲解';
  el('stageCaption').hidden=true;el('lessonVisual').hidden=showInteraction;
  extra.hidden=false;(showInteraction?el('stageInteraction'):el('readingDetail')).appendChild(extra);
  if(c.kind==='document'){
   const picture=(lesson.blocks||[]).flatMap(b=>b.images||[])[0];
   if(picture)el('lessonVisual').innerHTML='<figure class="source-figure"><img src="'+esc(picture)+'" alt="本页教材原图"><figcaption>教材原图</figcaption></figure>';
  }
  if(c.kind!=='document'&&!showInteraction){
   const note=document.createElement('div');note.className='slide-explanation';note.innerHTML='<span>关键理解</span><p>'+esc(lesson.body)+'</p>';el('lessonVisual').appendChild(note);
  }
  const quizCards=[...extra.querySelectorAll('.quiz')];
  for(const card of quizCards)for(const button of card.querySelectorAll('[data-option]')){const text=button.textContent.trim(),letter=text.slice(0,1),answer=text.slice(1).trim();button.setAttribute('aria-label',letter+' '+answer);button.innerHTML='<span class="option-mark">'+esc(letter)+'</span><span>'+esc(answer)+'</span>';}

  if(showInteraction&&quizCards.length){
   let question=0,lastQuestion=-1;const pager=document.createElement('div');pager.className='quiz-pager';pager.innerHTML='<button class="quiz-back" aria-label="上一题"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="m14 6-6 6 6 6"/></svg></button><div class="question-position"><span aria-live="polite"></span><div class="question-track" aria-hidden="true">'+quizCards.map(()=>'<i></i>').join('')+'</div></div><button class="quiz-forward" aria-label="下一题"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="m10 6 6 6-6 6"/></svg></button>';extra.appendChild(pager);
   const render=()=>{el('slide').scrollTop=0;quizCards.forEach((card,k)=>card.hidden=k!==question);pager.querySelector('span').textContent=(question+1)+' / '+quizCards.length;pager.querySelectorAll('.question-track i').forEach((mark,k)=>mark.classList.toggle('current',k===question));pager.querySelector('.quiz-back').disabled=question===0;pager.querySelector('.quiz-forward').disabled=question===quizCards.length-1;if(lastQuestion!==-1)window.QingruMotion?.enter(quizCards[question],question<lastQuestion?-1:1);lastQuestion=question;};
   pager.querySelector('.quiz-back').onclick=()=>{question--;render();};pager.querySelector('.quiz-forward').onclick=()=>{question++;render();};render();
  }
  el('pageLabel').textContent=(index+1)+' / '+c.lessons.length;el('pageSource').textContent='查看本页 '+lesson.sources.length+' 条原文';
  mode(false);catalog();el('roomMenu').open=false;
  if(initialized)window.QingruMotion?.enter(el('slide'),index<previousIndex?-1:1);
  if(window.matchMedia('(max-width:900px)').matches)closeCatalog();
 }
 function closeCatalog(){document.body.classList.remove('catalog-open');el('sidebarScrim').hidden=true;el('catalogToggle').setAttribute('aria-expanded','false');el('catalogToggle').setAttribute('aria-label','展开课程目录');}
 function open(id){el('lessonVideo').pause();el('roomMenu').open=false;el(id).showModal();}
 async function play(){
  mode(true);const v=el('lessonVideo');el('mediaStatus').hidden=true;
  if(!v.paused){v.pause();return;}
  el('answerAudio').pause();el('demoVideo').pause();if(v.ended)v.currentTime=0;
  try{await v.play();}catch{el('mediaStatus').textContent='暂时无法播放，请检查网络后重试。';el('mediaStatus').hidden=false;}
 }
 function init(course){
  document.body.classList.add('classroom-ready');el('courseView').setAttribute('aria-busy','false');
  for(const id of ['catalogToggle','openNotes','openQA','courseSwitch','slideMode'])el(id).disabled=false;
  const hasVideo=Boolean(course.lecture?.url);el('videoMode').hidden=!hasVideo;el('videoMode').disabled=!hasVideo;
  el('lectureStart').disabled=!hasVideo;el('lectureStart').textContent='播放';el('roomMode').textContent=hasVideo?'数字讲师课堂':'资料课堂';
  const courses=window.QingruLibrary.courses;
  el('courseSwitch').innerHTML=courses.map(c=>'<option value="'+esc(c.id)+'">'+esc(c.title)+'</option>').join('')+(course.id?.startsWith('draft-')?'<option value="'+esc(course.id)+'">'+esc(course.title)+'</option>':'');
  el('courseSwitch').value=course.id;
  el('courseSwitch').onchange=()=>{const chosen=courses.find(c=>c.id===el('courseSwitch').value);if(chosen)location.href=window.QingruMotion?.url(chosen.url)||chosen.url;};
  el('openNotes').onclick=()=>open('notesDialog');el('openQA').onclick=()=>open('qaDialog');
  el('videoMode').onclick=()=>mode(true);el('slideMode').onclick=()=>mode(false);el('lectureStart').onclick=play;el('posterPlay').onclick=play;
  const v=el('lessonVideo');
  v.controls=false;
  const waiting=document.createElement('div');waiting.className='media-wait';waiting.hidden=true;waiting.setAttribute('role','status');waiting.setAttribute('aria-label','正在缓冲视频');waiting.innerHTML='<span class="eye-loader" aria-hidden="true"></span>';el('stage').appendChild(waiting);let waitTimer=0;
  const clearWait=()=>{clearTimeout(waitTimer);waiting.hidden=true;};
  v.addEventListener('waiting',()=>{clearTimeout(waitTimer);waitTimer=setTimeout(()=>{if(!v.paused&&!v.ended)waiting.hidden=false;},180);});for(const name of ['playing','pause','ended','error'])v.addEventListener(name,clearWait);

  v.addEventListener('play',()=>{v.controls=true;el('lectureStart').textContent='暂停';el('posterPlay').hidden=true;});
  v.addEventListener('pause',()=>{el('lectureStart').textContent=v.ended?'重新播放':'继续播放';el('posterPlay').hidden=!videoMode;});
  v.onended=()=>{el('lectureStart').textContent='重新播放';el('posterPlay').hidden=false;};
  v.addEventListener('error',()=>{if(hasVideo){el('mediaStatus').textContent='视频未能载入，请刷新页面后重试。';el('mediaStatus').hidden=false;}});
  function duration(){if(Number.isFinite(v.duration))el('mediaDuration').textContent=Math.floor(v.duration/60)+':'+String(Math.round(v.duration%60)).padStart(2,'0');}
  v.addEventListener('loadedmetadata',duration);duration();
  el('catalogSearch').oninput=e=>{search=e.target.value.trim().toLowerCase();if(!searchFrame)searchFrame=requestAnimationFrame(()=>{searchFrame=0;catalog();});};
  el('catalogToggle').onclick=()=>{const expanded=document.body.classList.toggle('catalog-open');el('sidebarScrim').hidden=!expanded;el('catalogToggle').setAttribute('aria-expanded',String(expanded));el('catalogToggle').setAttribute('aria-label',expanded?'收起课程目录':'展开课程目录');};
  el('catalogClose').onclick=closeCatalog;
  el('sidebarScrim').onclick=closeCatalog;
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeCatalog();});
  document.addEventListener('click',e=>{if(!el('roomMenu').contains(e.target))el('roomMenu').open=false;});
  for(const b of el('roomMenu').querySelectorAll('button'))b.addEventListener('click',()=>{el('roomMenu').open=false;});
  for(const d of document.querySelectorAll('dialog'))d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}});
  mode(hasVideo&&currentIndex===0);catalog();initialized=true;window.QingruBoot?.ready();
  if(new URLSearchParams(location.search).get('tool')==='qa')open('qaDialog');
 }
 window.QingruClassroom={refresh,init,managesCatalog:true};
})();
