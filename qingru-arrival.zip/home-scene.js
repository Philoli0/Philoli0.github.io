/* Scene -> name -> workbench. The opening never blocks a user action. */
(function(){
 'use strict';
 const intro=document.querySelector('.scene-intro'),stage=intro?.querySelector('.brand-scene-stage');if(!stage)return;
 const scene=intro.querySelector('.brand-scene'),workspace=document.getElementById('workspace'),skip=intro.querySelector('.scene-next');
 const reduced=matchMedia('(prefers-reduced-motion:reduce)'),clamp=v=>Math.max(0,Math.min(1,v)),ramp=(p,a,b)=>{const t=clamp((p-a)/(b-a));return t*t*(3-2*t);};
 let frame=0,last=0,elapsed=0,entry=null,revision=0,mode='waiting',departFrom=0,departTo=0,resizeTimer=0,lastLanding=null;
 intro.classList.add('scene-motion-ready');intro.dataset.entrance='waiting';
 const picturesReady=Promise.allSettled(Array.from(scene.querySelectorAll('img'),img=>typeof img.decode==='function'?img.decode():Promise.resolve()));
 window.QingruSceneReady=location.hash==='#workspace'?Promise.resolve():picturesReady;
 const navHeight=()=>matchMedia('(max-width:760px)').matches?62:70;
 const workspaceY=()=>Math.max(0,workspace.getBoundingClientRect().top+scrollY-navHeight());
 function draw(p,copyOverride){
  intro.style.setProperty('--scene-pan',ramp(p,0,.68).toFixed(4));intro.style.setProperty('--scene-dusk',ramp(p,.13,.65).toFixed(4));
  intro.style.setProperty('--scene-sunset',ramp(p,.18,.65).toFixed(4));intro.style.setProperty('--scene-sun-alpha',(1-ramp(p,.5,.68)).toFixed(4));intro.style.setProperty('--scene-night',ramp(p,.5,.77).toFixed(4));
  const copy=copyOverride===undefined?ramp(p,.77,.985):copyOverride;intro.style.setProperty('--scene-copy',copy.toFixed(4));
  intro.dataset.phase=p<.13?'day':p<.68?'sunset':p<.77?'night':copy>=.999?'reading':'title';intro.dataset.progress=p.toFixed(4);
 }
 function syncHeader(){document.body.classList.toggle('workspace-in-view',scrollY>=workspaceY()-4);}
 function stop(){cancelAnimationFrame(frame);frame=0;last=0;entry?.cancel();entry=null;revision++;mode='idle';intro.dataset.entrance='settled';intro.classList.remove('arrival-departing');}
 function finish(){
  window.scrollTo({top:departTo,behavior:'instant'});lastLanding=departTo;mode='idle';frame=0;last=0;intro.dataset.entrance='settled';intro.classList.remove('arrival-departing');syncHeader();
  if(location.hash!=='#workspace')history.replaceState(null,'',location.pathname+location.search+'#workspace');
 }
 function render(now){
  frame=0;if(document.hidden||!['sequence','departure'].includes(mode))return;
  elapsed+=last?Math.min(64,now-last):0;last=now;
  if(mode==='sequence'){
   draw(clamp(elapsed/2300));if(elapsed>=3200){goToWorkspace();return;}
  }else{
   const t=clamp(elapsed/950),eased=(1-Math.cos(Math.PI*t))/2;
   window.scrollTo({top:departFrom+(departTo-departFrom)*eased,behavior:'instant'});draw(1,1-ramp(t,0,.65));syncHeader();
   if(t>=1){finish();return;}
  }
  frame=requestAnimationFrame(render);
 }
 function startFrames(){if(!frame&&!document.hidden)frame=requestAnimationFrame(render);}
 function goToWorkspace(){
  stop();draw(1);departFrom=scrollY;departTo=workspaceY();elapsed=0;last=0;
  if(reduced.matches||Math.abs(departTo-departFrom)<2){finish();return;}
  mode='departure';intro.classList.add('arrival-departing');startFrames();
 }
 function userScroll(){if(['waiting','sequence','departure','entry'].includes(mode)){stop();draw(1);syncHeader();}}
 function waitForBoot(){return new Promise(resolve=>{const ready=()=>!document.documentElement.classList.contains('q-booting')&&!document.documentElement.classList.contains('q-boot-visible');if(ready()){resolve();return;}const observer=new MutationObserver(()=>{if(ready()){observer.disconnect();resolve();}});observer.observe(document.documentElement,{attributes:true,attributeFilter:['class']});});}
 async function entrance(){
  const version=++revision;await Promise.allSettled([waitForBoot(),picturesReady]);if(version!==revision)return;
  if(location.hash==='#workspace'||scrollY>=workspaceY()-4){draw(1);departTo=workspaceY();finish();return;}
  if(reduced.matches||typeof scene.animate!=='function'){draw(1);mode='idle';intro.dataset.entrance='settled';return;}
  mode='entry';intro.dataset.entrance='playing';entry=scene.animate([
   {clipPath:'inset(8% 49% round 18px)',transform:'scale(.72)',filter:'blur(8px)',opacity:0},
   {clipPath:'inset(0% 0% round 0px)',transform:'scale(1)',filter:'blur(0px)',opacity:1}
  ],{duration:800,easing:'cubic-bezier(.72,0,.16,1)',fill:'both'});
  if(document.hidden)entry.pause();try{await entry.finished;}catch{}if(version!==revision)return;
  entry.cancel();entry=null;intro.dataset.entrance='settled';mode='sequence';elapsed=0;last=0;startFrames();
 }
 if(skip)skip.addEventListener('click',event=>{event.preventDefault();goToWorkspace();});
 document.addEventListener('click',event=>{const a=event.target.closest?.('a[href="#workspace"]');if(a&&!a.classList.contains('scene-next')){event.preventDefault();goToWorkspace();}});
 window.addEventListener('wheel',userScroll,{passive:true});window.addEventListener('touchstart',userScroll,{passive:true});
 window.addEventListener('keydown',event=>{if(['PageDown','PageUp','ArrowDown','ArrowUp','Home','End',' '].includes(event.key)&&!event.target?.closest?.('input,textarea,select,button,a,[contenteditable]'))userScroll();});
 window.addEventListener('scroll',syncHeader,{passive:true});
 window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{if(mode==='departure')departTo=workspaceY();else if(lastLanding!==null&&Math.abs(scrollY-lastLanding)<4){lastLanding=workspaceY();window.scrollTo({top:lastLanding,behavior:'instant'});}syncHeader();},120);},{passive:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;last=0;entry?.pause();}else{entry?.play();startFrames();syncHeader();}});
 reduced.addEventListener('change',()=>{stop();draw(1);syncHeader();});window.addEventListener('pagehide',stop);
 window.addEventListener('pageshow',event=>{if(event.persisted){stop();draw(1);syncHeader();}});
 window.addEventListener('hashchange',()=>{if(location.hash==='#workspace')goToWorkspace();else{stop();draw(1);syncHeader();}});
 draw(0);syncHeader();entrance();
})();
