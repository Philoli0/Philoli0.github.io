(function(){
 'use strict';
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),animations=new WeakMap();
 const version=new URL(document.currentScript?.src||location.href,location.href).searchParams.get('v');
 function url(value){const u=new URL(value,location.href);if(version&&u.origin===location.origin)u.searchParams.set('ui',version);return u.href;}
 function enter(node,direction=1){if(!node||reduced.matches||typeof node.animate!=='function')return;for(const a of animations.get(node)||[])a.cancel();const options={duration:420,easing:'cubic-bezier(.22,.72,.14,1)'},running=[node.animate([{opacity:.45,transform:'translateX('+direction*18+'px)'},{opacity:1,transform:'translateX(0)'}],options)];const objects=node.matches('.album-stage')?node.querySelectorAll('.album-copy h2,.album-copy>p,.album-numbers,.album-actions'):node.matches('#slide')?node.querySelectorAll('#lessonTitle,#lessonVisual,#stageInteraction'):[];objects.forEach((part,i)=>running.push(part.animate([{opacity:.15,transform:'translateY(9px)'},{opacity:1,transform:'translateY(0)'}],{...options,duration:350,delay:Math.min(i,3)*30,fill:'backwards'})));animations.set(node,running);}
 const closing=new WeakSet();async function dismiss(dialog){if(!dialog?.open||closing.has(dialog))return;if(reduced.matches||typeof dialog.animate!=='function'){dialog.close();return;}closing.add(dialog);const a=dialog.animate([{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(10px)'}],{duration:170,easing:'cubic-bezier(.4,0,.8,.5)',fill:'forwards'});try{await a.finished;}catch{}dialog.close();a.cancel();closing.delete(dialog);}
 window.QingruMotion={enter,url,dismiss};
 document.querySelectorAll('iframe.report-inline').forEach(f=>{if(version)f.src=url(f.getAttribute('src'));});
 document.querySelectorAll('.paper-figure img').forEach(img=>{if(version){const u=new URL(img.src,location.href);u.searchParams.set('v',version);img.src=u.href;}});
 // Native document transitions and compositor-only hover styles replace pointer sampling.
 const prefetched=new Set();let intent=0;
 function target(a){if(!a||a.hasAttribute('download')||a.getAttribute('href')?.startsWith('#'))return null;const u=new URL(a.href,location.href);return u.origin===location.origin&&/\.html$|\/$/.test(u.pathname)?u:null;}
 function prepare(a){const u=target(a);if(!u)return null;if(version){u.searchParams.set('ui',version);a.href=u.href;}return u;}
 function prefetch(a){const u=prepare(a);if(!u||prefetched.has(u.href)||navigator.connection?.saveData||/2g/.test(navigator.connection?.effectiveType||''))return;prefetched.add(u.href);const l=document.createElement('link');l.rel='prefetch';l.href=u.href;l.as='document';document.head.appendChild(l);}
 document.addEventListener('pointerover',e=>{const a=e.target.closest?.('a[href]');if(!target(a))return;clearTimeout(intent);intent=setTimeout(()=>prefetch(a),95);},{passive:true});
 document.addEventListener('pointerout',e=>{if(e.target.closest?.('a[href]'))clearTimeout(intent);},{passive:true});
 document.addEventListener('focusin',e=>prefetch(e.target.closest?.('a[href]')));
 document.addEventListener('click',e=>prepare(e.target.closest?.('a[href]')),true);
 document.addEventListener('submit',e=>{const f=e.target;if(!version||!f.hasAttribute('action')||(f.method||'get').toLowerCase()!=='get')return;let input=f.querySelector('input[name="ui"]');if(!input){input=document.createElement('input');input.type='hidden';input.name='ui';f.appendChild(input);}input.value=version;},true);
})();

;
/* One tab, one destination. Enter returns only when it cannot conflict with an action. */
(function(){
 'use strict';
 function normalize(root){if(!root?.querySelectorAll)return;for(const a of root.querySelectorAll('a[target="_blank"]'))a.removeAttribute('target');}
 normalize(document);
 const observer=new MutationObserver(entries=>{for(const entry of entries){if(entry.type==='attributes'){if(entry.target.getAttribute('target')==='_blank')entry.target.removeAttribute('target');}else for(const n of entry.addedNodes)if(n.nodeType===1){if(n.matches?.('a[target="_blank"]'))n.removeAttribute('target');normalize(n);}}});
 if(document.body)observer.observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['target']});
 document.addEventListener('keydown',event=>{
  if(event.key!=='Enter'||event.defaultPrevented||event.repeat||event.isComposing||event.altKey||event.ctrlKey||event.metaKey||event.shiftKey)return;
  const back=document.querySelector('.workbench-return');if(!back||document.documentElement.classList.contains('report-embedded')||document.querySelector('dialog[open]'))return;
  const target=event.target;if(target?.closest?.('input,textarea,select,button,a,summary,video,audio,[contenteditable],[role="button"],[role="textbox"],[role="slider"]'))return;
  event.preventDefault();back.click();
 });
})();

window.QingruBoot?.ready();
