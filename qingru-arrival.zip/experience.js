(function(){
 'use strict';
 const album=document.getElementById('albumStage');if(album&&!album.hidden)window.QingruMotion?.enter(album);
 const dialog=document.getElementById('builderDialog');if(!dialog)return;
 const close=document.getElementById('closeBuilder');if(close)close.onclick=()=>window.QingruMotion?.dismiss(dialog)||dialog.close();
 dialog.addEventListener('cancel',e=>{if(window.QingruMotion?.dismiss){e.preventDefault();window.QingruMotion.dismiss(dialog);}});
 const drop=dialog.querySelector('[data-file-drop]'),compile=document.getElementById('compileDraft');let dragDepth=0;
 function isFile(e){return [...(e.dataTransfer?.types||[])].includes('Files');}
 if(drop){
  drop.addEventListener('dragenter',e=>{if(!isFile(e))return;e.preventDefault();dragDepth++;drop.classList.add('drag-active');});
  drop.addEventListener('dragover',e=>{if(isFile(e)){e.preventDefault();e.dataTransfer.dropEffect='copy';}});
  drop.addEventListener('dragleave',()=>{dragDepth=Math.max(0,dragDepth-1);if(!dragDepth)drop.classList.remove('drag-active');});
  drop.addEventListener('drop',e=>{if(!isFile(e))return;e.preventDefault();dragDepth=0;drop.classList.remove('drag-active');window.QingruStudio?.addFiles(e.dataTransfer.files);});
 }
 function state(){dialog.classList.toggle('is-building',!compile.hidden&&compile.disabled);dialog.classList.toggle('has-preview',!document.getElementById('builderPreview').hidden);dialog.setAttribute('aria-busy',String(!compile.hidden&&compile.disabled));}
 new MutationObserver(state).observe(dialog,{subtree:true,attributes:true,attributeFilter:['disabled','hidden']});
 dialog.addEventListener('close',()=>{dragDepth=0;drop?.classList.remove('drag-active');});state();
})();
