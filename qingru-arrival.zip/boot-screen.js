(function(){
 'use strict';
 const html=document.documentElement;html.classList.add('q-booting');html.setAttribute('aria-busy','true');let done=false,shown=false;
 const screen=()=>document.getElementById('bootScreen');
 const reveal=setTimeout(()=>{if(!done){shown=true;html.classList.add('q-boot-visible');}},130);
 const slow=setTimeout(()=>{if(!done){const s=screen();if(s){s.querySelector('.boot-message').textContent='加载时间较长，请检查网络';s.querySelector('.boot-retry').hidden=false;}}},10000);
 function ready(){if(done)return;done=true;clearTimeout(reveal);clearTimeout(slow);html.classList.remove('q-booting');html.setAttribute('aria-busy','false');document.body?.setAttribute('aria-busy','false');const s=screen();if(!s)return;if(shown&&!matchMedia('(prefers-reduced-motion:reduce)').matches){s.classList.add('boot-leaving');setTimeout(()=>{s.hidden=true;html.classList.remove('q-boot-visible');},170);}else{s.hidden=true;html.classList.remove('q-boot-visible');}}
 function fail(){const s=screen();if(!s)return;shown=true;html.classList.add('q-boot-visible');s.querySelector('.boot-message').textContent='页面未能完整加载';s.querySelector('.boot-retry').hidden=false;}
 function hint(text){const m=screen()?.querySelector('.boot-message');if(m)m.textContent=text;}
 document.addEventListener('click',e=>{if(e.target.closest?.('.boot-retry'))location.reload();});
 document.addEventListener('DOMContentLoaded',()=>{if(done&&screen())screen().hidden=true;});
 window.addEventListener('error',e=>{if((e.target?.tagName==='SCRIPT'&&/runtime/.test(e.target.src))||(e.filename&&/runtime/.test(e.filename)))fail();},true);
 window.addEventListener('pageshow',e=>{if(e.persisted)ready();});
 window.QingruBoot={ready,hint,fail};
})();
