(function(){
 'use strict';
 if(matchMedia('(prefers-reduced-motion: reduce)').matches||!matchMedia('(hover:hover)').matches)return;
 for(const tile of document.querySelectorAll('.kinetic-tile')){
  let frame=0;
  tile.addEventListener('pointermove',e=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{const r=tile.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;tile.style.setProperty('--drift-x',x*14+'px');tile.style.setProperty('--drift-y',y*10+'px');tile.style.setProperty('--tilt-x',-y*1.4+'deg');tile.style.setProperty('--tilt-y',x*1.4+'deg');});});
  tile.addEventListener('pointerleave',()=>{cancelAnimationFrame(frame);for(const name of ['--drift-x','--drift-y'])tile.style.setProperty(name,'0px');for(const name of ['--tilt-x','--tilt-y'])tile.style.setProperty(name,'0deg');});
 }
})();
