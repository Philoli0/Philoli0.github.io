(function(){
 'use strict';
 if(matchMedia('(prefers-reduced-motion: reduce)').matches||!matchMedia('(hover:hover)').matches)return;
 for(const tile of document.querySelectorAll('.kinetic-tile')){
  let frame=0;
  tile.addEventListener('pointermove',e=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{const r=tile.getBoundingClientRect();tile.style.setProperty('--drift-x',((e.clientX-r.left)/r.width-.5)*12+'px');tile.style.setProperty('--drift-y',((e.clientY-r.top)/r.height-.5)*10+'px');});});
  tile.addEventListener('pointerleave',()=>{cancelAnimationFrame(frame);tile.style.setProperty('--drift-x','0px');tile.style.setProperty('--drift-y','0px');});
 }
})();
