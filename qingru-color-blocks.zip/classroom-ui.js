(function(){
 'use strict';
 const el=id=>document.getElementById(id),esc=s=>window.QingruContent.escape(String(s??''));
 let currentIndex=0,videoMode=false,search='';
 function catalog(){
  const c=window.QINGRU_COURSE_DATA,active=c.lessons[currentIndex],box=el('catalog');
  const opened=new Set([...box.querySelectorAll('details[open]')].map(d=>d.dataset.chapter));
  const match=l=>!search||(l.title+' '+l.short).toLowerCase().includes(search);
  const page=(l,i)=>'<button class="unit'+(i===currentIndex?' active':'')+'" data-index="'+i+'"'+(i===currentIndex?' aria-current="step"':'')+'><span>'+String(i+1).padStart(2,'0')+'</span><span class="unit-title">'+esc(l.title)+'</span></button>';
  if(c.kind!=='document'){
   const groups=[['建立理解',0,3],['推理与应用',3,9],['巩固练习',9,c.lessons.length]];
   box.innerHTML=groups.map(([title,start,end])=>{const list=c.lessons.slice(start,end).map((l,k)=>({l,i:start+k})).filter(({l})=>match(l));return list.length?'<div class="catalog-group"><h3>'+title+'</h3>'+list.map(({l,i})=>page(l,i)).join('')+'</div>':'';}).join('');
  }else{
   const chapters=new Map();
   const sections=c.sections?.length?c.sections:[{id:active.section_id,title:c.title,chapter_title:'课程内容'}];
   for(const s of sections){const pages=c.lessons.map((l,i)=>({l,i})).filter(({l})=>l.section_id===s.id);if(!pages.length)continue;const chapter=s.chapter_title||'课程内容';const sectionMatch=!search||(chapter+' '+s.title).toLowerCase().includes(search);const filtered=pages.filter(({l})=>sectionMatch||match(l));if(!filtered.length)continue;if(!chapters.has(chapter))chapters.set(chapter,[]);chapters.get(chapter).push({s,pages,filtered,showPages:s.id===active.section_id||Boolean(search&&!sectionMatch)});}
   box.innerHTML=[...chapters].map(([chapter,sections])=>{const activeChapter=sections.some(({s})=>s.id===active.section_id);return '<details class="catalog-chapter" data-chapter="'+esc(chapter)+'"'+(search||activeChapter||opened.has(chapter)?' open':'')+'><summary><span>'+esc(chapter)+'</span><small>'+sections.length+' 节</small></summary><div>'+sections.map(({s,pages,filtered,showPages})=>'<button class="section-link'+(s.id===active.section_id?' current':'')+'" data-index="'+pages[0].i+'"><span>'+esc(s.title)+'</span><small>'+pages.length+' 页</small></button>'+(showPages?'<div class="section-pages">'+filtered.map(({l,i})=>page(l,i)).join('')+'</div>':'')).join('')+'</div></details>';}).join('');
  }
  if(!box.innerHTML)box.innerHTML='<p class="catalog-empty">没有找到相关内容，请换个关键词。</p>';
  for(const b of box.querySelectorAll('[data-index]'))b.onclick=()=>window.QingruNavigateLesson(Number(b.dataset.index));
  el('chapterField').hidden=true;el('count').textContent=(currentIndex+1)+' / '+c.lessons.length+' 页';
 }
 function mode(isVideo){
  videoMode=Boolean(isVideo&&window.QINGRU_COURSE_DATA.lecture?.url);
  el('stage').classList.toggle('video-mode',videoMode);
  el('courseView').classList.toggle('watching-video',videoMode);
  el('videoMode').setAttribute('aria-pressed',String(videoMode));el('slideMode').setAttribute('aria-pressed',String(!videoMode));
  el('lessonVideo').hidden=!videoMode;el('posterPlay').hidden=!videoMode||!el('lessonVideo').paused;
  if(!videoMode)el('lessonVideo').pause();
  document.querySelector('.page-transport').hidden=videoMode;
  el('contextLabel').textContent=videoMode?'本节精讲':'本页要点';
  el('lessonBrief').textContent=videoMode?'从排队与滞销的生活情境出发，理解均衡价格、市场调整与供求变化。切换动态课件，可继续操作图表并完成练习。':window.QINGRU_COURSE_DATA.lessons[currentIndex].body;
  el('lectureStart').hidden=!videoMode;
 }
 function refresh(lesson,index){
  currentIndex=index;el('slide').scrollTop=0;
  const c=window.QINGRU_COURSE_DATA,extra=el('interactive'),stage=el('stage');
  const showInteraction=c.kind!=='document'&&Boolean(extra.innerHTML.trim());
  stage.classList.toggle('interaction-mode',showInteraction);stage.classList.toggle('reading-mode',c.kind==='document');
  stage.dataset.layout=c.kind==='document'?'document':lesson.id;
  const categories={opening:'情境导入',definition:'核心概念',table:'数据读解',adjustment:'动态推演',linear:'模型求解',shifts:'动态推演',both:'条件比较',model:'模型条件',cobweb:'时间推演',quiz:'理解练习'};
  el('slideCategory').textContent=c.kind==='document'?'教材课堂':categories[lesson.id]||'知识讲解';
  el('stageCaption').hidden=true;el('lessonVisual').hidden=showInteraction;
  extra.hidden=false;(showInteraction?el('stageInteraction'):el('readingDetail')).appendChild(extra);
  if(c.kind==='document'){
   const picture=(lesson.blocks||[]).flatMap(b=>b.images||[])[0];
   if(picture)el('lessonVisual').innerHTML='<figure class="source-figure"><img src="'+esc(picture)+'" alt="本页教材原图"><figcaption>教材原图</figcaption></figure>';
  }
  if(c.kind!=='document'&&!showInteraction){
   const note=document.createElement('div');note.className='slide-explanation';note.innerHTML='<span>关键理解</span><p>'+esc(lesson.body)+'</p>';el('lessonVisual').appendChild(note);
  }
  const quizCards=[...extra.querySelectorAll('.quiz')];
  if(showInteraction&&quizCards.length){
   let question=0;const pager=document.createElement('div');pager.className='quiz-pager';pager.innerHTML='<button class="quiz-back" aria-label="上一题">上一题</button><span aria-live="polite"></span><button class="quiz-forward" aria-label="下一题">下一题</button>';extra.prepend(pager);
   const render=()=>{el('slide').scrollTop=0;quizCards.forEach((card,k)=>card.hidden=k!==question);pager.querySelector('span').textContent='问题 '+(question+1)+' / '+quizCards.length;pager.querySelector('.quiz-back').disabled=question===0;pager.querySelector('.quiz-forward').disabled=question===quizCards.length-1;};
   pager.querySelector('.quiz-back').onclick=()=>{question--;render();};pager.querySelector('.quiz-forward').onclick=()=>{question++;render();};render();
  }
  el('pageLabel').textContent=(index+1)+' / '+c.lessons.length;el('pageSource').textContent='查看本页 '+lesson.sources.length+' 条原文';
  mode(false);catalog();el('roomMenu').open=false;
  if(window.matchMedia('(max-width:900px)').matches)closeCatalog();
 }
 function closeCatalog(){document.body.classList.remove('catalog-open');el('sidebarScrim').hidden=true;el('catalogToggle').setAttribute('aria-expanded','false');el('catalogToggle').setAttribute('aria-label','展开课程目录');}
 function open(id){el('lessonVideo').pause();el('roomMenu').open=false;el(id).showModal();}
 async function play(){
  mode(true);const v=el('lessonVideo');el('mediaStatus').hidden=true;
  if(!v.paused){v.pause();return;}
  el('answerAudio').pause();el('demoVideo').pause();if(v.ended)v.currentTime=0;
  try{await v.play();}catch{el('mediaStatus').textContent='暂时无法播放，请检查网络后重试。';el('mediaStatus').hidden=false;}
 }
 function init(course){
  document.body.classList.add('classroom-ready');el('courseView').setAttribute('aria-busy','false');
  for(const id of ['catalogToggle','openNotes','openQA','courseSwitch','slideMode'])el(id).disabled=false;
  const hasVideo=Boolean(course.lecture?.url);el('videoMode').hidden=!hasVideo;el('videoMode').disabled=!hasVideo;
  el('lectureStart').disabled=!hasVideo;el('lectureStart').textContent='播放';el('roomMode').textContent=hasVideo?'数字讲师课堂':'资料课堂';
  const courses=window.QingruLibrary.courses;
  el('courseSwitch').innerHTML=courses.map(c=>'<option value="'+esc(c.id)+'">'+esc(c.title)+'</option>').join('')+(course.id?.startsWith('draft-')?'<option value="'+esc(course.id)+'">'+esc(course.title)+'</option>':'');
  el('courseSwitch').value=course.id;
  el('courseSwitch').onchange=()=>{const chosen=courses.find(c=>c.id===el('courseSwitch').value);if(chosen)location.href=chosen.url;};
  el('openNotes').onclick=()=>open('notesDialog');el('openQA').onclick=()=>open('qaDialog');
  el('videoMode').onclick=()=>mode(true);el('slideMode').onclick=()=>mode(false);el('lectureStart').onclick=play;el('posterPlay').onclick=play;
  const v=el('lessonVideo');
  v.controls=false;
  v.addEventListener('play',()=>{v.controls=true;el('lectureStart').textContent='暂停';el('posterPlay').hidden=true;});
  v.addEventListener('pause',()=>{el('lectureStart').textContent=v.ended?'重新播放':'继续播放';el('posterPlay').hidden=!videoMode;});
  v.onended=()=>{el('lectureStart').textContent='重新播放';el('posterPlay').hidden=false;};
  v.addEventListener('error',()=>{if(hasVideo){el('mediaStatus').textContent='视频未能载入，请刷新页面后重试。';el('mediaStatus').hidden=false;}});
  function duration(){if(Number.isFinite(v.duration))el('mediaDuration').textContent='精讲 '+Math.floor(v.duration/60)+':'+String(Math.round(v.duration%60)).padStart(2,'0');}
  v.addEventListener('loadedmetadata',duration);duration();
  el('catalogSearch').oninput=e=>{search=e.target.value.trim().toLowerCase();catalog();};
  el('catalogToggle').onclick=()=>{const expanded=document.body.classList.toggle('catalog-open');el('sidebarScrim').hidden=!expanded;el('catalogToggle').setAttribute('aria-expanded',String(expanded));el('catalogToggle').setAttribute('aria-label',expanded?'收起课程目录':'展开课程目录');};
  el('catalogClose').onclick=closeCatalog;
  el('sidebarScrim').onclick=closeCatalog;
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeCatalog();});
  document.addEventListener('click',e=>{if(!el('roomMenu').contains(e.target))el('roomMenu').open=false;});
  for(const b of el('roomMenu').querySelectorAll('button'))b.addEventListener('click',()=>{el('roomMenu').open=false;});
  for(const d of document.querySelectorAll('dialog'))d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}});
  mode(hasVideo&&currentIndex===0);catalog();
 }
 window.QingruClassroom={refresh,init};
})();
