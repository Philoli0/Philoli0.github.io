(function(){
 'use strict';const stage=document.querySelector('#colourstage');if(!stage)return;
 const panels=[...stage.querySelectorAll('[data-panel]')],fine=matchMedia('(hover:hover) and (pointer:fine)');
 let hovered=null,focused=null;function sync(){stage.dataset.active=(focused||hovered)?.dataset.panel||'';}
 for(const panel of panels){panel.addEventListener('pointerenter',()=>{if(fine.matches){hovered=panel;sync();}});panel.addEventListener('pointerleave',()=>{if(hovered===panel)hovered=null;sync();});panel.addEventListener('focusin',()=>{focused=panel;sync();});panel.addEventListener('focusout',e=>{if(!panel.contains(e.relatedTarget)){focused=null;sync();}});}
 document.addEventListener('visibilitychange',()=>{if(document.hidden){hovered=null;sync();}});
})();
