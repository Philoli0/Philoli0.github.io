/* One opening per document. The workbench is a separate, permanent screen. */
(function(){
 'use strict';
 const intro=document.querySelector('.scene-intro');if(!intro)return;
 const scene=intro.querySelector('.brand-scene'),workspace=document.getElementById('workspace'),skip=intro.querySelector('.scene-next');
 const reduced=matchMedia('(prefers-reduced-motion:reduce)'),clamp=v=>Math.max(0,Math.min(1,v));
 const ramp=(p,a,b)=>{const t=clamp((p-a)/(b-a));return t*t*(3-2*t);};
 const nav=performance.getEntriesByType('navigation')[0],directReturn=location.hash==='#workspace'&&nav?.type!=='reload';
 let frame=0,last=0,elapsed=0,mode='waiting',revision=0,entry=null,exit=null,closed=false;
 const picturesReady=Promise.allSettled(Array.from(scene.querySelectorAll('img'),img=>typeof img.decode==='function'?img.decode():Promise.resolve()));
 window.QingruSceneReady=directReturn?Promise.resolve():picturesReady;
 function scrollTop(){window.scrollTo({top:0,behavior:'instant'});}
 function draw(p,copyOverride){
  intro.style.setProperty('--scene-pan',ramp(p,0,.68).toFixed(4));intro.style.setProperty('--scene-dusk',ramp(p,.13,.65).toFixed(4));
  intro.style.setProperty('--scene-sunset',ramp(p,.18,.65).toFixed(4));intro.style.setProperty('--scene-sun-alpha',(1-ramp(p,.5,.68)).toFixed(4));intro.style.setProperty('--scene-night',ramp(p,.5,.77).toFixed(4));
  const copy=copyOverride===undefined?ramp(p,.77,.985):copyOverride;intro.style.setProperty('--scene-copy',copy.toFixed(4));
  intro.dataset.phase=p<.13?'day':p<.68?'sunset':p<.77?'night':copy>=.999?'reading':'title';
 }
 function finish(){
  if(closed)return;closed=true;revision++;mode='closed';cancelAnimationFrame(frame);frame=0;entry?.cancel();exit?.cancel();
  intro.remove();workspace.inert=false;workspace.removeAttribute('aria-hidden');document.body.classList.remove('intro-active','intro-departing');
  document.body.classList.add('workspace-in-view');document.body.dataset.opening='complete';workspace.classList.add('workspace-arrived');
  scrollTop();history.replaceState(null,'',location.pathname+location.search+'#workspace');
 }
 async function depart(){
  if(closed||mode==='departure')return;mode='departure';revision++;cancelAnimationFrame(frame);frame=0;last=0;entry?.cancel();draw(1);
  document.body.classList.add('intro-departing');intro.inert=true;
  if(reduced.matches||typeof intro.animate!=='function'){finish();return;}
  exit=intro.animate([{transform:'translateY(0)'},{transform:'translateY(-101%)'}],{duration:950,easing:'cubic-bezier(.76,0,.2,1)',fill:'both'});
  try{await exit.finished;}catch{}finish();
 }
 function render(now){
  frame=0;if(closed||document.hidden||mode!=='sequence')return;
  elapsed+=last?Math.min(64,now-last):0;last=now;draw(clamp(elapsed/2500));
  if(elapsed>=3900){depart();return;}frame=requestAnimationFrame(render);
 }
 function run(){if(!frame&&!document.hidden&&mode==='sequence')frame=requestAnimationFrame(render);}
 function bootReady(){return new Promise(resolve=>{
  const ready=()=>!document.documentElement.classList.contains('q-booting')&&!document.documentElement.classList.contains('q-boot-visible');
  if(ready()){resolve();return;}const observer=new MutationObserver(()=>{if(ready()){observer.disconnect();resolve();}});observer.observe(document.documentElement,{attributes:true,attributeFilter:['class']});
 });}
 async function enter(){
  const version=++revision;await Promise.allSettled([bootReady(),picturesReady]);if(closed||version!==revision)return;
  if(reduced.matches){draw(1);intro.dataset.entrance='settled';mode='sequence';elapsed=3000;run();return;}
  mode='entry';intro.dataset.entrance='playing';
  entry=scene.animate([{clipPath:'inset(8% 49% round 18px)',transform:'scale(.72)',filter:'blur(8px)',opacity:0},{clipPath:'inset(0% 0% round 0px)',transform:'scale(1)',filter:'blur(0px)',opacity:1}],{duration:800,easing:'cubic-bezier(.72,0,.16,1)',fill:'both'});
  if(document.hidden)entry.pause();try{await entry.finished;}catch{}if(closed||version!==revision)return;
  entry.cancel();entry=null;intro.dataset.entrance='settled';mode='sequence';elapsed=0;last=0;run();
 }
 if(directReturn){finish();return;}
 // A reload always starts the opening again, including URLs returned from inner pages.
 history.scrollRestoration='manual';history.replaceState(null,'',location.pathname+location.search);
 document.body.classList.add('intro-active');document.body.dataset.opening='playing';workspace.inert=true;workspace.setAttribute('aria-hidden','true');scrollTop();
 intro.classList.add('scene-motion-ready');intro.dataset.entrance='waiting';draw(0);
 skip?.addEventListener('click',e=>{e.preventDefault();depart();});
 document.addEventListener('click',e=>{const a=e.target.closest?.('a[href="#workspace"],a[href="#top"]');if(!a)return;e.preventDefault();if(!closed)depart();else scrollTop();});
 window.addEventListener('hashchange',()=>{if(closed){history.replaceState(null,'',location.pathname+location.search+'#workspace');scrollTop();}});
 window.addEventListener('pageshow',e=>{if(e.persisted&&!closed)finish();else if(!closed)scrollTop();});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;last=0;entry?.pause();exit?.pause();}else{entry?.play();exit?.play();run();}});
 reduced.addEventListener('change',()=>{if(!closed)depart();});enter();
})();
