(function(){
 'use strict';
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),animations=new WeakMap();
 const version=new URL(document.currentScript?.src||location.href,location.href).searchParams.get('v');
 function url(value){const u=new URL(value,location.href);if(version&&u.origin===location.origin)u.searchParams.set('ui',version);return u.href;}
 function enter(node,direction=1){if(!node||reduced.matches||typeof node.animate!=='function')return;animations.get(node)?.cancel();const a=node.animate([{opacity:.6,transform:'translateX('+direction*9+'px)'},{opacity:1,transform:'translateX(0)'}],{duration:190,easing:'cubic-bezier(.2,.7,.2,1)'});animations.set(node,a);}
 window.QingruMotion={enter,url};
 document.querySelectorAll('iframe.report-inline').forEach(f=>{if(version)f.src=url(f.getAttribute('src'));});
 // Native document transitions and compositor-only hover styles replace pointer sampling.
 const prefetched=new Set();let intent=0;
 function target(a){if(!a||a.hasAttribute('download')||a.target==='_blank')return null;const u=new URL(a.href,location.href);return u.origin===location.origin&&/\.html$|\/$/.test(u.pathname)?u:null;}
 function prepare(a){const u=target(a);if(!u)return null;if(version){u.searchParams.set('ui',version);a.href=u.href;}return u;}
 function prefetch(a){const u=prepare(a);if(!u||prefetched.has(u.href)||navigator.connection?.saveData||/2g/.test(navigator.connection?.effectiveType||''))return;prefetched.add(u.href);const l=document.createElement('link');l.rel='prefetch';l.href=u.href;l.as='document';document.head.appendChild(l);}
 document.addEventListener('pointerover',e=>{const a=e.target.closest?.('a[href]');if(!target(a))return;clearTimeout(intent);intent=setTimeout(()=>prefetch(a),95);},{passive:true});
 document.addEventListener('pointerout',e=>{if(e.target.closest?.('a[href]'))clearTimeout(intent);},{passive:true});
 document.addEventListener('focusin',e=>prefetch(e.target.closest?.('a[href]')));
 document.addEventListener('click',e=>prepare(e.target.closest?.('a[href]')),true);
 document.addEventListener('submit',e=>{const f=e.target;if(!version||!f.hasAttribute('action')||(f.method||'get').toLowerCase()!=='get')return;let input=f.querySelector('input[name="ui"]');if(!input){input=document.createElement('input');input.type='hidden';input.name='ui';f.appendChild(input);}input.value=version;},true);
})();
