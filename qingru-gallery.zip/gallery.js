(function(){
 'use strict';
 const hero=document.querySelector('#galleryHero');if(!hero)return;
 const tabs=[...hero.querySelectorAll('[role="tab"]')],panels=[...hero.querySelectorAll('[role="tabpanel"]')],plates=[...hero.querySelectorAll('.gallery-plate')];
 const reduced=matchMedia('(prefers-reduced-motion:reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
 let angle=.23,active=false,frame=0,last=0,width=0,height=0;
 function paint(){
  const mobile=width<700,rx=Math.min(width*(mobile ? .33 : .25),330),ry=Math.min(height*(mobile ? .25 : .30),222),tilt=-.27;
  plates.forEach((p,i)=>{const t=i*Math.PI/6+angle,x=Math.cos(t)*rx,y=Math.sin(t)*ry;
   const px=x*Math.cos(tilt)-y*Math.sin(tilt),py=x*Math.sin(tilt)+y*Math.cos(tilt),depth=(Math.sin(t)+1)/2;
   p.style.transform='translate3d('+px.toFixed(2)+'px,'+py.toFixed(2)+'px,0) rotate('+(-8+Math.cos(t)*14).toFixed(1)+'deg) rotateY('+(Math.cos(t)*48).toFixed(1)+'deg) scale('+(.70+depth*.26).toFixed(3)+')';
   p.style.opacity=(.48+depth*.42).toFixed(2);
  });
 }
 function tick(now){frame=0;if(!active||reduced.matches||document.hidden)return;const dt=last?Math.min(40,now-last):0;last=now;angle+=dt*.00013*(hero.dataset.gallery==='search'?-1:1);paint();frame=requestAnimationFrame(tick);}
 function start(){if(!fine.matches||reduced.matches)return;active=true;last=0;if(!frame)frame=requestAnimationFrame(tick);}
 function stop(){active=false;last=0;if(frame)cancelAnimationFrame(frame);frame=0;}
 function select(tab,focus=false){
  const id=tab.dataset.galleryTab;hero.dataset.gallery=id;tabs.forEach(t=>{const on=t===tab;t.setAttribute('aria-selected',String(on));t.tabIndex=on?0:-1;});
  panels.forEach(p=>p.hidden=p.id!=='gallery-'+id);const panel=document.getElementById('gallery-'+id);window.QingruMotion?.enter(panel);if(focus)tab.focus();
 }
 tabs.forEach((tab,i)=>{tab.addEventListener('click',()=>select(tab));tab.addEventListener('keydown',e=>{let n;if(e.key==='ArrowRight')n=(i+1)%tabs.length;else if(e.key==='ArrowLeft')n=(i+tabs.length-1)%tabs.length;else if(e.key==='Home')n=0;else if(e.key==='End')n=tabs.length-1;else return;e.preventDefault();select(tabs[n],true);});});
 new ResizeObserver(entries=>{const r=entries[0].contentRect;width=r.width;height=r.height;paint();}).observe(hero);
 hero.addEventListener('pointerenter',start,{passive:true});hero.addEventListener('pointerleave',stop,{passive:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});reduced.addEventListener('change',stop);
})();
