(async function(){
 window.QingruBoot?.hint('正在准备课程');
 const params=new URLSearchParams(location.search),id=params.get('course'),draft=params.get('draft');
 try{
  if(draft){const course=await QingruStore.get(draft);if(!course)throw Error('此浏览器没有这份草稿，请回课程库查看或重新导入材料。');window.QINGRU_COURSE_DATA=course;}
  else if(id&&id!=='market-equilibrium'){const meta=QingruLibrary.courses.find(c=>c.id===id);if(!meta)throw Error('没有找到这门课程。');await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=window.QingruMotion?.url(meta.data)||meta.data;script.onload=resolve;script.onerror=()=>reject(Error('课程资料加载失败，请刷新重试。'));document.body.appendChild(script);});window.QINGRU_COURSE_DATA=QingruLibrary.loaded[id];}
  const course=window.QINGRU_COURSE_DATA;document.title=course.title+' · 清如课堂';document.getElementById('courseTitle').textContent=course.title;document.getElementById('courseDescription').textContent=course.kind==='document'?'按章节阅读、核对原文，再通过练习检验理解。':'从一杯奶茶的价格，理解供求如何相遇。';
  if(course.kind==='document'){document.querySelector('.heading .subtle').textContent='资料课堂 / '+(draft?'我的材料':course.source);document.querySelector('.aside-foot').textContent='原文保留 · 按章节学习';document.querySelector('.ask-section>div>p').textContent='从本课程原文中查找相关段落。';document.querySelector('.ask-body>.mode-note').textContent='本页提供材料检索；新讲解视频尚未制作。';document.getElementById('question').placeholder='输入课程中的概念或关键词';}
  await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='app.js';script.onload=resolve;script.onerror=reject;document.body.appendChild(script);});window.QingruClassroom?.init(course);
 }catch(e){document.querySelector('.lesson-area').innerHTML='<div class="empty-state">'+QingruContent.escape(e.message)+'<p><a class="button" href="courses.html">返回课程库</a></p></div>';const button=document.getElementById('lectureStart');if(button)button.hidden=true;document.getElementById('courseView').setAttribute('aria-busy','false');window.QingruBoot?.ready();}
})();
